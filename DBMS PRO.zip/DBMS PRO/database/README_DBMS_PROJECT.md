# CAMPUS PRODUCT EXCHANGE SYSTEM (CampusX)
## Relational Database Management System (DBMS) Specification

### 1. Database Overview
* **Database Engine:** MySQL 8.0+ / MariaDB / InnoDB
* **Character Set:** `utf8mb4`
* **Collation:** `utf8mb4_unicode_ci`
* **SQL Scripts:**
  - [`campus_product_exchange.sql`](file:///c:/Users/IRFAN786/OneDrive/Desktop/DBMS%20PRO/campus_product_exchange.sql) (Root level)
  - [`database/schema.sql`](file:///c:/Users/IRFAN786/OneDrive/Desktop/DBMS%20PRO/database/schema.sql)

---

### 2. Entity-Relationship (ER) Architecture

```mermaid
erDiagram
    STUDENT ||--o{ PRODUCT : owns
    STUDENT ||--o{ PRODUCT_REQUEST : creates
    STUDENT ||--o{ EXCHANGE : lends
    STUDENT ||--o{ EXCHANGE : borrows
    STUDENT ||--o{ NOTIFICATION : receives
    PRODUCT_CATEGORY ||--o{ PRODUCT : categorizes
    PRODUCT_CATEGORY ||--o{ PRODUCT_REQUEST : classifies
    CAMPUS_LOCATION ||--o{ PRODUCT : located_at
    CAMPUS_LOCATION ||--o{ PRODUCT_REQUEST : needed_at
    PRODUCT_REQUEST ||--o| EXCHANGE : initiates
    EXCHANGE ||--|| TRANSACTION : audits
    TRANSACTION ||--o{ STUDENT_FEEDBACK : reviewed_in

    STUDENT {
        string student_id PK
        string full_name
        string department
        string academic_year
        string section
        string college_email UK
        string phone_number
        decimal trust_rating
        int total_lent
        int total_borrowed
        int total_completed
    }

    PRODUCT {
        string product_id PK
        string owner_id FK
        int category_id FK
        string product_name
        string item_condition
        boolean is_available
        int location_id FK
        int quantity
    }

    PRODUCT_REQUEST {
        string request_id PK
        string requester_id FK
        int category_id FK
        string product_name
        int quantity
        string urgency_level
        int location_id FK
        string status
    }

    EXCHANGE {
        int exchange_id PK
        string request_id FK
        string lender_id FK
        string borrower_id FK
        string exchange_status
        timestamp accepted_at
        timestamp returned_at
    }

    TRANSACTION {
        string transaction_id PK
        int exchange_id FK
        string requester_id FK
        string provider_id FK
        string transaction_status
        date transaction_date
    }
```

---

### 3. Database Normalization (1NF, 2NF, 3NF)

1. **First Normal Form (1NF):**
   - Every column contains atomic (indivisible) values.
   - Primary keys (`student_id`, `product_id`, `request_id`, `transaction_id`, etc.) uniquely identify all rows.
   - No repeating groups or multivalued attributes (e.g., student phone numbers and emails are normalized).

2. **Second Normal Form (2NF):**
   - The database is in 1NF and contains no partial functional dependencies.
   - All non-key attributes are fully functionally dependent on the primary key.

3. **Third Normal Form (3NF):**
   - The database is in 2NF and has no transitive dependencies ($X \to Y$ and $Y \to Z$).
   - Locations (`campus_locations`) and Categories (`product_categories`) are separated into lookup tables instead of redundantly embedding block, floor, or category descriptions inside `products` or `product_requests`.

---

### 4. How to Import the Database in MySQL / phpMyAdmin

#### Method 1: Using MySQL CLI
```bash
mysql -u root -p < campus_product_exchange.sql
```

#### Method 2: Using MySQL Workbench
1. Open MySQL Workbench and connect to your local MySQL instance.
2. Go to **File** -> **Open SQL Script...**
3. Select `campus_product_exchange.sql`.
4. Click the **Execute (Lightning)** icon to execute the script.

#### Method 3: Using XAMPP phpMyAdmin
1. Open XAMPP Control Panel and start **MySQL** and **Apache**.
2. Visit `http://localhost/phpmyadmin/` in your browser.
3. Click on the **Import** tab at the top.
4. Choose `campus_product_exchange.sql` and click **Import**.

---

### 5. Backend Connection Snippet (Node.js + Express with `mysql2/promise`)

```javascript
// config/db.js
import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'campus_product_exchange',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

export default pool;
```
