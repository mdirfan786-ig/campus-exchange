import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_FILE = path.resolve(__dirname, '../database/campusx_db.json');

// Default initial seed data structured to match the MySQL DBMS Schema
const SEED_DATA = {
  categories: [
    { id: 1, name: 'Calculators', icon: 'bi-calculator-fill', desc: 'Scientific & graphing calculators for lab/math exams' },
    { id: 2, name: 'Geometry Tools', icon: 'bi-rulers', desc: 'Mini drafters, compasses, divider sets, roller scales' },
    { id: 3, name: 'Lab Equipment', icon: 'bi-flask', desc: 'Lab coats, safety goggles, multimeters, breadboards' },
    { id: 4, name: 'Electronics', icon: 'bi-cpu-fill', desc: 'Arduino boards, sensors, jumper wires, soldering tools' },
    { id: 5, name: 'Books', icon: 'bi-book-half', desc: 'Engineering textbooks, lecture notes, solution manuals' },
    { id: 6, name: 'Stationery', icon: 'bi-pen-fill', desc: 'Staplers, punchers, technical markers, highlighters' },
    { id: 7, name: 'Sports Items', icon: 'bi-dribbble', desc: 'Badminton racquets, football, table tennis gear' },
    { id: 8, name: 'Other', icon: 'bi-box-seam', desc: 'General campus academic utilities and chargers' }
  ],
  locations: [
    'Main block ground floor',
    'Main block 1st floor',
    'Main block 2nd floor',
    'Main block 3rd floor',
    'Techpark ground floor',
    'Techpark 1st floor',
    'Techpark 2nd floor',
    'Tech park 3rd floor',
    'Academic block ground floor',
    'Academic block 1st floor',
    'Academic block 2nd floor',
    'Academic block 3rd floor'
  ],
  students: [
    {
      id: "STU1001",
      name: "Mohamed Irfan N",
      department: "Computer Science & Engineering",
      year: "3",
      section: "A",
      email: "mohamed.irfan@example.com",
      phone: "+91 98451 23450",
      avatar: "",
      password: "password123",
      stats: { lent: 8, borrowed: 5, completed: 12, rating: 4.9 }
    },
    {
      id: "STU1002",
      name: "Rahul Sharma",
      department: "Mechanical Engineering",
      year: "4",
      section: "B",
      email: "rahul.sharma@example.com",
      phone: "+91 98765 43210",
      avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80",
      password: "password123",
      stats: { lent: 14, borrowed: 3, completed: 17, rating: 5.0 }
    },
    {
      id: "STU1003",
      name: "Priya Patel",
      department: "Electronics & Communication",
      year: "3",
      section: "A",
      email: "priya.patel@example.com",
      phone: "+91 97654 32109",
      avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
      password: "password123",
      stats: { lent: 6, borrowed: 9, completed: 15, rating: 4.8 }
    },
    {
      id: "STU1004",
      name: "Vikram Reddy",
      department: "Civil Engineering",
      year: "2",
      section: "C",
      email: "vikram.reddy@example.com",
      phone: "+91 96543 21098",
      avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
      password: "password123",
      stats: { lent: 3, borrowed: 7, completed: 9, rating: 4.6 }
    },
    {
      id: "STU1005",
      name: "Ananya Iyer",
      department: "Electrical & Electronics",
      year: "4",
      section: "A",
      email: "ananya.iyer@example.com",
      phone: "+91 95432 10987",
      avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80",
      password: "password123",
      stats: { lent: 11, borrowed: 4, completed: 15, rating: 4.95 }
    }
  ],
  products: [
    {
      id: "PROD101",
      name: "Casio FX-991EX ClassWiz Scientific Calculator",
      category: "Calculators",
      description: "High-resolution natural textbook display with 552 functions. Allowed in all university semester exams.",
      condition: "Excellent",
      available: true,
      ownerId: "STU1001",
      ownerName: "Mohamed Irfan N",
      ownerDept: "CSE",
      location: "Main block ground floor",
      availableTime: "8:30 AM - 5:00 PM",
      quantity: 1,
      icon: "bi-calculator-fill",
      image: "https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=400&auto=format&fit=crop&q=80"
    },
    {
      id: "PROD102",
      name: "Engineering Drawing Mini Drafter & T-Square",
      category: "Geometry Tools",
      description: "Precision metal clamp drafter with scale rules. Perfect for machine drawing & civil graphics labs.",
      condition: "Good",
      available: true,
      ownerId: "STU1002",
      ownerName: "Rahul Sharma",
      ownerDept: "Mechanical",
      location: "Techpark ground floor",
      availableTime: "9:00 AM - 4:30 PM",
      quantity: 1,
      icon: "bi-rulers",
      image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=400&auto=format&fit=crop&q=80"
    },
    {
      id: "PROD103",
      name: "Digital Multimeter with Test Probes",
      category: "Lab Equipment",
      description: "True-RMS digital multimeter with probe leads for voltage, resistance, diode, and continuity test.",
      condition: "Like New",
      available: true,
      ownerId: "STU1003",
      ownerName: "Priya Patel",
      ownerDept: "ECE",
      location: "Techpark 2nd floor",
      availableTime: "10:00 AM - 6:00 PM",
      quantity: 1,
      icon: "bi-cpu-fill",
      image: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=400&auto=format&fit=crop&q=80"
    },
    {
      id: "PROD104",
      name: "White Chemistry Laboratory Coat (Size L)",
      category: "Lab Equipment",
      description: "Pure cotton protective white lab coat with deep pockets. Clean and ironed, ready for practicals.",
      condition: "Good",
      available: true,
      ownerId: "STU1004",
      ownerName: "Vikram Reddy",
      ownerDept: "Civil",
      location: "Academic block ground floor",
      availableTime: "9:00 AM - 5:00 PM",
      quantity: 1,
      icon: "bi-shield-check",
      image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&auto=format&fit=crop&q=80"
    }
  ],
  requests: [
    {
      id: "REQ1021",
      requesterId: "STU1003",
      requesterName: "Priya Patel",
      requesterDept: "ECE",
      requesterYear: "3",
      productName: "Casio FX-991ES Plus Scientific Calculator",
      category: "Calculators",
      quantity: 1,
      urgency: "Emergency",
      location: "Main block ground floor",
      neededUntil: "1:30 PM (End of Exam Session)",
      reason: "Mid-semester Signals & Systems exam starts at 10:30 AM. My calculator battery died this morning.",
      status: "Waiting",
      acceptedBy: null,
      pickupDetails: null,
      createdAt: "2026-09-30T09:15:00.000Z"
    },
    {
      id: "REQ1022",
      requesterId: "STU1004",
      requesterName: "Vikram Reddy",
      requesterDept: "Civil",
      requesterYear: "2",
      productName: "Engineering Mini Drafter & Board Clips",
      category: "Geometry Tools",
      quantity: 1,
      urgency: "Urgent",
      location: "Techpark ground floor",
      neededUntil: "4:00 PM (After Practical Submission)",
      reason: "Building Planning & Drawing practical submission today. Need drafter to finalize floor plan plates.",
      status: "Accepted",
      acceptedBy: {
        id: "STU1002",
        name: "Rahul Sharma",
        department: "Mechanical",
        phone: "+91 98765 43210",
        location: "Techpark ground floor lobby"
      },
      pickupDetails: "Meet me at Techpark ground floor lobby near notice board. Text on arrival.",
      createdAt: "2026-09-30T08:45:00.000Z"
    },
    {
      id: "REQ1023",
      requesterId: "STU1005",
      requesterName: "Ananya Iyer",
      requesterDept: "EEE",
      requesterYear: "4",
      productName: "Digital Multimeter + Test Probes",
      category: "Lab Equipment",
      quantity: 1,
      urgency: "Important",
      location: "Techpark 2nd floor",
      neededUntil: "5:00 PM",
      reason: "Power Electronics project hardware testing requires continuity & DC current checks.",
      status: "Completed",
      acceptedBy: {
        id: "STU1003",
        name: "Priya Patel",
        department: "ECE",
        phone: "+91 97654 32109",
        location: "Techpark 2nd floor lab"
      },
      pickupDetails: "Received and safely returned with thanks.",
      createdAt: "2026-09-29T14:00:00.000Z"
    }
  ],
  transactions: [
    {
      id: "TXN9001",
      requestId: "REQ1019",
      requesterId: "STU1001",
      requesterName: "Mohamed Irfan N",
      providerId: "STU1002",
      providerName: "Rahul Sharma",
      productName: "Engineering Drafter with Compass",
      category: "Geometry Tools",
      status: "Completed",
      date: "2026-09-28",
      location: "Techpark ground floor",
      notes: "Returned on time in pristine condition."
    },
    {
      id: "TXN9002",
      requestId: "REQ1022",
      requesterId: "STU1004",
      requesterName: "Vikram Reddy",
      providerId: "STU1002",
      providerName: "Rahul Sharma",
      productName: "Engineering Mini Drafter & Board Clips",
      category: "Geometry Tools",
      status: "Accepted",
      date: "2026-09-30",
      location: "Techpark ground floor",
      notes: "In active use. Expected return by 4:00 PM."
    }
  ],
  notifications: [
    {
      id: "NOTIF001",
      userId: "ALL",
      title: "Urgent Calculator Needed",
      message: "Priya Patel (ECE) urgently needs a Scientific Calculator at Main block ground floor.",
      type: "alert",
      unread: true,
      time: "15m ago",
      link: "/request/REQ1021"
    },
    {
      id: "NOTIF002",
      userId: "STU1004",
      title: "Request Accepted!",
      message: "Rahul Sharma accepted your request for Engineering Mini Drafter. Meet at Techpark ground floor lobby.",
      type: "success",
      unread: true,
      time: "1h ago",
      link: "/request/REQ1022"
    }
  ]
};

// Database state management
class CampusXDatabase {
  constructor() {
    this.data = null;
    this.init();
  }

  init() {
    try {
      const dir = path.dirname(DB_FILE);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (fs.existsSync(DB_FILE)) {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        this.data = JSON.parse(fileContent);
      } else {
        this.data = JSON.parse(JSON.stringify(SEED_DATA));
        this.persist();
      }
    } catch (err) {
      console.error('Database load warning, using seed data:', err.message);
      this.data = JSON.parse(JSON.stringify(SEED_DATA));
      this.persist();
    }
  }

  // Crash-safe atomic persistence
  persist() {
    try {
      const tempPath = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.data, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (err) {
      console.error('Failed to persist database:', err.message);
    }
  }

  // ==================== REQUESTS ====================
  getRequests(filters = {}) {
    let list = [...this.data.requests];

    if (filters.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(r =>
        (r.productName && r.productName.toLowerCase().includes(q)) ||
        (r.reason && r.reason.toLowerCase().includes(q)) ||
        (r.location && r.location.toLowerCase().includes(q)) ||
        (r.category && r.category.toLowerCase().includes(q)) ||
        (r.requesterName && r.requesterName.toLowerCase().includes(q)) ||
        (r.id && r.id.toLowerCase().includes(q))
      );
    }

    if (filters.category && filters.category !== 'All') {
      list = list.filter(r => r.category === filters.category);
    }

    if (filters.urgency && filters.urgency !== 'All') {
      list = list.filter(r => r.urgency === filters.urgency);
    }

    if (filters.status && filters.status !== 'All') {
      list = list.filter(r => r.status === filters.status);
    }

    if (filters.requesterId) {
      list = list.filter(r => r.requesterId === filters.requesterId);
    }

    // Sort: Emergency & Urgent first, then newest
    const urgencyWeight = { 'Emergency': 4, 'Urgent': 3, 'Important': 2, 'Normal': 1 };
    list.sort((a, b) => {
      const wA = urgencyWeight[a.urgency] || 0;
      const wB = urgencyWeight[b.urgency] || 0;
      if (wA !== wB) return wB - wA;
      return new Date(b.createdAt) - new Date(a.createdAt);
    });

    return list;
  }

  getRequestById(id) {
    return this.data.requests.find(r => r.id === id) || null;
  }

  createRequest(reqData) {
    const nextNum = 1020 + this.data.requests.length + 1;
    const newId = `REQ${nextNum}`;

    const newRequest = {
      id: newId,
      requesterId: reqData.requesterId || 'STU1001',
      requesterName: reqData.requesterName || 'Student',
      requesterDept: reqData.requesterDept || 'Engineering',
      requesterYear: reqData.requesterYear || '3',
      productName: reqData.productName,
      category: reqData.category || 'Other',
      quantity: parseInt(reqData.quantity, 10) || 1,
      urgency: reqData.urgency || 'Normal',
      location: reqData.location || 'Main block ground floor',
      neededUntil: reqData.neededUntil || 'End of Day',
      reason: reqData.reason || '',
      status: 'Waiting',
      acceptedBy: null,
      pickupDetails: null,
      createdAt: new Date().toISOString()
    };

    this.data.requests.unshift(newRequest);

    // Create campus-wide broadcast notification
    const newNotif = {
      id: `NOTIF${Date.now().toString().slice(-4)}`,
      userId: "ALL",
      title: `Urgent Request: ${newRequest.productName}`,
      message: `${newRequest.requesterName} urgently needs a ${newRequest.productName} at ${newRequest.location}.`,
      type: newRequest.urgency === 'Emergency' ? 'alert' : 'info',
      unread: true,
      time: 'Just now',
      link: `/request/${newId}`
    };
    this.data.notifications.unshift(newNotif);

    this.persist();
    return newRequest;
  }

  acceptRequest(requestId, lenderStudent, pickupDetails) {
    const req = this.data.requests.find(r => r.id === requestId);
    if (!req) throw new Error('Request not found');
    if (req.status !== 'Waiting') throw new Error('Request has already been accepted or closed');

    req.status = 'Accepted';
    req.acceptedBy = {
      id: lenderStudent.id,
      name: lenderStudent.name,
      department: lenderStudent.department,
      phone: lenderStudent.phone,
      location: lenderStudent.location || 'On Campus'
    };
    req.pickupDetails = pickupDetails || `Meet at ${req.location}. Please text/call on arrival.`;

    // Create Audit Transaction Record
    const nextTxnNum = 9000 + this.data.transactions.length + 1;
    const txn = {
      id: `TXN${nextTxnNum}`,
      requestId: req.id,
      requesterId: req.requesterId,
      requesterName: req.requesterName,
      providerId: lenderStudent.id,
      providerName: lenderStudent.name,
      productName: req.productName,
      category: req.category,
      status: 'Accepted',
      date: new Date().toISOString().split('T')[0],
      location: req.location,
      notes: pickupDetails || 'Handshake agreed on campus.'
    };
    this.data.transactions.unshift(txn);

    // Notify the requester
    this.data.notifications.unshift({
      id: `NOTIF${Date.now().toString().slice(-4)}`,
      userId: req.requesterId,
      title: 'Your Request was Accepted! 🎉',
      message: `${lenderStudent.name} (${lenderStudent.phone}) accepted your request for ${req.productName}.`,
      type: 'success',
      unread: true,
      time: 'Just now',
      link: `/request/${req.id}`
    });

    this.persist();
    return req;
  }

  updateRequestStatus(requestId, newStatus, currentUserId) {
    const req = this.data.requests.find(r => r.id === requestId);
    if (!req) throw new Error('Request not found');

    const oldStatus = req.status;
    req.status = newStatus;

    // Update associated transaction
    const txn = this.data.transactions.find(t => t.requestId === requestId);
    if (txn) {
      txn.status = newStatus;
    }

    // Update student stats if completed
    if (newStatus === 'Completed' && oldStatus !== 'Completed') {
      const lender = this.data.students.find(s => s.id === req.acceptedBy?.id);
      if (lender && lender.stats) lender.stats.lent = (lender.stats.lent || 0) + 1;

      const borrower = this.data.students.find(s => s.id === req.requesterId);
      if (borrower && borrower.stats) {
        borrower.stats.borrowed = (borrower.stats.borrowed || 0) + 1;
        borrower.stats.completed = (borrower.stats.completed || 0) + 1;
      }
    }

    this.persist();
    return req;
  }

  // ==================== PRODUCTS ====================
  getProducts(filters = {}) {
    let list = [...this.data.products];

    if (filters.search) {
      const q = filters.search.toLowerCase().trim();
      list = list.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.ownerName.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q)
      );
    }

    if (filters.category && filters.category !== 'All') {
      list = list.filter(p => p.category === filters.category);
    }

    if (filters.available !== undefined) {
      const isAvail = filters.available === 'true' || filters.available === true;
      list = list.filter(p => p.available === isAvail);
    }

    if (filters.ownerId) {
      list = list.filter(p => p.ownerId === filters.ownerId);
    }

    return list;
  }

  getProductById(id) {
    return this.data.products.find(p => p.id === id) || null;
  }

  createProduct(prodData) {
    const nextNum = 100 + this.data.products.length + 1;
    const newProduct = {
      id: `PROD${nextNum}`,
      name: prodData.name,
      category: prodData.category || 'Other',
      description: prodData.description || '',
      condition: prodData.condition || 'Good',
      available: true,
      ownerId: prodData.ownerId || 'STU1001',
      ownerName: prodData.ownerName || 'Student',
      ownerDept: prodData.ownerDept || 'Engineering',
      location: prodData.location || 'Main block ground floor',
      availableTime: prodData.availableTime || '8:30 AM - 5:00 PM',
      quantity: parseInt(prodData.quantity, 10) || 1,
      icon: prodData.icon || 'bi-box-seam',
      image: prodData.image || null
    };

    this.data.products.unshift(newProduct);
    this.persist();
    return newProduct;
  }

  toggleProductAvailability(id) {
    const prod = this.data.products.find(p => p.id === id);
    if (!prod) throw new Error('Product not found');
    prod.available = !prod.available;
    this.persist();
    return prod;
  }

  // ==================== TRANSACTIONS ====================
  getTransactions(filters = {}) {
    let list = [...this.data.transactions];
    if (filters.studentId) {
      list = list.filter(t => t.requesterId === filters.studentId || t.providerId === filters.studentId);
    }
    return list;
  }

  getTransactionById(id) {
    return this.data.transactions.find(t => t.id === id) || null;
  }

  // ==================== NOTIFICATIONS ====================
  getNotifications(userId = 'ALL') {
    return this.data.notifications.filter(n => n.userId === 'ALL' || n.userId === userId);
  }

  markNotificationRead(id) {
    const notif = this.data.notifications.find(n => n.id === id);
    if (notif) {
      notif.unread = false;
      this.persist();
    }
    return notif;
  }

  markAllNotificationsRead(userId) {
    this.data.notifications.forEach(n => {
      if (n.userId === 'ALL' || n.userId === userId) {
        n.unread = false;
      }
    });
    this.persist();
    return true;
  }

  // ==================== STATS ====================
  getStats() {
    const activeRequests = this.data.requests.filter(r => r.status === 'Waiting').length;
    const productsAvailable = this.data.products.filter(p => p.available).length;
    const productsLent = this.data.products.filter(p => !p.available).length + 
                         this.data.requests.filter(r => r.status === 'Accepted').length;
    const completedExchanges = this.data.transactions.filter(t => t.status === 'Completed').length;

    return {
      activeRequests,
      productsAvailable,
      productsLent,
      completedExchanges
    };
  }

  // ==================== AUTH & STUDENTS ====================
  getAllStudents() {
    return this.data.students;
  }

  login(identifier, password) {
    const ident = identifier.toLowerCase().trim();
    const student = this.data.students.find(s => 
      s.id.toLowerCase() === ident || s.email.toLowerCase() === ident
    );

    if (!student) {
      throw new Error('Student ID or College Email not found in campus directory');
    }

    if (password && student.password && student.password !== password) {
      throw new Error('Invalid password. (Demo password is: password123 or 123456)');
    }

    return student;
  }

  register(studentData) {
    const existing = this.data.students.find(s => 
      s.id.toLowerCase() === studentData.id.toLowerCase() || 
      s.email.toLowerCase() === studentData.email.toLowerCase()
    );
    if (existing) {
      throw new Error('Student with this ID or Email is already registered');
    }

    const newStudent = {
      id: studentData.id.toUpperCase(),
      name: studentData.name,
      department: studentData.department,
      year: studentData.year || '1',
      section: studentData.section || 'A',
      email: studentData.email,
      phone: studentData.phone,
      avatar: studentData.avatar || '',
      password: studentData.password || 'password123',
      stats: { lent: 0, borrowed: 0, completed: 0, rating: 5.0 }
    };

    this.data.students.push(newStudent);
    this.persist();
    return newStudent;
  }

  updateProfile(studentId, updateData) {
    const student = this.data.students.find(s => s.id === studentId);
    if (!student) throw new Error('Student not found');

    if (updateData.name) student.name = updateData.name;
    if (updateData.email) student.email = updateData.email;
    if (updateData.phone) student.phone = updateData.phone;
    if (updateData.department) student.department = updateData.department;
    if (updateData.year) student.year = updateData.year;
    if (updateData.section) student.section = updateData.section;

    this.persist();
    return student;
  }

  // ==================== REPORTS & DISPUTES ====================
  createReport(reportData) {
    if (!this.data.reports) this.data.reports = [];

    const newId = `REP${1000 + this.data.reports.length + 1}`;
    const report = {
      id: newId,
      targetUserId: reportData.targetUserId,
      targetUserName: reportData.targetUserName || 'Reported Student',
      reporterId: reportData.reporterId || 'STU1001',
      reporterName: reportData.reporterName || 'Anonymous Student',
      requestId: reportData.requestId || null,
      reason: reportData.reason || 'Exchange Honor Code Violation',
      severity: reportData.severity || 'Medium',
      details: reportData.details || '',
      status: 'Under Review',
      createdAt: new Date().toISOString()
    };

    this.data.reports.unshift(report);

    // Track reported count on target student profile
    const targetStudent = this.data.students.find(s => s.id === reportData.targetUserId);
    if (targetStudent) {
      if (!targetStudent.stats) targetStudent.stats = { lent: 0, borrowed: 0, completed: 0, rating: 5.0 };
      targetStudent.stats.reportedCount = (targetStudent.stats.reportedCount || 0) + 1;
      // Slightly adjust rating
      targetStudent.stats.rating = Math.max(1.0, +(targetStudent.stats.rating - 0.2).toFixed(2));
    }

    // Add alert notification for student
    this.data.notifications.unshift({
      id: `NOTIF${Date.now().toString().slice(-4)}`,
      userId: reportData.reporterId || 'ALL',
      title: `Dispute Registered #${newId}`,
      message: `Your report regarding ${report.targetUserName} has been formally logged and sent to the Campus Exchange Honor Committee.`,
      type: 'alert',
      unread: true,
      time: 'Just now'
    });

    this.persist();
    return report;
  }

  getReports(filters = {}) {
    if (!this.data.reports) this.data.reports = [];
    let list = [...this.data.reports];
    if (filters.targetUserId) list = list.filter(r => r.targetUserId === filters.targetUserId);
    if (filters.reporterId) list = list.filter(r => r.reporterId === filters.reporterId);
    return list;
  }
}

export const db = new CampusXDatabase();
