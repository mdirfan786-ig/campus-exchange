import express from 'express';
import cors from 'cors';
import os from 'os';
import path from 'path';
import { fileURLToPath } from 'url';
import { db } from './db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;

// Universal CORS configuration so any device on the network (phone, tablet, laptop) can connect
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

app.use(express.json());

// Request logger for visibility and diagnostics
app.use((req, res, next) => {
  const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.url} (from ${clientIp})`);
  next();
});

// Helper: Get local network IPv4 address (Wi-Fi / LAN)
function getLocalNetworkIp() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      if (iface.family === 'IPv4' && !iface.internal) {
        return iface.address;
      }
    }
  }
  return 'localhost';
}

const localIp = getLocalNetworkIp();

// ==================== HEALTH & NETWORK DIAGNOSTICS ====================
app.get('/api/health', (req, res) => {
  const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
  res.json({
    status: 'ONLINE',
    system: 'Campus Product Exchange System (CampusX) API',
    version: '1.0.0',
    localIp,
    clientIp,
    uptime: Math.round(process.uptime()),
    timestamp: new Date().toISOString()
  });
});

app.get('/api/network', (req, res) => {
  res.json({
    localUrl: `http://localhost:${PORT}`,
    networkUrl: `http://${localIp}:${PORT}`,
    frontendLocalUrl: `http://localhost:5174`,
    frontendNetworkUrl: `http://${localIp}:5174`,
    localIp,
    serverPort: PORT
  });
});

// ==================== REQUESTS API ====================
// GET /api/requests - Get all requests with optional filters
app.get('/api/requests', (req, res) => {
  try {
    const filters = {
      search: req.query.search,
      category: req.query.category,
      urgency: req.query.urgency,
      status: req.query.status,
      requesterId: req.query.requesterId
    };
    const requests = db.getRequests(filters);
    res.json({ success: true, count: requests.length, data: requests });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/requests/:id - Get single request by ID
app.get('/api/requests/:id', (req, res) => {
  try {
    const request = db.getRequestById(req.params.id);
    if (!request) {
      return res.status(404).json({ success: false, error: 'Request not found' });
    }
    res.json({ success: true, data: request });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/requests - Create new urgent request
app.post('/api/requests', (req, res) => {
  try {
    const { productName, category, quantity, urgency, location, neededUntil, reason, requesterId, requesterName, requesterDept, requesterYear } = req.body;

    if (!productName || !productName.trim()) {
      return res.status(400).json({ success: false, error: 'Product name is required' });
    }

    const newRequest = db.createRequest({
      productName: productName.trim(),
      category,
      quantity,
      urgency,
      location,
      neededUntil,
      reason,
      requesterId,
      requesterName,
      requesterDept,
      requesterYear
    });

    res.status(201).json({ success: true, message: 'Request created successfully', data: newRequest });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/requests/:id/accept - Accept request by a campus lender
app.put('/api/requests/:id/accept', (req, res) => {
  try {
    const { lenderStudent, pickupDetails } = req.body;
    if (!lenderStudent || !lenderStudent.id) {
      return res.status(400).json({ success: false, error: 'Lender student details required' });
    }

    const updated = db.acceptRequest(req.params.id, lenderStudent, pickupDetails);
    res.json({ success: true, message: 'Request accepted successfully', data: updated });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// PUT /api/requests/:id/status - Update request status (Completed, Cancelled, Returned)
app.put('/api/requests/:id/status', (req, res) => {
  try {
    const { status, currentUserId } = req.body;
    if (!status) {
      return res.status(400).json({ success: false, error: 'Status is required' });
    }

    const updated = db.updateRequestStatus(req.params.id, status, currentUserId);
    res.json({ success: true, message: `Request status updated to ${status}`, data: updated });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ==================== PRODUCTS API ====================
// GET /api/products - Get all lending catalog items
app.get('/api/products', (req, res) => {
  try {
    const filters = {
      search: req.query.search,
      category: req.query.category,
      available: req.query.available,
      ownerId: req.query.ownerId
    };
    const products = db.getProducts(filters);
    res.json({ success: true, count: products.length, data: products });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/products/:id - Single product details
app.get('/api/products/:id', (req, res) => {
  try {
    const product = db.getProductById(req.params.id);
    if (!product) {
      return res.status(404).json({ success: false, error: 'Product not found' });
    }
    res.json({ success: true, data: product });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/products - Add product to lend
app.post('/api/products', (req, res) => {
  try {
    const { name, category, description, condition, location, availableTime, quantity, ownerId, ownerName, ownerDept, icon, image } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, error: 'Product name is required' });
    }

    const newProduct = db.createProduct({
      name: name.trim(),
      category,
      description,
      condition,
      location,
      availableTime,
      quantity,
      ownerId,
      ownerName,
      ownerDept,
      icon,
      image
    });

    res.status(201).json({ success: true, message: 'Item added to catalog', data: newProduct });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/products/:id/availability - Toggle available state
app.put('/api/products/:id/availability', (req, res) => {
  try {
    const product = db.toggleProductAvailability(req.params.id);
    res.json({ success: true, message: `Product availability changed to ${product.available}`, data: product });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ==================== TRANSACTIONS API ====================
app.get('/api/transactions', (req, res) => {
  try {
    const filters = { studentId: req.query.studentId };
    const transactions = db.getTransactions(filters);
    res.json({ success: true, count: transactions.length, data: transactions });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/transactions/:id', (req, res) => {
  try {
    const txn = db.getTransactionById(req.params.id);
    if (!txn) return res.status(404).json({ success: false, error: 'Transaction not found' });
    res.json({ success: true, data: txn });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== NOTIFICATIONS API ====================
app.get('/api/notifications', (req, res) => {
  try {
    const userId = req.query.userId || 'ALL';
    const notifications = db.getNotifications(userId);
    const unreadCount = notifications.filter(n => n.unread).length;
    res.json({ success: true, unreadCount, data: notifications });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/notifications/:id/read', (req, res) => {
  try {
    const notif = db.markNotificationRead(req.params.id);
    res.json({ success: true, data: notif });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.put('/api/notifications/read-all', (req, res) => {
  try {
    const userId = req.body.userId || 'ALL';
    db.markAllNotificationsRead(userId);
    res.json({ success: true, message: 'All notifications marked as read' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== STATS API ====================
app.get('/api/stats', (req, res) => {
  try {
    const stats = db.getStats();
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== AUTH & STUDENTS API ====================
app.get('/api/auth/students', (req, res) => {
  try {
    const students = db.getAllStudents();
    res.json({ success: true, data: students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/auth/login', (req, res) => {
  try {
    const { identifier, password } = req.body;
    if (!identifier) {
      return res.status(400).json({ success: false, error: 'Student ID or Email is required' });
    }

    const student = db.login(identifier, password);
    res.json({ success: true, message: 'Login successful', data: student });
  } catch (err) {
    res.status(401).json({ success: false, error: err.message });
  }
});

app.post('/api/auth/register', (req, res) => {
  try {
    const { name, id, email, department, year, section, phone, password } = req.body;
    if (!name || !id || !email) {
      return res.status(400).json({ success: false, error: 'Name, Student ID, and Email are required' });
    }

    const student = db.register({ name, id, email, department, year, section, phone, password });
    res.status(201).json({ success: true, message: 'Student registered successfully', data: student });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.put('/api/auth/profile/:id', (req, res) => {
  try {
    const updated = db.updateProfile(req.params.id, req.body);
    res.json({ success: true, message: 'Profile updated', data: updated });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// ==================== REPORTS & DISPUTES API ====================
app.post('/api/reports', (req, res) => {
  try {
    const { targetUserId, targetUserName, reporterId, reporterName, requestId, reason, severity, details } = req.body;
    if (!targetUserId || !reason) {
      return res.status(400).json({ success: false, error: 'Target student ID and violation reason are required.' });
    }

    const report = db.createReport({
      targetUserId,
      targetUserName,
      reporterId,
      reporterName,
      requestId,
      reason,
      severity,
      details
    });

    res.status(201).json({
      success: true,
      message: 'Report filed successfully and queued for review.',
      data: report
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/reports', (req, res) => {
  try {
    const reports = db.getReports(req.query);
    res.json({ success: true, count: reports.length, data: reports });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ==================== START SERVER ====================
// Listen on 0.0.0.0 so all devices on Wi-Fi / Local Network can access it
app.listen(PORT, '0.0.0.0', () => {
  console.log('\n======================================================');
  console.log('🚀 CampusX Robust Backend API Server Running!');
  console.log('======================================================');
  console.log(`> Local:            http://localhost:${PORT}`);
  console.log(`> All Devices (LAN): http://${localIp}:${PORT}`);
  console.log(`> Health Endpoint:  http://${localIp}:${PORT}/api/health`);
  console.log(`> Network Info:     http://${localIp}:${PORT}/api/network`);
  console.log('======================================================\n');
});
