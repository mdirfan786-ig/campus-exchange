import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const RequestDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { requests, currentUser, acceptRequest, cancelRequest, completeRequest, showToast } = useApp();

  const [showAcceptModal, setShowAcceptModal] = useState(false);
  const [pickupDetails, setPickupDetails] = useState('');
  const [loading, setLoading] = useState(false);

  const request = requests.find((r) => r.id === id);

  if (!request) {
    return (
      <div className="cx-card p-5 text-center">
        <i className="bi bi-exclamation-triangle fs-1 text-warning d-block mb-3"></i>
        <h4 className="fw-bold text-dark">Request Not Found</h4>
        <p className="text-muted small mb-4">The request ID #{id} may have been removed or does not exist.</p>
        <Link to="/my-requests" className="btn btn-primary btn-sm">
          Return to Requests
        </Link>
      </div>
    );
  }

  const isOwner = currentUser && request.requesterId === currentUser.id;
  const canAccept = request.status === 'Waiting' && !isOwner;

  const handleOpenAccept = () => {
    setPickupDetails(`I am in ${currentUser?.department?.slice(0, 3)?.toUpperCase() || 'Campus'} block. Contact: ${currentUser?.phone || '+91 98451 23450'}`);
    setShowAcceptModal(true);
  };

  const handleConfirmAccept = async () => {
    if (!pickupDetails.trim()) {
      showToast('Please provide pickup instructions for the student.', 'warning');
      return;
    }
    try {
      setLoading(true);
      await acceptRequest(request.id, pickupDetails.trim());
      setShowAcceptModal(false);
    } catch (err) {
      showToast(err.message || 'Error accepting request', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async () => {
    if (window.confirm('Are you sure you want to cancel this request?')) {
      await cancelRequest(request.id);
    }
  };

  const handleComplete = async () => {
    if (window.confirm('Confirm that you received the item and have returned it safely?')) {
      await completeRequest(request.id);
    }
  };

  return (
    <div className="container-fluid" style={{ maxWidth: 900 }}>
      {/* Back button */}
      <div className="mb-3">
        <button
          type="button"
          className="btn btn-sm btn-light border text-muted d-inline-flex align-items-center gap-1"
          onClick={() => navigate(-1)}
        >
          <i className="bi bi-arrow-left"></i> Back to Requests
        </button>
      </div>

      {/* Main Request Card */}
      <div className="cx-card bg-white p-4 p-md-5 mb-4">
        {/* Top Header */}
        <div className="d-flex flex-column flex-sm-row justify-content-between align-items-start gap-3 pb-3 border-bottom">
          <div>
            <div className="d-flex align-items-center gap-2 mb-1">
              <span className="badge bg-light text-primary border fw-bold fs-6">
                #{request.id}
              </span>
              <StatusBadge status={request.status} />
            </div>
            <h3 className="fw-bold text-dark mb-0">{request.productName}</h3>
            <span className="text-muted small">
              Category: <strong className="text-secondary">{request.category}</strong>
            </span>
          </div>

          <div className="text-sm-end">
            <StatusBadge status={request.urgency} type="urgency" />
            <div className="text-muted small mt-1">
              Needed by: <span className="fw-semibold text-dark">{request.requiredTime || 'Immediate'}</span>
            </div>
          </div>
        </div>

        {/* Status Callout if Accepted */}
        {request.status === 'Accepted' && (
          <div className="alert alert-success mt-4 p-3 d-flex align-items-start gap-3">
            <i className="bi bi-check-circle-fill fs-4 text-success flex-shrink-0"></i>
            <div>
              <h6 className="fw-bold text-success mb-1">Request Accepted!</h6>
              <p className="small mb-1 text-dark">
                <strong>{request.acceptedBy?.name || 'A student'}</strong> ({request.acceptedBy?.department || 'Campus'}) has accepted to lend this item.
              </p>
              <div className="p-2 bg-white rounded border small mt-2">
                <i className="bi bi-geo-alt-fill text-danger me-1"></i>
                <strong>Pickup Instructions:</strong> {request.pickupDetails || 'Collect at designated room.'}
              </div>
              {request.acceptedBy?.phone && (
                <div className="small text-muted mt-2">
                  <i className="bi bi-telephone-fill text-primary me-1"></i>
                  Lender Contact: <strong>{request.acceptedBy.phone}</strong>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Detailed Grid */}
        <div className="row g-4 mt-2">
          {/* Left Column: Request Details */}
          <div className="col-12 col-md-7">
            <h6 className="fw-bold text-dark border-bottom pb-2 mb-3">
              <i className="bi bi-info-circle text-primary me-2"></i>Request Details
            </h6>

            <div className="row g-3 small">
              <div className="col-6">
                <span className="text-muted d-block">Quantity Needed</span>
                <span className="fw-bold text-dark fs-6">{request.quantity} Unit(s)</span>
              </div>

              <div className="col-6">
                <span className="text-muted d-block">Required Date</span>
                <span className="fw-bold text-dark fs-6">{request.requiredDate || 'Today'}</span>
              </div>

              <div className="col-12">
                <span className="text-muted d-block">Academic Reason</span>
                <span className="fw-medium text-dark">{request.reason}</span>
              </div>

              <div className="col-12">
                <span className="text-muted d-block">Campus Delivery / Pickup Point</span>
                <span className="fw-semibold text-danger">
                  <i className="bi bi-geo-alt-fill me-1"></i>{request.location}
                </span>
              </div>

              {request.description && (
                <div className="col-12">
                  <span className="text-muted d-block">Additional Notes</span>
                  <div className="p-3 bg-light rounded border text-secondary fst-italic">
                    "{request.description}"
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Requester Information */}
          <div className="col-12 col-md-5">
            <div className="p-4 bg-light rounded-3 border h-100">
              <h6 className="fw-bold text-dark mb-3">
                <i className="bi bi-person-badge text-primary me-2"></i>Requester Information
              </h6>

              <div className="d-flex align-items-center gap-3 mb-3">
                <div 
                  className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold fs-5"
                  style={{ width: 48, height: 48 }}
                >
                  {request.requesterName.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <h6 className="fw-bold text-dark mb-0">{request.requesterName}</h6>
                  <span className="text-muted small">{request.requesterId}</span>
                </div>
              </div>

              <div className="small d-flex flex-column gap-2 text-secondary">
                <div>
                  <i className="bi bi-building me-2 text-muted"></i>
                  <strong>Dept:</strong> {request.requesterDept}
                </div>
                <div>
                  <i className="bi bi-mortarboard me-2 text-muted"></i>
                  <strong>Year:</strong> {request.requesterYear || '3'}rd Year
                </div>
                <div>
                  <i className="bi bi-telephone me-2 text-muted"></i>
                  <strong>Phone:</strong> {request.requesterPhone || '+91 98451 23450'}
                </div>
                <div>
                  <i className="bi bi-shield-check me-2 text-success"></i>
                  <strong>Status:</strong> Verified Student
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="mt-4 pt-3 border-top d-flex flex-wrap justify-content-between align-items-center gap-2">
          <div className="text-muted small">
            Created on {new Date(request.createdAt).toLocaleDateString()}
          </div>

          <div className="d-flex gap-2">
            {canAccept && (
              <button
                type="button"
                className="btn btn-success d-flex align-items-center gap-2 shadow-sm px-4"
                onClick={handleOpenAccept}
              >
                <i className="bi bi-hand-thumbs-up-fill"></i>
                <span>Accept Request</span>
              </button>
            )}

            {isOwner && request.status === 'Waiting' && (
              <button
                type="button"
                className="btn btn-outline-danger btn-sm"
                onClick={handleCancel}
              >
                <i className="bi bi-x-circle me-1"></i> Cancel Request
              </button>
            )}

            {isOwner && request.status === 'Accepted' && (
              <button
                type="button"
                className="btn btn-primary d-flex align-items-center gap-2 shadow-sm"
                onClick={handleComplete}
              >
                <i className="bi bi-check2-all"></i>
                <span>Mark as Received & Returned</span>
              </button>
            )}

            <Link to="/products" className="btn btn-outline-secondary btn-sm">
              Explore Available
            </Link>
          </div>
        </div>
      </div>

      {/* Accept Request Confirmation Modal */}
      <Modal
        isOpen={showAcceptModal}
        onClose={() => setShowAcceptModal(false)}
        title="Do you want to provide this product?"
        footer={
          <>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary"
              onClick={() => setShowAcceptModal(false)}
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-sm btn-success d-flex align-items-center gap-1"
              onClick={handleConfirmAccept}
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  <span>Confirming...</span>
                </>
              ) : (
                <>
                  <i className="bi bi-check2-circle"></i>
                  <span>Accept Request</span>
                </>
              )}
            </button>
          </>
        }
      >
        <div>
          <div className="p-3 bg-light rounded-3 border mb-3">
            <div className="small text-muted mb-1">Product to Provide:</div>
            <h5 className="fw-bold text-dark mb-2">{request.productName}</h5>
            
            <div className="small text-secondary mb-1">
              <strong>Requester:</strong> {request.requesterName} ({request.requesterDept})
            </div>
            
            <div className="small text-danger">
              <i className="bi bi-geo-alt-fill me-1"></i>
              <strong>Location:</strong> {request.location}
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">
              Provide Pickup / Meetup Instructions *
            </label>
            <textarea
              className="form-control"
              rows={3}
              placeholder="e.g. I am in Room 204, desk 3. Meet me at the door wearing blue shirt."
              value={pickupDetails}
              onChange={(e) => setPickupDetails(e.target.value)}
              required
            />
            <div className="form-text small">
              The requester will be immediately notified with these details to meet you.
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default RequestDetails;
