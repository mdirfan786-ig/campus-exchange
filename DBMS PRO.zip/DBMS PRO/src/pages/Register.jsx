import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const Register = () => {
  const { register } = useApp();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: '',
    id: '',
    email: '',
    department: 'Computer Science & Engineering',
    year: '2',
    section: 'A',
    phone: '',
    password: '',
    confirmPassword: '',
    termsAgreed: false
  });

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    // Validation
    if (!formData.name.trim() || !formData.id.trim() || !formData.email.trim() || !formData.phone.trim()) {
      setErrorMsg('Please complete all required student identification fields.');
      return;
    }

    if (!formData.email.includes('@') || !formData.email.includes('.')) {
      setErrorMsg('Please enter a valid college email address.');
      return;
    }

    if (formData.password.length < 6) {
      setErrorMsg('Password must be at least 6 characters long.');
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      setErrorMsg('Passwords do not match. Please verify.');
      return;
    }

    if (!formData.termsAgreed) {
      setErrorMsg('You must agree to the Campus Product Exchange Honor Code.');
      return;
    }

    try {
      setLoading(true);
      await register({
        name: formData.name.trim(),
        id: formData.id.trim().toUpperCase(),
        email: formData.email.trim(),
        department: formData.department,
        year: formData.year,
        section: formData.section.toUpperCase(),
        phone: formData.phone.trim(),
        password: formData.password
      });

      navigate('/login');
    } catch (err) {
      setErrorMsg(err.message || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-vh-100 d-flex flex-column justify-content-center bg-light py-5 px-3">
      <div className="container" style={{ maxWidth: 640 }}>
        {/* Brand header */}
        <div className="text-center mb-4">
          <div className="d-inline-flex align-items-center justify-content-center bg-primary text-white rounded-4 p-3 shadow-md mb-3">
            <i className="bi bi-person-plus fs-2"></i>
          </div>
          <h2 className="fw-extrabold text-dark tracking-tight mb-1">Create Student Account</h2>
          <p className="text-muted small">Join CampusX – Share and borrow study tools within campus</p>
        </div>

        {/* Card */}
        <div className="cx-card p-4 p-sm-5 bg-white shadow-md">
          {errorMsg && (
            <div className="alert alert-danger py-2 px-3 small d-flex align-items-center gap-2 mb-4">
              <i className="bi bi-exclamation-circle-fill"></i>
              <div>{errorMsg}</div>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="row g-3">
              {/* Student Name */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Full Name *</label>
                <input
                  type="text"
                  name="name"
                  className="form-control"
                  placeholder="e.g. Arun Kumar"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Student ID */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Student ID / Roll No *</label>
                <input
                  type="text"
                  name="id"
                  className="form-control"
                  placeholder="e.g. STU1005"
                  value={formData.id}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* College Email */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">College Email *</label>
                <input
                  type="email"
                  name="email"
                  className="form-control"
                  placeholder="student@college.edu"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Phone Number */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Phone Number *</label>
                <input
                  type="tel"
                  name="phone"
                  className="form-control"
                  placeholder="+91 98765 43210"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Department */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Department *</label>
                <select
                  name="department"
                  className="form-select"
                  value={formData.department}
                  onChange={handleChange}
                  required
                >
                  <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                  <option value="Information Technology">Information Technology</option>
                  <option value="Mechanical Engineering">Mechanical Engineering</option>
                  <option value="Electronics & Communication">Electronics & Communication</option>
                  <option value="Civil Engineering">Civil Engineering</option>
                  <option value="Electrical Engineering">Electrical Engineering</option>
                  <option value="Biotechnology">Biotechnology</option>
                </select>
              </div>

              {/* Year & Section */}
              <div className="col-6 col-md-3">
                <label className="form-label small fw-semibold text-secondary">Year *</label>
                <select
                  name="year"
                  className="form-select"
                  value={formData.year}
                  onChange={handleChange}
                  required
                >
                  <option value="1">1st Year</option>
                  <option value="2">2nd Year</option>
                  <option value="3">3rd Year</option>
                  <option value="4">4th Year</option>
                </select>
              </div>

              <div className="col-6 col-md-3">
                <label className="form-label small fw-semibold text-secondary">Section *</label>
                <input
                  type="text"
                  name="section"
                  className="form-control"
                  placeholder="A"
                  maxLength={2}
                  value={formData.section}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Password */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Password *</label>
                <input
                  type="password"
                  name="password"
                  className="form-control"
                  placeholder="Min 6 characters"
                  value={formData.password}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Confirm Password */}
              <div className="col-12 col-md-6">
                <label className="form-label small fw-semibold text-secondary">Confirm Password *</label>
                <input
                  type="password"
                  name="confirmPassword"
                  className="form-control"
                  placeholder="Repeat password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  required
                />
              </div>

              {/* Terms & Conditions */}
              <div className="col-12 mt-4">
                <div className="form-check p-3 bg-light rounded border">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    name="termsAgreed"
                    id="termsAgreed"
                    checked={formData.termsAgreed}
                    onChange={handleChange}
                    required
                  />
                  <label className="form-check-label small text-muted ms-2" htmlFor="termsAgreed">
                    I pledge by the <strong>Campus Exchange Honor Code</strong> to return borrowed study tools 
                    promptly and in good condition, and adhere strictly to university campus policies.
                  </label>
                </div>
              </div>

              {/* Submit */}
              <div className="col-12 mt-4">
                <button
                  type="submit"
                  className="btn btn-primary w-100 py-2 fw-semibold d-flex align-items-center justify-content-center gap-2 shadow-sm"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                      <span>Creating Profile...</span>
                    </>
                  ) : (
                    <>
                      <i className="bi bi-check-circle"></i>
                      <span>Complete Registration</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>

          <div className="mt-4 text-center border-top pt-3">
            <p className="text-muted small mb-0">
              Already registered?{' '}
              <Link to="/login" className="text-primary fw-semibold text-decoration-none">
                Sign In here
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;
