import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CAMPUS_LOCATIONS } from '../data/mockData';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const AvailableProducts = () => {
  const { products, currentUser, addProduct, toggleProductAvailability, deleteProduct } = useApp();

  const [showAddModal, setShowAddModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category: 'Stationery',
    description: '',
    condition: 'Excellent',
    location: 'Main block ground floor',
    availableTime: '9:00 AM - 5:00 PM',
    quantity: 1,
    image: '',
    icon: 'bi-box-seam'
  });

  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Products belonging to currently active student
  const myProducts = products.filter(p => !currentUser || p.ownerId === currentUser.id);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleOpenAdd = () => {
    setFormData({
      name: '',
      category: 'Calculators',
      description: '',
      condition: 'Excellent',
      location: 'Main block ground floor',
      availableTime: '8:30 AM - 4:30 PM',
      quantity: 1,
      image: '',
      icon: 'bi-calculator-fill'
    });
    setErrorMsg('');
    setShowAddModal(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!formData.name.trim() || !formData.description.trim()) {
      setErrorMsg('Please enter product title and description.');
      return;
    }

    try {
      setSubmitting(true);
      await addProduct({
        ...formData,
        quantity: Number(formData.quantity) || 1
      });
      setShowAddModal(false);
    } catch (err) {
      setErrorMsg(err.message || 'Failed to add product.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id, name) => {
    if (window.confirm(`Are you sure you want to stop sharing "${name}"?`)) {
      await deleteProduct(id);
    }
  };

  return (
    <div className="d-flex flex-column gap-4">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
          <h3 className="fw-bold text-dark mb-1">Products You Can Share</h3>
          <p className="text-muted small mb-0">
            List study tools and academic devices you own that can help campus peers in emergencies
          </p>
        </div>
        <button
          type="button"
          className="btn btn-primary btn-sm d-flex align-items-center gap-2 shadow-sm"
          onClick={handleOpenAdd}
        >
          <i className="bi bi-plus-circle-fill"></i>
          <span>Add Product to Share</span>
        </button>
      </div>

      {/* Overview Stat Ribbon */}
      <div className="row g-3">
        <div className="col-12 col-md-4">
          <div className="cx-card p-3 d-flex align-items-center justify-content-between">
            <div>
              <p className="text-muted small mb-0">Your Total Shared Items</p>
              <h4 className="fw-bold text-dark mb-0">{myProducts.length}</h4>
            </div>
            <div className="p-3 bg-primary bg-opacity-10 text-primary rounded-3">
              <i className="bi bi-collection-fill fs-4"></i>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div className="cx-card p-3 d-flex align-items-center justify-content-between">
            <div>
              <p className="text-muted small mb-0">Currently Available</p>
              <h4 className="fw-bold text-success mb-0">{myProducts.filter(p => p.available).length}</h4>
            </div>
            <div className="p-3 bg-success bg-opacity-10 text-success rounded-3">
              <i className="bi bi-check-circle-fill fs-4"></i>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div className="cx-card p-3 d-flex align-items-center justify-content-between">
            <div>
              <p className="text-muted small mb-0">Currently Lent Out</p>
              <h4 className="fw-bold text-warning mb-0">{myProducts.filter(p => !p.available).length}</h4>
            </div>
            <div className="p-3 bg-warning bg-opacity-10 text-warning rounded-3">
              <i className="bi bi-clock-history fs-4"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid or Table */}
      <div className="cx-table-container">
        {myProducts.length === 0 ? (
          <div className="p-5 text-center text-muted">
            <i className="bi bi-box-seam fs-1 text-secondary d-block mb-3"></i>
            <h5 className="fw-bold text-dark">No shared products listed yet</h5>
            <p className="small text-muted mb-4" style={{ maxWidth: 440, margin: '0 auto' }}>
              Have an extra calculator, geometry box, lab coat, or charger lying around?
              List it here to help a batchmate in urgent need during practicals!
            </p>
            <button type="button" className="btn btn-primary btn-sm" onClick={handleOpenAdd}>
              <i className="bi bi-plus-lg me-1"></i> Add Your First Item
            </button>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="cx-table table">
              <thead>
                <tr>
                  <th>Product</th>
                  <th>Category</th>
                  <th>Condition</th>
                  <th>Location</th>
                  <th>Available Hours</th>
                  <th>Status</th>
                  <th>Toggle Availability</th>
                  <th className="text-end">Actions</th>
                </tr>
              </thead>
              <tbody>
                {myProducts.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div className="d-flex align-items-center gap-2">
                        <div
                          className="rounded-3 d-flex align-items-center justify-content-center text-dark"
                          style={{ width: 38, height: 38, backgroundColor: '#f4f4f5' }}
                        >
                          <i className={`bi ${p.icon || 'bi-box-seam'} fs-5`}></i>
                        </div>
                        <div>
                          <div className="fw-bold text-dark">{p.name}</div>
                          <div className="text-muted small text-truncate" style={{ maxWidth: 220 }}>
                            {p.description}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span className="badge bg-light text-dark border">{p.category}</span>
                    </td>
                    <td>
                      <span className="badge bg-light text-secondary border">{p.condition}</span>
                    </td>
                    <td>
                      <div className="small text-dark">
                        <i className="bi bi-geo-alt text-danger me-1"></i>
                        {p.location}
                      </div>
                    </td>
                    <td>
                      <span className="small text-muted">{p.availableTime || 'Anytime'}</span>
                    </td>
                    <td>
                      <StatusBadge status={p.available ? 'Available' : 'Lent Out'} />
                    </td>
                    <td>
                      <div className="form-check form-switch mb-0">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          role="switch"
                          checked={p.available}
                          onChange={() => toggleProductAvailability(p.id)}
                          id={`switch-${p.id}`}
                        />
                        <label className="form-check-label small" htmlFor={`switch-${p.id}`}>
                          {p.available ? 'Ready' : 'Lent'}
                        </label>
                      </div>
                    </td>
                    <td className="text-end">
                      <button
                        type="button"
                        className="btn btn-sm btn-outline-danger py-1 px-2"
                        title="Remove from lending"
                        onClick={() => handleDelete(p.id, p.name)}
                      >
                        <i className="bi bi-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add Product Modal */}
      <Modal
        isOpen={showAddModal}
        onClose={() => setShowAddModal(false)}
        title="Add Product to Campus Exchange"
        maxWidth="620px"
        footer={
          <>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary"
              onClick={() => setShowAddModal(false)}
              disabled={submitting}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-sm btn-primary d-flex align-items-center gap-1"
              onClick={handleSubmit}
              disabled={submitting}
            >
              {submitting ? (
                <>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  <span>Adding...</span>
                </>
              ) : (
                <>
                  <i className="bi bi-check-lg"></i>
                  <span>Add Product</span>
                </>
              )}
            </button>
          </>
        }
      >
        {errorMsg && (
          <div className="alert alert-danger py-2 px-3 small d-flex align-items-center gap-2 mb-3">
            <i className="bi bi-exclamation-circle-fill"></i>
            <div>{errorMsg}</div>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="row g-3">
            <div className="col-12 col-md-8">
              <label className="form-label small fw-semibold text-secondary">Product Name *</label>
              <input
                type="text"
                name="name"
                className="form-control"
                placeholder="e.g. Casio Scientific Calculator FX-991CW"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-12 col-md-4">
              <label className="form-label small fw-semibold text-secondary">Category *</label>
              <select
                name="category"
                className="form-select"
                value={formData.category}
                onChange={handleChange}
                required
              >
                {CATEGORIES.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Description *</label>
              <textarea
                name="description"
                className="form-control"
                rows={2}
                placeholder="Details about product model, state, accessories included..."
                value={formData.description}
                onChange={handleChange}
                required
              />
            </div>

            <div className="col-6 col-md-4">
              <label className="form-label small fw-semibold text-secondary">Condition *</label>
              <select
                name="condition"
                className="form-select"
                value={formData.condition}
                onChange={handleChange}
              >
                <option value="Brand New">Brand New</option>
                <option value="Like New">Like New</option>
                <option value="Excellent">Excellent</option>
                <option value="Good">Good</option>
              </select>
            </div>

            <div className="col-6 col-md-4">
              <label className="form-label small fw-semibold text-secondary">Quantity</label>
              <input
                type="number"
                name="quantity"
                className="form-control"
                min="1"
                max="10"
                value={formData.quantity}
                onChange={handleChange}
              />
            </div>

            <div className="col-12 col-md-4">
              <label className="form-label small fw-semibold text-secondary">Available Time</label>
              <input
                type="text"
                name="availableTime"
                className="form-control"
                placeholder="e.g. 9:00 AM - 5:00 PM"
                value={formData.availableTime}
                onChange={handleChange}
              />
            </div>

            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Available Campus Location *</label>
              <select
                name="location"
                className="form-select"
                value={formData.location}
                onChange={handleChange}
              >
                {CAMPUS_LOCATIONS.map(loc => (
                  <option key={loc} value={loc}>{loc}</option>
                ))}
              </select>
            </div>

            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Image URL (Optional)</label>
              <input
                type="url"
                name="image"
                className="form-control"
                placeholder="https://..."
                value={formData.image}
                onChange={handleChange}
              />
              <div className="form-text small">
                Leave empty to automatically use a clean category badge icon.
              </div>
            </div>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default AvailableProducts;
