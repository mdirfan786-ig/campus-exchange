import React, { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const MyRequests = () => {
  const { requests, currentUser, cancelRequest, completeRequest } = useApp();
  const navigate = useNavigate();

  const [filterTab, setFilterTab] = useState('All');
  const [scope, setScope] = useState('mine'); // 'mine' or 'all'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedReqForTracking, setSelectedReqForTracking] = useState(null);

  // Filter requests
  const filteredRequests = useMemo(() => {
    return requests.filter((r) => {
      // Scope filter: my requests vs all campus requests
      if (scope === 'mine' && currentUser) {
        if (r.requesterId !== currentUser.id) return false;
      }

      // Status tab
      if (filterTab !== 'All' && r.status !== filterTab) {
        return false;
      }

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          r.id.toLowerCase().includes(q) ||
          r.productName.toLowerCase().includes(q) ||
          r.location.toLowerCase().includes(q) ||
          r.reason.toLowerCase().includes(q) ||
          r.requesterName.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [requests, currentUser, scope, filterTab, searchQuery]);

  const handleCancel = async (id) => {
    if (window.confirm('Are you sure you want to cancel this request?')) {
      await cancelRequest(id);
    }
  };

  const handleComplete = async (id) => {
    if (window.confirm('Confirm that you have returned this borrowed item to the lender?')) {
      await completeRequest(id);
    }
  };

  return (
    <div className="d-flex flex-column gap-4">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
          <h3 className="fw-bold text-dark mb-1">Campus Product Requests</h3>
          <p className="text-muted small mb-0">
            Track urgent product requests, responses from peers, and pickup updates
          </p>
        </div>
        <Link to="/create-request" className="btn btn-primary btn-sm d-flex align-items-center gap-1 shadow-sm">
          <i className="bi bi-plus-lg"></i>
          <span>New Product Request</span>
        </Link>
      </div>

      {/* Scope Switcher and Search */}
      <div className="cx-card p-3">
        <div className="row g-3 align-items-center justify-content-between">
          <div className="col-12 col-md-6 d-flex gap-2">
            <div className="btn-group" role="group">
              <button
                type="button"
                className={`btn btn-sm ${scope === 'mine' ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setScope('mine')}
              >
                <i className="bi bi-person-fill me-1"></i> My Requests ({requests.filter(r => r.requesterId === currentUser?.id).length})
              </button>
              <button
                type="button"
                className={`btn btn-sm ${scope === 'all' ? 'btn-primary' : 'btn-outline-secondary'}`}
                onClick={() => setScope('all')}
              >
                <i className="bi bi-globe me-1"></i> All Campus Requests ({requests.length})
              </button>
            </div>
          </div>

          <div className="col-12 col-md-4">
            <div className="input-group input-group-sm">
              <span className="input-group-text bg-light text-muted border-end-0">
                <i className="bi bi-search"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0 ps-0"
                placeholder="Search by ID, item, location..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>

        {/* Status filter tabs */}
        <div className="d-flex flex-wrap gap-2 mt-3 pt-2 border-top">
          {['All', 'Waiting', 'Accepted', 'In Progress', 'Completed', 'Cancelled'].map((tab) => {
            const count = requests.filter((r) => {
              if (scope === 'mine' && currentUser && r.requesterId !== currentUser.id) return false;
              if (tab === 'All') return true;
              return r.status === tab;
            }).length;

            return (
              <button
                key={tab}
                type="button"
                className={`btn btn-sm py-1 px-3 rounded-pill ${
                  filterTab === tab ? 'btn-dark' : 'btn-light border'
                }`}
                onClick={() => setFilterTab(tab)}
              >
                {tab} <span className="badge bg-secondary ms-1">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Requests Table */}
      <div className="cx-table-container">
        {filteredRequests.length === 0 ? (
          <div className="p-5 text-center text-muted">
            <i className="bi bi-inbox fs-1 d-block mb-2 text-secondary"></i>
            <h6 className="fw-bold text-dark">No requests found</h6>
            <p className="small mb-3">
              {scope === 'mine'
                ? "You haven't posted any product requests matching this filter."
                : "No active campus requests matching this filter."}
            </p>
            {scope === 'mine' && (
              <Link to="/create-request" className="btn btn-sm btn-primary">
                Create First Request
              </Link>
            )}
          </div>
        ) : (
          <div className="table-responsive">
            <table className="cx-table table">
              <thead>
                <tr>
                  <th>Request ID</th>
                  <th>Product</th>
                  {scope === 'all' && <th>Requested By</th>}
                  <th>Quantity</th>
                  <th>Urgency</th>
                  <th>Location</th>
                  <th>Time / Date</th>
                  <th>Status</th>
                  <th className="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredRequests.map((req) => {
                  const isOwner = currentUser?.id === req.requesterId;
                  return (
                    <tr key={req.id}>
                      <td>
                        <Link to={`/request/${req.id}`} className="fw-bold text-primary text-decoration-none">
                          #{req.id}
                        </Link>
                      </td>
                      <td>
                        <div className="fw-semibold text-dark">{req.productName}</div>
                        <div className="text-muted small text-truncate" style={{ maxWidth: 200 }}>
                          {req.reason}
                        </div>
                      </td>
                      {scope === 'all' && (
                        <td>
                          <div className="small fw-semibold">{req.requesterName}</div>
                          <div className="text-muted small" style={{ fontSize: '0.75rem' }}>{req.requesterDept}</div>
                        </td>
                      )}
                      <td>
                        <span className="badge bg-light text-dark border">
                          {req.quantity} unit
                        </span>
                      </td>
                      <td>
                        <StatusBadge status={req.urgency} type="urgency" />
                      </td>
                      <td>
                        <div className="small text-truncate" style={{ maxWidth: 170 }}>
                          <i className="bi bi-geo-alt-fill text-danger me-1"></i>
                          {req.location}
                        </div>
                      </td>
                      <td>
                        <div className="small text-dark fw-medium">{req.requiredTime || 'Immediate'}</div>
                        <div className="text-muted small" style={{ fontSize: '0.75rem' }}>{req.requiredDate || 'Today'}</div>
                      </td>
                      <td>
                        <StatusBadge status={req.status} />
                      </td>
                      <td className="text-end">
                        <div className="d-flex justify-content-end gap-1">
                          <Link
                            to={`/request/${req.id}`}
                            className="btn btn-sm btn-outline-secondary py-1 px-2"
                            title="View Request Details"
                          >
                            <i className="bi bi-eye"></i>
                          </Link>

                          <button
                            type="button"
                            className="btn btn-sm btn-outline-info text-dark py-1 px-2"
                            title="Track Exchange Status"
                            onClick={() => setSelectedReqForTracking(req)}
                          >
                            <i className="bi bi-signpost-split"></i>
                          </button>

                          {isOwner && req.status === 'Waiting' && (
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-danger py-1 px-2"
                              title="Cancel Request"
                              onClick={() => handleCancel(req.id)}
                            >
                              <i className="bi bi-x-circle"></i>
                            </button>
                          )}

                          {isOwner && req.status === 'Accepted' && (
                            <button
                              type="button"
                              className="btn btn-sm btn-outline-success py-1 px-2"
                              title="Mark as Received & Returned"
                              onClick={() => handleComplete(req.id)}
                            >
                              <i className="bi bi-check2-all"></i>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Track Request Progress Modal */}
      <Modal
        isOpen={!!selectedReqForTracking}
        onClose={() => setSelectedReqForTracking(null)}
        title={`Track Request #${selectedReqForTracking?.id}`}
        footer={
          <button
            type="button"
            className="btn btn-sm btn-primary"
            onClick={() => setSelectedReqForTracking(null)}
          >
            Close
          </button>
        }
      >
        {selectedReqForTracking && (
          <div>
            <div className="mb-4">
              <h5 className="fw-bold text-dark mb-1">{selectedReqForTracking.productName}</h5>
              <p className="text-muted small mb-2">
                Needed at: <strong>{selectedReqForTracking.location}</strong> ({selectedReqForTracking.requiredTime})
              </p>
              <div className="d-flex gap-2">
                <StatusBadge status={selectedReqForTracking.urgency} type="urgency" />
                <StatusBadge status={selectedReqForTracking.status} />
              </div>
            </div>

            {/* Stepper tracker */}
            <div className="d-flex flex-column gap-3 border-start ps-3 ms-2">
              {/* Step 1: Created */}
              <div className="position-relative">
                <span className="position-absolute top-0 start-0 translate-middle-x rounded-circle bg-success text-white p-1 d-flex align-items-center justify-content-center" style={{ width: 22, height: 22, marginLeft: -17 }}>
                  <i className="bi bi-check-lg" style={{ fontSize: '0.7rem' }}></i>
                </span>
                <h6 className="fw-bold text-dark mb-0">1. Request Broadcasted</h6>
                <p className="text-muted small mb-0">
                  Broadcasted across campus network for {selectedReqForTracking.quantity} unit(s).
                </p>
              </div>

              {/* Step 2: Accepted */}
              <div className="position-relative">
                <span className={`position-absolute top-0 start-0 translate-middle-x rounded-circle p-1 d-flex align-items-center justify-content-center text-white ${
                  selectedReqForTracking.status === 'Accepted' || selectedReqForTracking.status === 'In Progress' || selectedReqForTracking.status === 'Completed'
                    ? 'bg-success'
                    : 'bg-secondary'
                }`} style={{ width: 22, height: 22, marginLeft: -17 }}>
                  <i className="bi bi-check-lg" style={{ fontSize: '0.7rem' }}></i>
                </span>
                <h6 className="fw-bold text-dark mb-0">2. Lender Matched & Accepted</h6>
                {selectedReqForTracking.acceptedBy ? (
                  <div className="p-2 bg-light rounded mt-1 border">
                    <p className="mb-1 text-dark fw-semibold small">
                      {selectedReqForTracking.acceptedBy.name} ({selectedReqForTracking.acceptedBy.department})
                    </p>
                    <p className="mb-0 text-muted small">
                      <strong>Pickup:</strong> {selectedReqForTracking.pickupDetails || 'Collect at designated hall'}
                    </p>
                  </div>
                ) : (
                  <p className="text-muted small mb-0">Waiting for a student with this item to accept.</p>
                )}
              </div>

              {/* Step 3: Product Handover */}
              <div className="position-relative">
                <span className={`position-absolute top-0 start-0 translate-middle-x rounded-circle p-1 d-flex align-items-center justify-content-center text-white ${
                  selectedReqForTracking.status === 'Completed'
                    ? 'bg-success'
                    : selectedReqForTracking.status === 'Accepted'
                    ? 'bg-primary'
                    : 'bg-secondary'
                }`} style={{ width: 22, height: 22, marginLeft: -17 }}>
                  <i className="bi bi-check-lg" style={{ fontSize: '0.7rem' }}></i>
                </span>
                <h6 className="fw-bold text-dark mb-0">3. Physical Exchange & Temporary Use</h6>
                <p className="text-muted small mb-0">
                  Item used for exam/lab session and kept in safe condition.
                </p>
              </div>

              {/* Step 4: Returned & Closed */}
              <div className="position-relative">
                <span className={`position-absolute top-0 start-0 translate-middle-x rounded-circle p-1 d-flex align-items-center justify-content-center text-white ${
                  selectedReqForTracking.status === 'Completed' ? 'bg-success' : 'bg-secondary'
                }`} style={{ width: 22, height: 22, marginLeft: -17 }}>
                  <i className="bi bi-check-lg" style={{ fontSize: '0.7rem' }}></i>
                </span>
                <h6 className="fw-bold text-dark mb-0">4. Item Returned & Closed</h6>
                <p className="text-muted small mb-0">
                  Returned to owner and transaction verified completed.
                </p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default MyRequests;
