import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const SAMPLE_SQL_DDL = `-- ============================================================================
-- CAMPUS PRODUCT EXCHANGE SYSTEM (CampusX) - MySQL 8.0 DDL & Relational Schema
-- ============================================================================

CREATE DATABASE IF NOT EXISTS campus_product_exchange;
USE campus_product_exchange;

-- 1. Students Table
CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    department VARCHAR(100) NOT NULL,
    academic_year ENUM('1', '2', '3', '4') NOT NULL DEFAULT '1',
    section VARCHAR(5) NOT NULL DEFAULT 'A',
    college_email VARCHAR(120) NOT NULL UNIQUE,
    phone_number VARCHAR(20) NOT NULL,
    trust_rating DECIMAL(3,2) NOT NULL DEFAULT 5.00,
    total_lent INT UNSIGNED DEFAULT 0,
    total_borrowed INT UNSIGNED DEFAULT 0,
    total_completed INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Master Product Categories
CREATE TABLE product_categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    icon_class VARCHAR(50) DEFAULT 'bi-box-seam'
) ENGINE=InnoDB;

-- 3. Campus Pickup Locations
CREATE TABLE campus_locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    location_name VARCHAR(100) NOT NULL UNIQUE,
    campus_block VARCHAR(50) NOT NULL,
    floor_level VARCHAR(30) DEFAULT 'Ground Floor'
) ENGINE=InnoDB;

-- 4. Products Table (Lending inventory)
CREATE TABLE products (
    product_id VARCHAR(20) PRIMARY KEY,
    owner_id VARCHAR(20) NOT NULL,
    category_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    item_condition ENUM('Brand New', 'Like New', 'Excellent', 'Good') DEFAULT 'Good',
    is_available BOOLEAN DEFAULT TRUE,
    location_id INT NOT NULL,
    quantity INT UNSIGNED DEFAULT 1,
    image_url VARCHAR(255),
    CONSTRAINT fk_prod_owner FOREIGN KEY (owner_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_prod_cat FOREIGN KEY (category_id) REFERENCES product_categories(category_id),
    CONSTRAINT fk_prod_loc FOREIGN KEY (location_id) REFERENCES campus_locations(location_id)
) ENGINE=InnoDB;

-- 5. Product Requests Table (Urgent broadcasts)
CREATE TABLE product_requests (
    request_id VARCHAR(20) PRIMARY KEY,
    requester_id VARCHAR(20) NOT NULL,
    category_id INT NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    quantity INT UNSIGNED DEFAULT 1,
    reason TEXT NOT NULL,
    urgency_level ENUM('Normal', 'Important', 'Urgent', 'Emergency') DEFAULT 'Emergency',
    location_id INT NOT NULL,
    required_date VARCHAR(50) DEFAULT 'Today',
    required_time VARCHAR(50) DEFAULT 'Immediate',
    status ENUM('Waiting', 'Accepted', 'In Progress', 'Completed', 'Cancelled') DEFAULT 'Waiting',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_req_student FOREIGN KEY (requester_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_req_cat FOREIGN KEY (category_id) REFERENCES product_categories(category_id),
    CONSTRAINT fk_req_loc FOREIGN KEY (location_id) REFERENCES campus_locations(location_id)
) ENGINE=InnoDB;

-- 6. Exchanges Table
CREATE TABLE exchanges (
    exchange_id INT AUTO_INCREMENT PRIMARY KEY,
    request_id VARCHAR(20) NOT NULL UNIQUE,
    lender_id VARCHAR(20) NOT NULL,
    borrower_id VARCHAR(20) NOT NULL,
    pickup_instructions TEXT NOT NULL,
    exchange_status ENUM('Accepted', 'Handed Over', 'Returned', 'Cancelled') DEFAULT 'Accepted',
    accepted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    returned_at TIMESTAMP NULL,
    CONSTRAINT fk_exch_req FOREIGN KEY (request_id) REFERENCES product_requests(request_id) ON DELETE CASCADE,
    CONSTRAINT fk_exch_lender FOREIGN KEY (lender_id) REFERENCES students(student_id),
    CONSTRAINT fk_exch_borrower FOREIGN KEY (borrower_id) REFERENCES students(student_id)
) ENGINE=InnoDB;

-- 7. Transactions Table (Audit trail)
CREATE TABLE transactions (
    transaction_id VARCHAR(20) PRIMARY KEY,
    exchange_id INT NOT NULL,
    request_id VARCHAR(20) NOT NULL,
    product_name VARCHAR(150) NOT NULL,
    requester_id VARCHAR(20) NOT NULL,
    provider_id VARCHAR(20) NOT NULL,
    location_id INT NOT NULL,
    transaction_status ENUM('Active', 'Returned', 'Completed', 'Cancelled') DEFAULT 'Active',
    transaction_date DATE NOT NULL,
    notes TEXT,
    CONSTRAINT fk_txn_exchange FOREIGN KEY (exchange_id) REFERENCES exchanges(exchange_id) ON DELETE CASCADE,
    CONSTRAINT fk_txn_req FOREIGN KEY (requester_id) REFERENCES students(student_id),
    CONSTRAINT fk_txn_prov FOREIGN KEY (provider_id) REFERENCES students(student_id),
    CONSTRAINT fk_txn_loc FOREIGN KEY (location_id) REFERENCES campus_locations(location_id)
) ENGINE=InnoDB;`;

const About = () => {
  const { showToast } = useApp();
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'dbms' | 'sql'

  const copySqlToClipboard = () => {
    navigator.clipboard.writeText(SAMPLE_SQL_DDL);
    showToast('MySQL Schema copied to clipboard!', 'success');
  };

  const steps = [
    {
      num: "01",
      title: "Urgent Campus Need",
      desc: "During exams or practical labs, a student suddenly needs a calculator, geometry box, lab coat, or charger.",
      icon: "bi-exclamation-diamond-fill",
      color: "danger"
    },
    {
      num: "02",
      title: "Broadcast Request",
      desc: "Student selects the item, campus location (e.g. Main block ground floor), and urgency level (Emergency/Urgent).",
      icon: "bi-broadcast",
      color: "warning"
    },
    {
      num: "03",
      title: "Nearby Peer Accepts",
      desc: "A nearby student with an available item accepts the request and sends instant pickup coordinates.",
      icon: "bi-hand-thumbs-up-fill",
      color: "primary"
    },
    {
      num: "04",
      title: "Handover & Safe Return",
      desc: "Materials are exchanged, an audit transaction is logged, and items are returned once exams finish.",
      icon: "bi-shield-check",
      color: "success"
    }
  ];

  const dbTables = [
    { name: "students", desc: "Student credentials, roll no, department, trust rating & contact info." },
    { name: "products", desc: "Items registered by students for sharing, condition, availability flag & location." },
    { name: "product_categories", desc: "Master categories (Calculators, Geometry Tools, Lab Equipment, Books, etc.)." },
    { name: "product_requests", desc: "Urgent loan requests with required time, location, urgency & status." },
    { name: "exchanges", desc: "Active handshake between Requester student and Lender student." },
    { name: "transactions", desc: "Historical record of every handover, return verification timestamp & audit." },
    { name: "notifications", desc: "Real-time alerts for broadcast matches, acceptances, and return reminders." },
    { name: "campus_locations", desc: "Campus blocks, exam halls, library floors, and laboratory coordinates." }
  ];

  return (
    <div className="container-fluid" style={{ maxWidth: 1080 }}>
      {/* Hero Header */}
      <div className="cx-card p-4 p-md-5 bg-white mb-4 shadow-sm border-0 border-top border-4 border-primary">
        <span className="badge bg-primary bg-opacity-10 text-primary mb-2 px-3 py-1 fw-semibold">
          CAMPUS RESOURCE SHARING SYSTEM
        </span>
        <h2 className="fw-bold text-dark mb-2">About Campus Product Exchange (CampusX)</h2>
        <p className="text-secondary fs-6 mb-3" style={{ lineHeight: '1.7' }}>
          The <strong>Campus Product Exchange System</strong> enables students to temporarily exchange 
          essential academic study materials within their college campus. Built for urgent exam situations 
          where a student abruptly needs an item that a fellow student can immediately lend.
        </p>

        {/* Tab Navigation */}
        <div className="d-flex flex-wrap gap-2 border-top pt-3 mt-4">
          <button
            type="button"
            className={`btn btn-sm px-3 rounded-pill fw-semibold ${activeTab === 'overview' ? 'btn-primary' : 'btn-light border'}`}
            onClick={() => setActiveTab('overview')}
          >
            <i className="bi bi-info-circle me-1"></i> Project Overview & Workflow
          </button>
          <button
            type="button"
            className={`btn btn-sm px-3 rounded-pill fw-semibold ${activeTab === 'dbms' ? 'btn-primary' : 'btn-light border'}`}
            onClick={() => setActiveTab('dbms')}
          >
            <i className="bi bi-diagram-3 me-1"></i> Relational ER Architecture
          </button>
          <button
            type="button"
            className={`btn btn-sm px-3 rounded-pill fw-semibold ${activeTab === 'sql' ? 'btn-primary' : 'btn-light border'}`}
            onClick={() => setActiveTab('sql')}
          >
            <i className="bi bi-database-fill-gear me-1"></i> MySQL Schema & SQL Queries
          </button>
        </div>
      </div>

      {/* TAB 1: OVERVIEW & WORKFLOW */}
      {activeTab === 'overview' && (
        <div className="d-flex flex-column gap-4">
          {/* 4-Step Visual Workflow */}
          <div className="mb-2">
            <div className="text-center mb-4">
              <h4 className="fw-bold text-dark mb-1">How CampusX Works</h4>
              <p className="text-muted small">From exam hall emergency to safe return in 4 simple steps</p>
            </div>

            <div className="row g-3">
              {steps.map((s) => (
                <div key={s.num} className="col-12 col-sm-6 col-lg-3">
                  <div className="cx-card p-4 h-100 bg-white">
                    <div className="d-flex justify-content-between align-items-center mb-3">
                      <span className="fw-extrabold text-muted" style={{ fontSize: '1.5rem', opacity: 0.5 }}>
                        {s.num}
                      </span>
                      <div className={`p-2 rounded-3 bg-${s.color} bg-opacity-10 text-${s.color}`}>
                        <i className={`bi ${s.icon} fs-5`}></i>
                      </div>
                    </div>
                    <h6 className="fw-bold text-dark mb-2">{s.title}</h6>
                    <p className="text-muted small mb-0" style={{ lineHeight: '1.5' }}>
                      {s.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Academic Items Commonly Shared */}
          <div className="cx-card p-4 p-md-5 bg-white">
            <h4 className="fw-bold text-dark mb-2">Commonly Exchanged Campus Essentials</h4>
            <p className="text-muted small mb-4">
              Authorized study tools supported on CampusX for temporary examination and laboratory use:
            </p>

            <div className="row g-3">
              {[
                { icon: "bi-calculator", title: "Scientific Calculators", desc: "Casio FX-991EX, non-programmable exam approved models." },
                { icon: "bi-rulers", title: "Mini Drafters & T-Squares", desc: "Drawing hall clamps and scale rules for engineering graphics." },
                { icon: "bi-pencil-square", title: "Geometry Sets & Stencils", desc: "Compass boxes, protractors, circle templates, and drawing tools." },
                { icon: "bi-shield-check", title: "Laboratory Coats", desc: "Clean white aprons for chemistry, physics, and bio practicals." },
                { icon: "bi-cpu", title: "Multimeters & Breadboards", desc: "Probes, IC testers, wire strippers for ECE and hardware labs." },
                { icon: "bi-journal-bookmark", title: "Reference Textbooks & Notes", desc: "CLRS algorithms, engineering maths, question banks." },
                { icon: "bi-plug", title: "Chargers & USB Cables", desc: "65W Type-C laptop chargers and high-speed OTG cables." },
                { icon: "bi-trophy", title: "Sports Equipment", desc: "Badminton rackets, table tennis paddles for evening games." }
              ].map((item, idx) => (
                <div key={idx} className="col-12 col-sm-6 col-md-3">
                  <div className="p-3 bg-light rounded-3 border h-100">
                    <div className="text-primary mb-2">
                      <i className={`bi ${item.icon} fs-4`}></i>
                    </div>
                    <h6 className="fw-bold text-dark mb-1 small">{item.title}</h6>
                    <p className="text-muted small mb-0" style={{ fontSize: '0.8rem' }}>
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Honor Code */}
          <div className="cx-card p-4 bg-white border-start border-4 border-success">
            <h5 className="fw-bold text-dark mb-2">
              <i className="bi bi-shield-check text-success me-2"></i>Campus Sharing Honor Code
            </h5>
            <ul className="text-muted small mb-0 d-flex flex-column gap-2 ps-3">
              <li><strong>Punctual Returns:</strong> Return the borrowed item promptly at the agreed time and campus point.</li>
              <li><strong>Careful Handling:</strong> Treat borrowed scientific instruments and calculators with extreme care.</li>
              <li><strong>Zero Commercial Activity:</strong> Strictly peer-to-peer sharing. No fees, renting, or selling allowed.</li>
            </ul>
          </div>
        </div>
      )}

      {/* TAB 2: DBMS & ER RELATIONAL ARCHITECTURE */}
      {activeTab === 'dbms' && (
        <div className="d-flex flex-column gap-4">
          <div className="cx-card p-4 p-md-5 bg-white">
            <div className="d-flex align-items-center justify-content-between mb-3">
              <div>
                <h4 className="fw-bold text-dark mb-1">Relational Database Model</h4>
                <p className="text-muted small mb-0">Entity Relationship Mapping for College DBMS Evaluation</p>
              </div>
              <span className="badge bg-primary px-3 py-2">InnoDB Engine • 3NF Normalized</span>
            </div>

            <div className="row g-3 mt-1">
              {dbTables.map((t) => (
                <div key={t.name} className="col-12 col-md-6">
                  <div className="p-3 bg-light rounded-3 border h-100">
                    <div className="d-flex align-items-center gap-2 mb-1">
                      <i className="bi bi-table text-primary"></i>
                      <strong className="text-dark font-monospace small">TABLE: {t.name}</strong>
                    </div>
                    <p className="text-muted small mb-0">{t.desc}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Relational Flow Cardinality */}
            <div className="mt-4 pt-3 border-top">
              <h6 className="fw-bold text-dark mb-3">Foreign Key Relationships & Cardinality:</h6>
              <div className="d-flex flex-column gap-2 small">
                <div className="p-2 bg-light rounded border font-monospace">
                  <span className="text-primary fw-bold">students</span> (1) ───&lt; (M) <span className="text-primary fw-bold">products</span> [ON DELETE CASCADE]
                </div>
                <div className="p-2 bg-light rounded border font-monospace">
                  <span className="text-primary fw-bold">students</span> (1) ───&lt; (M) <span className="text-primary fw-bold">product_requests</span> [ON DELETE CASCADE]
                </div>
                <div className="p-2 bg-light rounded border font-monospace">
                  <span className="text-primary fw-bold">product_requests</span> (1) ───|| (1) <span className="text-primary fw-bold">exchanges</span> [ON DELETE CASCADE]
                </div>
                <div className="p-2 bg-light rounded border font-monospace">
                  <span className="text-primary fw-bold">exchanges</span> (1) ───|| (1) <span className="text-primary fw-bold">transactions</span> [ON DELETE CASCADE]
                </div>
                <div className="p-2 bg-light rounded border font-monospace">
                  <span className="text-primary fw-bold">campus_locations</span> (1) ───&lt; (M) <span className="text-primary fw-bold">products / requests</span>
                </div>
              </div>
            </div>

            {/* Normalization breakdown */}
            <div className="row g-3 mt-4 pt-3 border-top">
              <div className="col-12 col-md-4">
                <div className="p-3 bg-white rounded border shadow-sm">
                  <h6 className="fw-bold text-primary mb-1">1st Normal Form (1NF)</h6>
                  <p className="text-muted small mb-0">All attributes contain atomic values; explicit primary keys define unique rows.</p>
                </div>
              </div>
              <div className="col-12 col-md-4">
                <div className="p-3 bg-white rounded border shadow-sm">
                  <h6 className="fw-bold text-primary mb-1">2nd Normal Form (2NF)</h6>
                  <p className="text-muted small mb-0">No partial dependencies. All non-prime attributes functionally depend on the primary key.</p>
                </div>
              </div>
              <div className="col-12 col-md-4">
                <div className="p-3 bg-white rounded border shadow-sm">
                  <h6 className="fw-bold text-primary mb-1">3rd Normal Form (3NF)</h6>
                  <p className="text-muted small mb-0">No transitive dependencies. Locations and categories are distinct lookup tables.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MYSQL DDL & VIVA QUERIES */}
      {activeTab === 'sql' && (
        <div className="d-flex flex-column gap-4">
          <div className="cx-card p-4 p-md-5 bg-white">
            <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2 mb-3">
              <div>
                <h4 className="fw-bold text-dark mb-1">MySQL DDL & Database Script</h4>
                <p className="text-muted small mb-0">
                  Ready to execute in MySQL 8.0+, MariaDB, or phpMyAdmin (also saved as <code>campus_product_exchange.sql</code> in root)
                </p>
              </div>
              <button
                type="button"
                className="btn btn-outline-primary btn-sm d-flex align-items-center gap-1"
                onClick={copySqlToClipboard}
              >
                <i className="bi bi-clipboard"></i> Copy SQL
              </button>
            </div>

            {/* SQL Code Block */}
            <pre className="p-3 bg-dark text-light rounded-3 small overflow-auto" style={{ maxHeight: 380, lineHeight: 1.45 }}>
              <code>{SAMPLE_SQL_DDL}</code>
            </pre>

            {/* Essential Viva Queries */}
            <div className="mt-4 pt-3 border-top">
              <h5 className="fw-bold text-dark mb-3">
                <i className="bi bi-question-circle text-primary me-2"></i>Top 5 DBMS Viva Queries & Explanations
              </h5>

              <div className="d-flex flex-column gap-3">
                <div className="p-3 bg-light rounded-3 border">
                  <strong className="text-dark small d-block mb-1">1. Find all active Emergency requests in Main Block with Requester Contacts:</strong>
                  <pre className="bg-white p-2 rounded border small mb-1 text-primary">
                    <code>{`SELECT r.request_id, r.product_name, s.full_name, s.phone_number, l.location_name
FROM product_requests r
JOIN students s ON r.requester_id = s.student_id
JOIN campus_locations l ON r.location_id = l.location_id
WHERE r.status = 'Waiting' AND r.urgency_level = 'Emergency' AND l.campus_block = 'Main Block';`}</code>
                  </pre>
                  <span className="text-muted" style={{ fontSize: '0.78rem' }}>Demonstrates 3-table INNER JOIN with compound WHERE filters.</span>
                </div>

                <div className="p-3 bg-light rounded-3 border">
                  <strong className="text-dark small d-block mb-1">2. Department-wise exchange count and completed returns:</strong>
                  <pre className="bg-white p-2 rounded border small mb-1 text-primary">
                    <code>{`SELECT s.department, COUNT(t.transaction_id) AS total_exchanges,
       SUM(CASE WHEN t.transaction_status = 'Completed' THEN 1 ELSE 0 END) AS completed_returns
FROM students s
JOIN transactions t ON s.student_id = t.requester_id OR s.student_id = t.provider_id
GROUP BY s.department
ORDER BY total_exchanges DESC;`}</code>
                  </pre>
                  <span className="text-muted" style={{ fontSize: '0.78rem' }}>Demonstrates GROUP BY, COUNT, Conditional SUM (CASE WHEN), and ORDER BY.</span>
                </div>

                <div className="p-3 bg-light rounded-3 border">
                  <strong className="text-dark small d-block mb-1">3. Subquery: Students who requested items but never shared any item:</strong>
                  <pre className="bg-white p-2 rounded border small mb-1 text-primary">
                    <code>{`SELECT student_id, full_name, department FROM students
WHERE student_id IN (SELECT DISTINCT requester_id FROM product_requests)
  AND student_id NOT IN (SELECT DISTINCT owner_id FROM products);`}</code>
                  </pre>
                  <span className="text-muted" style={{ fontSize: '0.78rem' }}>Demonstrates Nested Subqueries with IN and NOT IN.</span>
                </div>

                <div className="p-3 bg-light rounded-3 border">
                  <strong className="text-dark small d-block mb-1">4. Most in-demand product categories using HAVING:</strong>
                  <pre className="bg-white p-2 rounded border small mb-1 text-primary">
                    <code>{`SELECT c.category_name, COUNT(r.request_id) AS total_requests, SUM(r.quantity) AS units
FROM product_categories c
JOIN product_requests r ON c.category_id = r.category_id
GROUP BY c.category_id, c.category_name
HAVING COUNT(r.request_id) >= 1
ORDER BY total_requests DESC;`}</code>
                  </pre>
                  <span className="text-muted" style={{ fontSize: '0.78rem' }}>Demonstrates Aggregate grouping with HAVING clause filter.</span>
                </div>

                <div className="p-3 bg-light rounded-3 border">
                  <strong className="text-dark small d-block mb-1">5. Find the student who completed the most successful lends:</strong>
                  <pre className="bg-white p-2 rounded border small mb-1 text-primary">
                    <code>{`SELECT s.student_id, s.full_name, COUNT(e.exchange_id) AS total_lends
FROM students s
JOIN exchanges e ON s.student_id = e.lender_id
WHERE e.exchange_status = 'Returned'
GROUP BY s.student_id, s.full_name
ORDER BY total_lends DESC
LIMIT 1;`}</code>
                  </pre>
                  <span className="text-muted" style={{ fontSize: '0.78rem' }}>Demonstrates Aggregations with LIMIT for leaderboards.</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default About;
