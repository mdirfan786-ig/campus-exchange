import React, { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { CAMPUS_LOCATIONS } from '../data/mockData';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { products, currentUser, toggleProductAvailability, createRequest, showToast } = useApp();

  const [showBorrowModal, setShowBorrowModal] = useState(false);
  const [borrowReason, setBorrowReason] = useState('Urgent lab practical requirement');
  const [borrowLocation, setBorrowLocation] = useState('Main block ground floor');

  const product = products.find((p) => p.id === id);

  if (!product) {
    return (
      <div className="cx-card p-5 text-center">
        <i className="bi bi-box fs-1 text-warning d-block mb-3"></i>
        <h4 className="fw-bold text-dark">Product Not Found</h4>
        <p className="text-muted small mb-4">The item #{id} could not be located in the catalog.</p>
        <Link to="/products" className="btn btn-primary btn-sm">
          Browse All Products
        </Link>
      </div>
    );
  }

  const isOwner = currentUser && product.ownerId === currentUser.id;

  const handleCreateBorrowRequest = async (e) => {
    e.preventDefault();
    try {
      await createRequest({
        productName: product.name,
        category: product.category,
        quantity: 1,
        reason: borrowReason,
        urgency: 'Urgent',
        requiredDate: 'Today',
        requiredTime: 'Now',
        location: borrowLocation,
        description: `Requesting to borrow from ${product.ownerName} (${product.location})`
      });
      setShowBorrowModal(false);
      navigate('/my-requests');
    } catch (err) {
      showToast(err.message || 'Error creating request', 'error');
    }
  };

  return (
    <div className="container-fluid" style={{ maxWidth: 960 }}>
      {/* Back button */}
      <div className="mb-3">
        <button
          type="button"
          className="btn btn-sm btn-light border text-muted d-inline-flex align-items-center gap-1"
          onClick={() => navigate(-1)}
        >
          <i className="bi bi-arrow-left"></i> Back to Products
        </button>
      </div>

      <div className="cx-card bg-white p-4 p-md-5">
        <div className="row g-4">
          {/* Left Column: Product Visual */}
          <div className="col-12 col-md-5">
            <div
              className="rounded-4 overflow-hidden position-relative border"
              style={{ height: 320, backgroundColor: '#f8fafc' }}
            >
              {product.image ? (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-100 h-100"
                  style={{ objectFit: 'cover' }}
                  onError={(e) => {
                    e.target.style.display = 'none';
                    e.target.nextSibling.style.display = 'flex';
                  }}
                />
              ) : null}
              <div
                className="w-100 h-100 d-flex flex-column align-items-center justify-content-center text-primary"
                style={{
                  display: product.image ? 'none' : 'flex',
                  backgroundColor: '#f4f4f5'
                }}
              >
                <i className={`bi ${product.icon || 'bi-box-seam'} fs-1 text-dark`} style={{ fontSize: '4rem', color: '#09090b' }}></i>
                <span className="small text-muted mt-2 fw-medium">{product.category}</span>
              </div>

              <div className="position-absolute top-0 end-0 m-3">
                <StatusBadge status={product.available ? 'Available' : 'Unavailable'} />
              </div>
            </div>

            <div className="mt-3 p-3 bg-light rounded-3 border">
              <div className="d-flex justify-content-between align-items-center small mb-2">
                <span className="text-muted">Item Condition:</span>
                <span className="badge bg-secondary">{product.condition}</span>
              </div>
              <div className="d-flex justify-content-between align-items-center small mb-2">
                <span className="text-muted">Quantity Available:</span>
                <span className="fw-bold text-dark">{product.quantity || 1}</span>
              </div>
              <div className="d-flex justify-content-between align-items-center small">
                <span className="text-muted">Available Hours:</span>
                <span className="fw-medium text-dark">{product.availableTime || 'Anytime'}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Details & Owner info */}
          <div className="col-12 col-md-7 d-flex flex-column">
            <div>
              <span className="badge bg-primary bg-opacity-10 text-primary small px-2 py-1 mb-2">
                {product.category}
              </span>
              <h3 className="fw-bold text-dark mb-2">{product.name}</h3>

              <div className="small text-muted mb-3 d-flex align-items-center gap-2">
                <i className="bi bi-geo-alt-fill text-danger"></i>
                <span className="fw-medium text-dark">{product.location}</span>
              </div>

              <h6 className="fw-bold text-secondary mb-1">Description</h6>
              <p className="text-muted small mb-4" style={{ lineHeight: '1.6' }}>
                {product.description}
              </p>
            </div>

            {/* Owner Card */}
            <div className="p-3 bg-light rounded-3 border mb-4 mt-auto">
              <span className="text-muted small fw-semibold d-block mb-2">Item Owner</span>
              <div className="d-flex align-items-center justify-content-between">
                <div className="d-flex align-items-center gap-2">
                  <div
                    className="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center fw-bold"
                    style={{ width: 36, height: 36, fontSize: '0.85rem' }}
                  >
                    {product.ownerName.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <h6 className="fw-bold text-dark mb-0 small">{product.ownerName}</h6>
                    <span className="text-muted" style={{ fontSize: '0.75rem' }}>
                      {product.ownerDept || 'Campus Student'} • Trust Rating: 4.9 ★
                    </span>
                  </div>
                </div>

                <span className="badge bg-success bg-opacity-10 text-success small">
                  <i className="bi bi-shield-check me-1"></i> Verified
                </span>
              </div>
            </div>

            {/* Actions */}
            <div className="d-flex flex-wrap gap-2 pt-3 border-top">
              {product.available ? (
                <>
                  {!isOwner ? (
                    <button
                      type="button"
                      className="btn btn-primary d-flex align-items-center gap-2 shadow-sm px-4"
                      onClick={() => setShowBorrowModal(true)}
                    >
                      <i className="bi bi-hand-index-thumb-fill"></i>
                      <span>Request to Borrow This Item</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      className="btn btn-warning text-dark d-flex align-items-center gap-2"
                      onClick={() => toggleProductAvailability(product.id)}
                    >
                      <i className="bi bi-pause-circle"></i>
                      <span>Mark as Currently Lent Out</span>
                    </button>
                  )}
                </>
              ) : (
                <div className="w-100">
                  <div className="alert alert-secondary py-2 px-3 small d-flex align-items-center gap-2 mb-2">
                    <i className="bi bi-info-circle-fill"></i>
                    <span>This item is currently lent out to another student.</span>
                  </div>
                  {isOwner && (
                    <button
                      type="button"
                      className="btn btn-sm btn-success d-flex align-items-center gap-1"
                      onClick={() => toggleProductAvailability(product.id)}
                    >
                      <i className="bi bi-check-circle"></i>
                      <span>Mark Available Again</span>
                    </button>
                  )}
                </div>
              )}

              <Link to="/products" className="btn btn-outline-secondary">
                View Other Items
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Borrow Request Modal */}
      <Modal
        isOpen={showBorrowModal}
        onClose={() => setShowBorrowModal(false)}
        title={`Borrow Request for ${product.name}`}
        footer={
          <>
            <button
              type="button"
              className="btn btn-sm btn-outline-secondary"
              onClick={() => setShowBorrowModal(false)}
            >
              Cancel
            </button>
            <button
              type="button"
              className="btn btn-sm btn-primary"
              onClick={handleCreateBorrowRequest}
            >
              Send Request to {product.ownerName}
            </button>
          </>
        }
      >
        <form onSubmit={handleCreateBorrowRequest}>
          <div className="p-3 bg-light rounded border mb-3">
            <h6 className="fw-bold text-dark mb-1">{product.name}</h6>
            <div className="small text-muted">
              Owner: <strong>{product.ownerName}</strong> at <strong>{product.location}</strong>
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">
              Why do you need this item? *
            </label>
            <input
              type="text"
              className="form-control"
              value={borrowReason}
              onChange={(e) => setBorrowReason(e.target.value)}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">
              Where can you meet for pickup? *
            </label>
            <select
              className="form-select"
              value={borrowLocation}
              onChange={(e) => setBorrowLocation(e.target.value)}
              required
            >
              {CAMPUS_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default ProductDetails;
