import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const Notifications = () => {
  const { notifications, markNotificationRead, markAllNotificationsRead, currentUser } = useApp();
  const [filter, setFilter] = useState('all'); // 'all' or 'unread'

  const userNotifications = notifications.filter(
    (n) => !currentUser || n.userId === currentUser.id || n.userId === 'ALL'
  );

  const displayed = userNotifications.filter((n) => {
    if (filter === 'unread') return n.unread;
    return true;
  });

  const getIcon = (type) => {
    switch (type) {
      case 'success':
        return 'bi-check-circle-fill text-success';
      case 'alert':
        return 'bi-lightning-charge-fill text-danger';
      case 'warning':
        return 'bi-clock-fill text-warning';
      case 'info':
      default:
        return 'bi-info-circle-fill text-primary';
    }
  };

  return (
    <div className="container-fluid" style={{ maxWidth: 880 }}>
      {/* Header */}
      <div className="d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-3 mb-4">
        <div>
          <h3 className="fw-bold text-dark mb-1">Campus Notifications</h3>
          <p className="text-muted small mb-0">
            Real-time updates regarding your product requests, peer acceptances, and exchange returns
          </p>
        </div>

        <div className="d-flex gap-2">
          <button
            type="button"
            className="btn btn-outline-secondary btn-sm"
            onClick={markAllNotificationsRead}
          >
            <i className="bi bi-check2-all me-1"></i> Mark All as Read
          </button>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="d-flex gap-2 mb-3">
        <button
          type="button"
          className={`btn btn-sm px-3 rounded-pill ${filter === 'all' ? 'btn-primary' : 'btn-light border'}`}
          onClick={() => setFilter('all')}
        >
          All ({userNotifications.length})
        </button>
        <button
          type="button"
          className={`btn btn-sm px-3 rounded-pill ${filter === 'unread' ? 'btn-primary' : 'btn-light border'}`}
          onClick={() => setFilter('unread')}
        >
          Unread ({userNotifications.filter(n => n.unread).length})
        </button>
      </div>

      {/* Notification List */}
      <div className="d-flex flex-column gap-2">
        {displayed.length === 0 ? (
          <div className="cx-card p-5 text-center text-muted">
            <i className="bi bi-bell-slash fs-1 text-secondary d-block mb-3"></i>
            <h5 className="fw-bold text-dark">No notifications to display</h5>
            <p className="small text-muted mb-0">You are all caught up with campus product exchange events!</p>
          </div>
        ) : (
          displayed.map((n) => (
            <div
              key={n.id}
              className={`cx-card p-3 d-flex align-items-start gap-3 transition-hover ${
                n.unread ? 'border-primary border-opacity-50 bg-white' : 'bg-light bg-opacity-50'
              }`}
              style={{ cursor: 'pointer' }}
              onClick={() => markNotificationRead(n.id)}
            >
              <div
                className={`rounded-circle d-flex align-items-center justify-content-center p-2 flex-shrink-0 ${n.unread ? 'bg-black text-white' : 'text-dark'}`}
                style={{
                  width: 44,
                  height: 44,
                  backgroundColor: n.unread ? '#000000' : '#f4f4f5'
                }}
              >
                <i className={`bi ${getIcon(n.type)} fs-5`}></i>
              </div>

              <div className="flex-grow-1">
                <div className="d-flex justify-content-between align-items-center mb-1">
                  <h6 className={`mb-0 small fw-bold ${n.unread ? 'text-dark' : 'text-secondary'}`}>
                    {n.title}
                  </h6>
                  <span className="text-muted small" style={{ fontSize: '0.72rem' }}>
                    {n.time}
                  </span>
                </div>

                <p className="text-muted small mb-2">{n.message}</p>

                {n.link && (
                  <Link
                    to={n.link}
                    className="btn btn-sm btn-outline-primary py-0 px-2 fw-medium"
                    style={{ fontSize: '0.78rem' }}
                    onClick={(e) => {
                      e.stopPropagation();
                      markNotificationRead(n.id);
                    }}
                  >
                    View Details <i className="bi bi-arrow-right"></i>
                  </Link>
                )}
              </div>

              {n.unread && (
                <span
                  className="rounded-circle bg-primary flex-shrink-0 mt-1"
                  style={{ width: 8, height: 8 }}
                  title="Unread"
                ></span>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default Notifications;
