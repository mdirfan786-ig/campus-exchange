import React, { useState, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CAMPUS_LOCATIONS } from '../data/mockData';
import ProductCard from '../components/ProductCard';

const CONDITIONS = ['All', 'Brand New', 'Like New', 'Excellent', 'Good'];

const BrowseProducts = () => {
  const { products, currentUser, toggleProductAvailability } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();

  // Filter state
  const [searchTerm, setSearchTerm] = useState(searchParams.get('search') || '');
  const [selectedCategory, setSelectedCategory] = useState(searchParams.get('category') || 'All');
  const [selectedAvailability, setSelectedAvailability] = useState('All');
  const [selectedLocation, setSelectedLocation] = useState('All');
  const [selectedCondition, setSelectedCondition] = useState('All');

  // Filter logic
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Search
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matches =
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query) ||
          p.location.toLowerCase().includes(query) ||
          p.ownerName.toLowerCase().includes(query);
        if (!matches) return false;
      }

      // Category
      if (selectedCategory !== 'All' && p.category !== selectedCategory) {
        return false;
      }

      // Availability
      if (selectedAvailability === 'Available' && !p.available) return false;
      if (selectedAvailability === 'Lent Out' && p.available) return false;

      // Location
      if (selectedLocation !== 'All' && !p.location.includes(selectedLocation)) {
        return false;
      }

      // Condition
      if (selectedCondition !== 'All' && p.condition !== selectedCondition) {
        return false;
      }

      return true;
    });
  }, [products, searchTerm, selectedCategory, selectedAvailability, selectedLocation, selectedCondition]);

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedCategory('All');
    setSelectedAvailability('All');
    setSelectedLocation('All');
    setSelectedCondition('All');
    setSearchParams({});
  };

  return (
    <div className="d-flex flex-column gap-4">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
          <h3 className="fw-bold text-dark mb-1">Browse Shared Products</h3>
          <p className="text-muted small mb-0">
            Discover study materials, lab instruments, calculators, and electronics available from campus peers
          </p>
        </div>
        <div className="d-flex gap-2">
          <Link to="/available-products" className="btn btn-outline-primary btn-sm d-flex align-items-center gap-1">
            <i className="bi bi-box-seam"></i>
            <span>Share My Item</span>
          </Link>
          <Link to="/create-request" className="btn btn-primary btn-sm d-flex align-items-center gap-1">
            <i className="bi bi-lightning-charge-fill"></i>
            <span>Request Item</span>
          </Link>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="cx-filter-bar">
        <div className="row g-2 align-items-center">
          {/* Search */}
          <div className="col-12 col-md-4">
            <div className="input-group">
              <span className="input-group-text bg-light text-muted border-end-0">
                <i className="bi bi-search"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0 ps-0"
                placeholder="Search products (e.g. calculator, pen, Drafter)..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              {searchTerm && (
                <button
                  type="button"
                  className="btn btn-light border text-muted"
                  onClick={() => setSearchTerm('')}
                >
                  <i className="bi bi-x"></i>
                </button>
              )}
            </div>
          </div>

          {/* Category Filter */}
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Availability Filter */}
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={selectedAvailability}
              onChange={(e) => setSelectedAvailability(e.target.value)}
            >
              <option value="All">All Statuses</option>
              <option value="Available">Available Now</option>
              <option value="Lent Out">Currently Lent</option>
            </select>
          </div>

          {/* Condition Filter */}
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={selectedCondition}
              onChange={(e) => setSelectedCondition(e.target.value)}
            >
              {CONDITIONS.map((cond) => (
                <option key={cond} value={cond}>
                  {cond === 'All' ? 'All Conditions' : cond}
                </option>
              ))}
            </select>
          </div>

          {/* Location Filter */}
          <div className="col-6 col-md-2">
            <select
              className="form-select"
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
            >
              <option value="All">All Locations</option>
              {CAMPUS_LOCATIONS.map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Active Category Badges Pills */}
        <div className="d-flex flex-wrap gap-1 mt-3 pt-2 border-top">
          <button
            type="button"
            className={`btn btn-sm py-1 px-3 rounded-pill ${
              selectedCategory === 'All' ? 'btn-primary' : 'btn-light border'
            }`}
            onClick={() => setSelectedCategory('All')}
          >
            All Items ({products.length})
          </button>
          {CATEGORIES.map((cat) => {
            const count = products.filter((p) => p.category === cat).length;
            return (
              <button
                key={cat}
                type="button"
                className={`btn btn-sm py-1 px-3 rounded-pill ${
                  selectedCategory === cat ? 'btn-primary' : 'btn-light border'
                }`}
                onClick={() => setSelectedCategory(cat)}
              >
                {cat} ({count})
              </button>
            );
          })}

          {(searchTerm || selectedCategory !== 'All' || selectedAvailability !== 'All' || selectedCondition !== 'All' || selectedLocation !== 'All') && (
            <button
              type="button"
              className="btn btn-sm btn-outline-danger py-1 px-3 rounded-pill ms-auto"
              onClick={clearFilters}
            >
              <i className="bi bi-arrow-counterclockwise me-1"></i> Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* Product Results Grid */}
      <div>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <span className="text-muted small fw-medium">
            Showing <strong className="text-dark">{filteredProducts.length}</strong> products
          </span>
        </div>

        {filteredProducts.length === 0 ? (
          <div className="cx-card p-5 text-center">
            <div className="d-inline-flex p-3 rounded-circle bg-light text-muted mb-3 fs-1">
              <i className="bi bi-search"></i>
            </div>
            <h5 className="fw-bold text-dark">No products found</h5>
            <p className="text-muted small mb-4" style={{ maxWidth: 460, margin: '0 auto' }}>
              We couldn't find any shared products matching your current filters or query.
              You can create an urgent request for this item!
            </p>
            <div className="d-flex justify-content-center gap-2">
              <button type="button" className="btn btn-sm btn-outline-secondary" onClick={clearFilters}>
                Clear All Filters
              </button>
              <Link to="/create-request" className="btn btn-sm btn-primary">
                <i className="bi bi-lightning-charge-fill me-1"></i> Request This Item
              </Link>
            </div>
          </div>
        ) : (
          <div className="row g-3">
            {filteredProducts.map((product) => (
              <div key={product.id} className="col-12 col-sm-6 col-lg-4 col-xl-3">
                <ProductCard
                  product={product}
                  isOwner={currentUser?.id === product.ownerId}
                  onToggleAvailability={toggleProductAvailability}
                />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BrowseProducts;
