import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { CATEGORIES, CAMPUS_LOCATIONS, URGENCY_LEVELS } from '../data/mockData';

const CreateRequest = () => {
  const { createRequest, currentUser } = useApp();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    productName: '',
    category: 'Calculators',
    quantity: 1,
    reason: '',
    urgency: 'Emergency',
    requiredDate: 'Today',
    requiredTime: '10:00 AM',
    location: 'Main block ground floor',
    customLocation: '',
    description: ''
  });

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleQuickPreset = (presetName, cat, urg, loc, rsn) => {
    setFormData((prev) => ({
      ...prev,
      productName: presetName,
      category: cat,
      urgency: urg,
      location: loc,
      reason: rsn
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    // Validation
    if (!formData.productName.trim()) {
      setErrorMsg('Please enter the name of the product you need.');
      return;
    }

    if (!formData.reason.trim()) {
      setErrorMsg('Please specify the academic reason (e.g. Exam, Lab, Viva).');
      return;
    }

    if (Number(formData.quantity) <= 0) {
      setErrorMsg('Quantity must be at least 1.');
      return;
    }

    const finalLocation = formData.location === 'Other Location' && formData.customLocation.trim()
      ? formData.customLocation.trim()
      : formData.location;

    try {
      setLoading(true);
      await createRequest({
        productName: formData.productName.trim(),
        category: formData.category,
        quantity: Number(formData.quantity),
        reason: formData.reason.trim(),
        urgency: formData.urgency,
        requiredDate: formData.requiredDate,
        requiredTime: formData.requiredTime,
        location: finalLocation,
        description: formData.description.trim()
      });

      // Redirect to My Requests
      navigate('/my-requests');
    } catch (err) {
      setErrorMsg(err.message || 'Failed to submit request.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container-fluid" style={{ maxWidth: 880 }}>
      {/* Header */}
      <div className="mb-4">
        <span className="badge bg-danger bg-opacity-10 text-danger mb-2 px-3 py-1 fw-semibold">
          <i className="bi bi-broadcast me-1"></i> Urgent Campus Broadcast
        </span>
        <h3 className="fw-bold text-dark mb-1">Create Product Request</h3>
        <p className="text-muted small mb-0">
          Broadcast your urgent equipment or material need to fellow students across your campus.
        </p>
      </div>

      {/* Preset Quick Fill Pills */}
      <div className="cx-card p-3 mb-4 bg-light">
        <span className="small fw-semibold text-secondary d-block mb-2">
          ⚡ Quick Exam & Practical Presets:
        </span>
        <div className="d-flex flex-wrap gap-2">
          <button
            type="button"
            className="btn btn-sm btn-outline-danger py-1 px-2"
            style={{ fontSize: '0.78rem' }}
            onClick={() =>
              handleQuickPreset(
                'Scientific Calculator (FX-991)',
                'Calculators',
                'Emergency',
                'Main block ground floor',
                'Maths Semester Examination starting in 15 mins'
              )
            }
          >
            Scientific Calculator
          </button>

          <button
            type="button"
            className="btn btn-sm btn-outline-warning text-dark py-1 px-2"
            style={{ fontSize: '0.78rem' }}
            onClick={() =>
              handleQuickPreset(
                'Mini Drafter with Metal Clamp',
                'Geometry Tools',
                'Urgent',
                'Techpark ground floor',
                'Machine Drawing Lab Assessment'
              )
            }
          >
            Engineering Drafter
          </button>

          <button
            type="button"
            className="btn btn-sm btn-outline-primary py-1 px-2"
            style={{ fontSize: '0.78rem' }}
            onClick={() =>
              handleQuickPreset(
                'White Chemistry Lab Coat',
                'Lab Equipment',
                'Important',
                'Academic block ground floor',
                'Forgot coat in hostel before organic synthesis lab'
              )
            }
          >
            Lab Coat
          </button>

          <button
            type="button"
            className="btn btn-sm btn-outline-info text-dark py-1 px-2"
            style={{ fontSize: '0.78rem' }}
            onClick={() =>
              handleQuickPreset(
                '65W Type-C Laptop Charger',
                'Electronics',
                'Emergency',
                'Techpark 1st floor',
                'Laptop died before seminar slide presentation'
              )
            }
          >
            Laptop Charger
          </button>
        </div>
      </div>

      {/* Form Card */}
      <div className="cx-card p-4 p-md-5 bg-white shadow-sm">
        {errorMsg && (
          <div className="alert alert-danger py-2 px-3 small d-flex align-items-center gap-2 mb-4">
            <i className="bi bi-exclamation-circle-fill"></i>
            <div>{errorMsg}</div>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="row g-3">
            {/* Product Name */}
            <div className="col-12 col-md-8">
              <label className="form-label small fw-semibold text-secondary">Product Name *</label>
              <input
                type="text"
                name="productName"
                className="form-control"
                placeholder="e.g. Casio Calculator, Engineering Drafter, Multimeter, Lab Coat"
                value={formData.productName}
                onChange={handleChange}
                required
              />
            </div>

            {/* Category */}
            <div className="col-12 col-md-4">
              <label className="form-label small fw-semibold text-secondary">Category *</label>
              <select
                name="category"
                className="form-select"
                value={formData.category}
                onChange={handleChange}
                required
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* Quantity */}
            <div className="col-6 col-md-3">
              <label className="form-label small fw-semibold text-secondary">Quantity Needed *</label>
              <input
                type="number"
                name="quantity"
                className="form-control"
                min="1"
                max="10"
                value={formData.quantity}
                onChange={handleChange}
                required
              />
            </div>

            {/* Urgency Level */}
            <div className="col-6 col-md-5">
              <label className="form-label small fw-semibold text-secondary">Urgency Level *</label>
              <select
                name="urgency"
                className="form-select fw-semibold"
                value={formData.urgency}
                onChange={handleChange}
                required
              >
                {URGENCY_LEVELS.map((u) => (
                  <option key={u.level} value={u.level}>
                    {u.level} – {u.desc}
                  </option>
                ))}
              </select>
            </div>

            {/* Required Date & Time */}
            <div className="col-6 col-md-2">
              <label className="form-label small fw-semibold text-secondary">Required Date</label>
              <input
                type="text"
                name="requiredDate"
                className="form-control"
                placeholder="Today"
                value={formData.requiredDate}
                onChange={handleChange}
              />
            </div>

            <div className="col-6 col-md-2">
              <label className="form-label small fw-semibold text-secondary">Required Time</label>
              <input
                type="text"
                name="requiredTime"
                className="form-control"
                placeholder="10:00 AM"
                value={formData.requiredTime}
                onChange={handleChange}
              />
            </div>

            {/* Reason */}
            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Academic Reason *</label>
              <input
                type="text"
                name="reason"
                className="form-control"
                placeholder="e.g. Calculus-II University Examination / VLSI Practical Test"
                value={formData.reason}
                onChange={handleChange}
                required
              />
            </div>

            {/* Location */}
            <div className="col-12 col-md-7">
              <label className="form-label small fw-semibold text-secondary">Campus Pickup Location *</label>
              <select
                name="location"
                className="form-select"
                value={formData.location}
                onChange={handleChange}
                required
              >
                {CAMPUS_LOCATIONS.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
                <option value="Other Location">Other Campus Location (Type Below)</option>
              </select>
            </div>

            {formData.location === 'Other Location' && (
              <div className="col-12 col-md-5">
                <label className="form-label small fw-semibold text-secondary">Specific Location *</label>
                <input
                  type="text"
                  name="customLocation"
                  className="form-control"
                  placeholder="e.g. Biotech Block, Room 104"
                  value={formData.customLocation}
                  onChange={handleChange}
                  required
                />
              </div>
            )}

            {/* Additional Description */}
            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">
                Additional Instructions / Notes
              </label>
              <textarea
                name="description"
                className="form-control"
                rows={3}
                placeholder="e.g. Will return immediately at 1:15 PM once examination finishes. Can meet in lobby."
                value={formData.description}
                onChange={handleChange}
              />
              <div className="form-text small">
                Help other students locate and contact you quickly.
              </div>
            </div>

            {/* Action Buttons */}
            <div className="col-12 mt-4 pt-3 border-top d-flex justify-content-end gap-3">
              <button
                type="button"
                className="btn btn-outline-secondary px-4"
                onClick={() => navigate(-1)}
              >
                Cancel
              </button>

              <button
                type="submit"
                className="btn btn-primary px-4 fw-semibold d-flex align-items-center gap-2 shadow-sm"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                    <span>Broadcasting...</span>
                  </>
                ) : (
                  <>
                    <i className="bi bi-send-fill"></i>
                    <span>Submit Request</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateRequest;
