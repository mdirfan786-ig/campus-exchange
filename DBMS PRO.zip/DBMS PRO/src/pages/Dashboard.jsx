import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import RequestCard from '../components/RequestCard';
import ProductCard from '../components/ProductCard';
import Modal from '../components/Modal';

const Dashboard = () => {
  const { currentUser, requests, products, stats, acceptRequest, showToast } = useApp();
  const navigate = useNavigate();

  // Accept modal state
  const [selectedRequest, setSelectedRequest] = useState(null);
  const [pickupDetails, setPickupDetails] = useState('');
  const [accepting, setAccepting] = useState(false);

  const openAcceptModal = (req) => {
    setSelectedRequest(req);
    setPickupDetails(`I am at ${currentUser?.department?.slice(0, 3)?.toUpperCase() || 'Campus'} block lobby. Call/text me.`);
  };

  const closeAcceptModal = () => {
    setSelectedRequest(null);
    setPickupDetails('');
  };

  const handleConfirmAccept = async () => {
    if (!selectedRequest) return;
    try {
      setAccepting(true);
      await acceptRequest(selectedRequest.id, pickupDetails);
      closeAcceptModal();
    } catch (err) {
      showToast(err.message || "Failed to accept request", "error");
    } finally {
      setAccepting(false);
    }
  };

  const recentRequests = requests.slice(0, 4);
  const featuredProducts = products.filter(p => p.available).slice(0, 4);

  return (
    <div className="d-flex flex-column gap-4">
      {/* Welcome & Urgency Hero Banner */}
      <div className="urgency-banner d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
        <div>
          <span className="badge bg-white bg-opacity-25 text-white mb-2 px-3 py-1 fw-normal rounded-pill">
            <i className="bi bi-geo-fill me-1 text-white"></i> Campus Active Network
          </span>
          <h2 className="fw-bold mb-1 text-white">
            Welcome, {currentUser ? currentUser.name.split(' ').slice(0, 2).join(' ') : 'Student'} 👋
          </h2>
          <p className="text-white-50 mb-0 fs-6">
            Need something urgently for exam or lab? Request it from your campus mates.
          </p>
        </div>

        <div className="d-flex flex-wrap gap-2">
          <Link to="/create-request" className="btn btn-light text-dark fw-bold d-flex align-items-center gap-2 shadow-sm">
            <i className="bi bi-lightning-charge-fill"></i>
            <span>Request a Product</span>
          </Link>
          <Link to="/products" className="btn btn-outline-light d-flex align-items-center gap-2">
            <i className="bi bi-grid"></i>
            <span>Browse Catalog</span>
          </Link>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="row g-3">
        <div className="col-6 col-lg-3">
          <div className="cx-stat-card">
            <div>
              <p className="text-muted small fw-semibold mb-1">Active Requests</p>
              <h3 className="fw-bold text-dark mb-0">{stats.activeRequests}</h3>
              <span className="small text-muted fw-medium" style={{ fontSize: '0.72rem' }}>
                <i className="bi bi-clock-fill me-1"></i> Waiting help
              </span>
            </div>
            <div className="cx-stat-icon-wrap">
              <i className="bi bi-broadcast"></i>
            </div>
          </div>
        </div>

        <div className="col-6 col-lg-3">
          <div className="cx-stat-card">
            <div>
              <p className="text-muted small fw-semibold mb-1">Products Available</p>
              <h3 className="fw-bold text-dark mb-0">{stats.productsAvailable}</h3>
              <span className="small text-muted fw-medium" style={{ fontSize: '0.72rem' }}>
                <i className="bi bi-check-circle-fill me-1"></i> Ready to borrow
              </span>
            </div>
            <div className="cx-stat-icon-wrap">
              <i className="bi bi-box-seam-fill"></i>
            </div>
          </div>
        </div>

        <div className="col-6 col-lg-3">
          <div className="cx-stat-card">
            <div>
              <p className="text-muted small fw-semibold mb-1">Products Lent</p>
              <h3 className="fw-bold text-dark mb-0">{stats.productsLent}</h3>
              <span className="small text-muted fw-medium" style={{ fontSize: '0.72rem' }}>
                <i className="bi bi-arrow-left-right me-1"></i> In active use
              </span>
            </div>
            <div className="cx-stat-icon-wrap">
              <i className="bi bi-arrow-repeat"></i>
            </div>
          </div>
        </div>

        <div className="col-6 col-lg-3">
          <div className="cx-stat-card">
            <div>
              <p className="text-muted small fw-semibold mb-1">Completed Exchanges</p>
              <h3 className="fw-bold text-dark mb-0">{stats.completedExchanges}</h3>
              <span className="small text-muted fw-medium" style={{ fontSize: '0.72rem' }}>
                <i className="bi bi-shield-check me-1"></i> Safely returned
              </span>
            </div>
            <div className="cx-stat-icon-wrap">
              <i className="bi bi-patch-check-fill"></i>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions Bar */}
      <div className="cx-card p-3 p-md-4">
        <h6 className="fw-bold text-dark mb-3">
          <i className="bi bi-speedometer2 text-primary me-2"></i>Quick Actions
        </h6>
        <div className="row g-2">
          <div className="col-6 col-md-3">
            <button
              type="button"
              className="btn btn-light border w-100 py-3 d-flex flex-column align-items-center justify-content-center gap-2 hover-shadow"
              onClick={() => navigate('/create-request')}
            >
              <div className="rounded-circle bg-danger bg-opacity-10 text-danger p-2 px-3">
                <i className="bi bi-plus-circle-fill fs-5"></i>
              </div>
              <span className="fw-semibold small text-dark">Request a Product</span>
            </button>
          </div>

          <div className="col-6 col-md-3">
            <button
              type="button"
              className="btn btn-light border w-100 py-3 d-flex flex-column align-items-center justify-content-center gap-2 hover-shadow"
              onClick={() => navigate('/products')}
            >
              <div className="rounded-circle bg-primary bg-opacity-10 text-primary p-2 px-3">
                <i className="bi bi-search fs-5"></i>
              </div>
              <span className="fw-semibold small text-dark">Browse Products</span>
            </button>
          </div>

          <div className="col-6 col-md-3">
            <button
              type="button"
              className="btn btn-light border w-100 py-3 d-flex flex-column align-items-center justify-content-center gap-2 hover-shadow"
              onClick={() => navigate('/my-requests')}
            >
              <div className="rounded-circle bg-warning bg-opacity-10 text-warning p-2 px-3">
                <i className="bi bi-clock-history fs-5"></i>
              </div>
              <span className="fw-semibold small text-dark">My Requests</span>
            </button>
          </div>

          <div className="col-6 col-md-3">
            <button
              type="button"
              className="btn btn-light border w-100 py-3 d-flex flex-column align-items-center justify-content-center gap-2 hover-shadow"
              onClick={() => navigate('/transactions')}
            >
              <div className="rounded-circle bg-success bg-opacity-10 text-success p-2 px-3">
                <i className="bi bi-arrow-left-right fs-5"></i>
              </div>
              <span className="fw-semibold small text-dark">Transactions</span>
            </button>
          </div>
        </div>
      </div>

      {/* Urgent Recent Requests Section */}
      <div>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h5 className="fw-bold text-dark mb-0">
              <i className="bi bi-broadcast text-danger me-2"></i>Recent Campus Requests
            </h5>
            <p className="text-muted small mb-0">Urgent requests waiting for a helpful peer</p>
          </div>
          <Link to="/my-requests" className="btn btn-sm btn-outline-primary">
            View All Requests <i className="bi bi-arrow-right ms-1"></i>
          </Link>
        </div>

        {recentRequests.length === 0 ? (
          <div className="cx-card p-4 text-center text-muted">
            <i className="bi bi-check-circle fs-2 text-success mb-2 d-block"></i>
            <p className="mb-0">No active product requests right now. Everything is calm on campus!</p>
          </div>
        ) : (
          <div className="row g-3">
            {recentRequests.map(req => (
              <div key={req.id} className="col-12 col-md-6 col-xl-3">
                <RequestCard 
                  request={req} 
                  currentUserId={currentUser?.id}
                  onAcceptClick={openAcceptModal}
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Available Products Showcase */}
      <div>
        <div className="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h5 className="fw-bold text-dark mb-0">
              <i className="bi bi-box-seam-fill text-primary me-2"></i>Available for Immediate Lending
            </h5>
            <p className="text-muted small mb-0">Shared by students across various campus blocks</p>
          </div>
          <Link to="/products" className="btn btn-sm btn-outline-primary">
            Explore All <i className="bi bi-arrow-right ms-1"></i>
          </Link>
        </div>

        <div className="row g-3">
          {featuredProducts.map(product => (
            <div key={product.id} className="col-12 col-sm-6 col-lg-3">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>

      {/* Accept Request Confirmation Modal */}
      <Modal
        isOpen={!!selectedRequest}
        onClose={closeAcceptModal}
        title="Confirm Lending Request"
        footer={
          <>
            <button 
              type="button" 
              className="btn btn-sm btn-outline-secondary" 
              onClick={closeAcceptModal}
              disabled={accepting}
            >
              Cancel
            </button>
            <button 
              type="button" 
              className="btn btn-sm btn-success d-flex align-items-center gap-1"
              onClick={handleConfirmAccept}
              disabled={accepting}
            >
              {accepting ? (
                <>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  <span>Confirming...</span>
                </>
              ) : (
                <>
                  <i className="bi bi-check2-circle"></i>
                  <span>Accept & Share Contact</span>
                </>
              )}
            </button>
          </>
        }
      >
        {selectedRequest && (
          <div>
            <div className="p-3 bg-light rounded-3 border mb-3">
              <p className="mb-1 text-muted small">You are about to provide:</p>
              <h5 className="fw-bold text-dark mb-1">{selectedRequest.productName}</h5>
              <div className="small text-muted mb-2">
                <strong>Requester:</strong> {selectedRequest.requesterName} ({selectedRequest.requesterDept} Dept)
              </div>
              <div className="small text-danger">
                <i className="bi bi-geo-alt-fill me-1"></i>
                <strong>Needed At:</strong> {selectedRequest.location}
              </div>
              <div className="small text-dark mt-1">
                <strong>Urgency:</strong> <span className="badge bg-danger">{selectedRequest.urgency}</span>
              </div>
            </div>

            <div className="mb-3">
              <label className="form-label small fw-semibold text-secondary">
                Your Pickup / Location Instructions for Requester *
              </label>
              <textarea
                className="form-control"
                rows={3}
                placeholder="e.g. I am in Room 204, desk 3. Meet me at the door wearing blue shirt."
                value={pickupDetails}
                onChange={(e) => setPickupDetails(e.target.value)}
                required
              />
              <div className="form-text small">
                The requester will receive an instant notification with your instructions.
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Dashboard;
