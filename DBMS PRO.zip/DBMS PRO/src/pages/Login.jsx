import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import Modal from '../components/Modal';

const Login = () => {
  const { login, showToast } = useApp();
  const navigate = useNavigate();

  const [identifier, setIdentifier] = useState('STU1001');
  const [password, setPassword] = useState('123456');
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    if (!identifier.trim() || !password.trim()) {
      setErrorMsg('Please enter your College Email / Student ID and Password.');
      return;
    }

    try {
      setLoading(true);
      await login(identifier, password);
      navigate('/dashboard');
    } catch (err) {
      setErrorMsg(err.message || 'Login failed. Please verify your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const fillDemoStudent = (id, pass = '123456') => {
    setIdentifier(id);
    setPassword(pass);
    setErrorMsg('');
  };

  const handleForgotPassword = (e) => {
    e.preventDefault();
    if (!forgotEmail) {
      showToast('Please enter your registered college email.', 'warning');
      return;
    }
    setShowForgotModal(false);
    showToast(`Password reset link sent to ${forgotEmail}. (Demo password is 123456)`, 'info');
    setForgotEmail('');
  };

  return (
    <div className="min-vh-100 d-flex flex-column justify-content-center bg-light py-5 px-3">
      <div className="container" style={{ maxWidth: 460 }}>
        {/* Brand header */}
        <div className="text-center mb-4">
          <div className="d-inline-flex align-items-center justify-content-center bg-primary text-white rounded-4 p-3 shadow-md mb-3">
            <i className="bi bi-box-arrow-up-right fs-2"></i>
          </div>
          <h2 className="fw-extrabold text-dark tracking-tight mb-1">CampusX</h2>
          <p className="text-primary fw-medium mb-1">Campus Product Exchange</p>
          <p className="text-muted small fst-italic">"Share what you have. Get what you need."</p>
        </div>

        {/* Login Card */}
        <div className="cx-card p-4 p-sm-5 bg-white shadow-md">
          <h4 className="fw-bold text-dark mb-1">Student Sign In</h4>
          <p className="text-muted small mb-4">Access your campus lending & request dashboard</p>

          {errorMsg && (
            <div className="alert alert-danger py-2 px-3 small d-flex align-items-center gap-2 mb-3">
              <i className="bi bi-exclamation-circle-fill"></i>
              <div>{errorMsg}</div>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label small fw-semibold text-secondary">
                College Email or Student ID
              </label>
              <div className="input-group">
                <span className="input-group-text bg-light text-muted border-end-0">
                  <i className="bi bi-person-badge"></i>
                </span>
                <input
                  type="text"
                  className="form-control border-start-0 ps-0"
                  placeholder="e.g. STU1001 or arun@example.com"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="mb-3">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <label className="form-label small fw-semibold text-secondary mb-0">Password</label>
                <button
                  type="button"
                  className="btn btn-link p-0 small text-decoration-none text-primary"
                  style={{ fontSize: '0.8rem' }}
                  onClick={() => setShowForgotModal(true)}
                >
                  Forgot Password?
                </button>
              </div>
              <div className="input-group">
                <span className="input-group-text bg-light text-muted border-end-0">
                  <i className="bi bi-lock"></i>
                </span>
                <input
                  type="password"
                  className="form-control border-start-0 ps-0"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="form-check mb-4">
              <input
                className="form-check-input"
                type="checkbox"
                id="rememberMe"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
              />
              <label className="form-check-label small text-muted" htmlFor="rememberMe">
                Keep me signed in on this campus device
              </label>
            </div>

            <button
              type="submit"
              className="btn btn-primary w-100 py-2 fw-semibold d-flex align-items-center justify-content-center gap-2 shadow-sm"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
                  <span>Signing in...</span>
                </>
              ) : (
                <>
                  <i className="bi bi-box-arrow-in-right"></i>
                  <span>Login to CampusX</span>
                </>
              )}
            </button>
          </form>

          {/* Demo account quick login helper */}
          <div className="mt-4 pt-3 border-top text-center">
            <span className="text-muted small d-block mb-2">🚀 Instant Demo Logins:</span>
            <div className="d-flex flex-wrap justify-content-center gap-2">
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary px-2 py-1"
                style={{ fontSize: '0.75rem' }}
                onClick={() => fillDemoStudent('STU1001')}
              >
                Mohamed Irfan (STU1001)
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary px-2 py-1"
                style={{ fontSize: '0.75rem' }}
                onClick={() => fillDemoStudent('STU1002')}
              >
                Rahul (STU1002)
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary px-2 py-1"
                style={{ fontSize: '0.75rem' }}
                onClick={() => fillDemoStudent('STU1003')}
              >
                Priya (STU1003)
              </button>
              <button
                type="button"
                className="btn btn-sm btn-outline-secondary px-2 py-1"
                style={{ fontSize: '0.75rem' }}
                onClick={() => fillDemoStudent('STU1004')}
              >
                Irfan (STU1004)
              </button>
            </div>
            <p className="text-muted mt-2 mb-0" style={{ fontSize: '0.72rem' }}>
              Default password: <code>123456</code>
            </p>
          </div>

          <div className="mt-4 text-center">
            <p className="text-muted small mb-0">
              New student on campus?{' '}
              <Link to="/register" className="text-primary fw-semibold text-decoration-none">
                Create Account
              </Link>
            </p>
          </div>
        </div>

        {/* Campus notice */}
        <p className="text-center text-muted small mt-4">
          <i className="bi bi-shield-lock me-1"></i> Authorized only for enrolled college students & faculty.
        </p>
      </div>

      {/* Forgot Password Modal */}
      <Modal
        isOpen={showForgotModal}
        onClose={() => setShowForgotModal(false)}
        title="Reset Campus Account Password"
        footer={
          <>
            <button type="button" className="btn btn-outline-secondary btn-sm" onClick={() => setShowForgotModal(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-primary btn-sm" onClick={handleForgotPassword}>
              Send Reset Link
            </button>
          </>
        }
      >
        <p className="text-muted small">
          Enter your registered college email ID. We will send you an OTP / password reset link.
        </p>
        <div className="mb-3">
          <label className="form-label small fw-semibold text-secondary">College Email</label>
          <input
            type="email"
            className="form-control"
            placeholder="student@college.edu"
            value={forgotEmail}
            onChange={(e) => setForgotEmail(e.target.value)}
          />
        </div>
      </Modal>
    </div>
  );
};

export default Login;
