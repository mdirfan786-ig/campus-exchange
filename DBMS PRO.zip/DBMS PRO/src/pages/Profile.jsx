import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import Modal from '../components/Modal';

const Profile = () => {
  const { currentUser, updateProfile, showToast } = useApp();

  const [showEditModal, setShowEditModal] = useState(false);
  const [showPassModal, setShowPassModal] = useState(false);

  // Edit form state
  const [editData, setEditData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: currentUser?.phone || '',
    department: currentUser?.department || '',
    year: currentUser?.year || '3',
    section: currentUser?.section || 'A'
  });

  // Password state
  const [passData, setPassData] = useState({
    currentPass: '',
    newPass: '',
    confirmPass: ''
  });

  const handleOpenEdit = () => {
    setEditData({
      name: currentUser?.name || '',
      email: currentUser?.email || '',
      phone: currentUser?.phone || '',
      department: currentUser?.department || '',
      year: currentUser?.year || '3',
      section: currentUser?.section || 'A'
    });
    setShowEditModal(true);
  };

  const handleSaveProfile = async (e) => {
    e.preventDefault();
    if (!editData.name || !editData.email) {
      showToast('Name and Email are required.', 'warning');
      return;
    }
    await updateProfile(editData);
    setShowEditModal(false);
  };

  const handleSavePassword = (e) => {
    e.preventDefault();
    if (!passData.currentPass || !passData.newPass) {
      showToast('Please fill all password fields.', 'warning');
      return;
    }
    if (passData.newPass.length < 6) {
      showToast('New password must be at least 6 characters.', 'warning');
      return;
    }
    if (passData.newPass !== passData.confirmPass) {
      showToast('New passwords do not match.', 'error');
      return;
    }

    showToast('Password updated successfully!', 'success');
    setShowPassModal(false);
    setPassData({ currentPass: '', newPass: '', confirmPass: '' });
  };

  const stats = currentUser?.stats || {
    lent: 8,
    borrowed: 5,
    completed: 12,
    rating: 4.9
  };

  return (
    <div className="container-fluid" style={{ maxWidth: 960 }}>
      {/* Header Profile Hero Card */}
      <div className="cx-card bg-white p-4 p-md-5 mb-4 position-relative overflow-hidden">
        <div
          className="position-absolute top-0 start-0 end-0"
          style={{ height: '90px', background: 'linear-gradient(135deg, #000000 0%, #27272a 100%)' }}
        ></div>

        <div className="position-relative mt-4 pt-3 d-flex flex-column flex-md-row justify-content-between align-items-md-end gap-3">
          <div className="d-flex flex-column flex-sm-row align-items-sm-end gap-3">
            {currentUser?.avatar ? (
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="rounded-circle border border-4 border-white shadow-md bg-white"
                style={{ width: 100, height: 100, objectFit: 'cover' }}
              />
            ) : (
              <div 
                className="rounded-circle border border-4 border-white shadow-md bg-light text-secondary d-flex align-items-center justify-content-center"
                style={{ width: 100, height: 100 }}
              >
                <i className="bi bi-person-fill text-muted" style={{ fontSize: '3.2rem' }}></i>
              </div>
            )}
            <div>
              <h3 className="fw-bold text-dark mb-0">{currentUser?.name || 'Mohamed Irfan N'}</h3>
              <p className="text-muted small mb-1">
                Student ID: <span className="fw-semibold text-primary">{currentUser?.id || 'STU1001'}</span>
              </p>
              <div className="d-flex flex-wrap gap-2 small">
                <span className="badge bg-light text-dark border">
                  {currentUser?.department || 'Computer Science & Engineering'}
                </span>
                <span className="badge bg-light text-dark border">
                  Year {currentUser?.year || '3'} • Sec {currentUser?.section || 'A'}
                </span>
              </div>
            </div>
          </div>

          <div className="d-flex gap-2">
            <button
              type="button"
              className="btn btn-outline-primary btn-sm d-flex align-items-center gap-1"
              onClick={handleOpenEdit}
            >
              <i className="bi bi-pencil-square"></i> Edit Profile
            </button>
            <button
              type="button"
              className="btn btn-light border btn-sm d-flex align-items-center gap-1"
              onClick={() => setShowPassModal(true)}
            >
              <i className="bi bi-key"></i> Change Password
            </button>
          </div>
        </div>
      </div>

      {/* Exchange Statistics */}
      <div className="mb-4">
        <h5 className="fw-bold text-dark mb-3">
          <i className="bi bi-trophy text-warning me-2"></i>Campus Exchange Reputation & Statistics
        </h5>
        <div className="row g-3">
          <div className="col-6 col-md-3">
            <div className="cx-card p-3 text-center">
              <span className="text-muted small d-block mb-1">Products Lent</span>
              <h3 className="fw-bold text-primary mb-0">{stats.lent}</h3>
              <span className="small text-muted" style={{ fontSize: '0.72rem' }}>Times helped peers</span>
            </div>
          </div>

          <div className="col-6 col-md-3">
            <div className="cx-card p-3 text-center">
              <span className="text-muted small d-block mb-1">Products Borrowed</span>
              <h3 className="fw-bold text-warning mb-0">{stats.borrowed}</h3>
              <span className="small text-muted" style={{ fontSize: '0.72rem' }}>Emergency loans</span>
            </div>
          </div>

          <div className="col-6 col-md-3">
            <div className="cx-card p-3 text-center">
              <span className="text-muted small d-block mb-1">Completed Exchanges</span>
              <h3 className="fw-bold text-success mb-0">{stats.completed}</h3>
              <span className="small text-muted" style={{ fontSize: '0.72rem' }}>100% on-time return</span>
            </div>
          </div>

          <div className="col-6 col-md-3">
            <div className="cx-card p-3 text-center">
              <span className="text-muted small d-block mb-1">Campus Trust Rating</span>
              <h3 className="fw-bold text-dark mb-0">
                {stats.rating} <span className="text-warning fs-5">★</span>
              </h3>
              <span className="small text-success" style={{ fontSize: '0.72rem' }}>Top 5% verified</span>
            </div>
          </div>
        </div>
      </div>

      {/* Student Details Grid */}
      <div className="cx-card p-4 p-md-5 mb-4">
        <h5 className="fw-bold text-dark border-bottom pb-2 mb-4">
          <i className="bi bi-person-lines-fill text-primary me-2"></i>Academic & Contact Details
        </h5>

        <div className="row g-4 small">
          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">Full Legal Name</span>
            <span className="fw-semibold text-dark fs-6">{currentUser?.name}</span>
          </div>

          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">College Roll / Student ID</span>
            <span className="fw-semibold text-dark fs-6">{currentUser?.id}</span>
          </div>

          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">Official College Email</span>
            <span className="fw-semibold text-dark fs-6">{currentUser?.email}</span>
          </div>

          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">Mobile Contact</span>
            <span className="fw-semibold text-dark fs-6">{currentUser?.phone || '+91 98451 23450'}</span>
          </div>

          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">Department / Branch</span>
            <span className="fw-semibold text-dark fs-6">{currentUser?.department}</span>
          </div>

          <div className="col-12 col-sm-6">
            <span className="text-muted d-block mb-1">Current Academic Class</span>
            <span className="fw-semibold text-dark fs-6">Year {currentUser?.year}, Section {currentUser?.section}</span>
          </div>
        </div>
      </div>

      {/* Edit Profile Modal */}
      <Modal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        title="Edit Profile Information"
        footer={
          <>
            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => setShowEditModal(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-sm btn-primary" onClick={handleSaveProfile}>
              Save Changes
            </button>
          </>
        }
      >
        <form onSubmit={handleSaveProfile}>
          <div className="row g-3">
            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Full Name</label>
              <input
                type="text"
                className="form-control"
                value={editData.name}
                onChange={(e) => setEditData({ ...editData, name: e.target.value })}
                required
              />
            </div>

            <div className="col-12 col-md-6">
              <label className="form-label small fw-semibold text-secondary">Email</label>
              <input
                type="email"
                className="form-control"
                value={editData.email}
                onChange={(e) => setEditData({ ...editData, email: e.target.value })}
                required
              />
            </div>

            <div className="col-12 col-md-6">
              <label className="form-label small fw-semibold text-secondary">Phone Number</label>
              <input
                type="tel"
                className="form-control"
                value={editData.phone}
                onChange={(e) => setEditData({ ...editData, phone: e.target.value })}
                required
              />
            </div>

            <div className="col-12">
              <label className="form-label small fw-semibold text-secondary">Department</label>
              <input
                type="text"
                className="form-control"
                value={editData.department}
                onChange={(e) => setEditData({ ...editData, department: e.target.value })}
                required
              />
            </div>

            <div className="col-6">
              <label className="form-label small fw-semibold text-secondary">Year</label>
              <select
                className="form-select"
                value={editData.year}
                onChange={(e) => setEditData({ ...editData, year: e.target.value })}
              >
                <option value="1">1st Year</option>
                <option value="2">2nd Year</option>
                <option value="3">3rd Year</option>
                <option value="4">4th Year</option>
              </select>
            </div>

            <div className="col-6">
              <label className="form-label small fw-semibold text-secondary">Section</label>
              <input
                type="text"
                className="form-control"
                value={editData.section}
                onChange={(e) => setEditData({ ...editData, section: e.target.value })}
                maxLength={2}
              />
            </div>
          </div>
        </form>
      </Modal>

      {/* Change Password Modal */}
      <Modal
        isOpen={showPassModal}
        onClose={() => setShowPassModal(false)}
        title="Change Campus Password"
        footer={
          <>
            <button type="button" className="btn btn-sm btn-outline-secondary" onClick={() => setShowPassModal(false)}>
              Cancel
            </button>
            <button type="button" className="btn btn-sm btn-primary" onClick={handleSavePassword}>
              Update Password
            </button>
          </>
        }
      >
        <form onSubmit={handleSavePassword}>
          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">Current Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Enter current password (demo: 123456)"
              value={passData.currentPass}
              onChange={(e) => setPassData({ ...passData, currentPass: e.target.value })}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">New Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Minimum 6 characters"
              value={passData.newPass}
              onChange={(e) => setPassData({ ...passData, newPass: e.target.value })}
              required
            />
          </div>

          <div className="mb-3">
            <label className="form-label small fw-semibold text-secondary">Confirm New Password</label>
            <input
              type="password"
              className="form-control"
              placeholder="Repeat new password"
              value={passData.confirmPass}
              onChange={(e) => setPassData({ ...passData, confirmPass: e.target.value })}
              required
            />
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Profile;
