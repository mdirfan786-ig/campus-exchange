import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import StatusBadge from '../components/StatusBadge';
import Modal from '../components/Modal';

const Transactions = () => {
  const { transactions, currentUser, updateTransactionStatus } = useApp();

  const [filterStatus, setFilterStatus] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTxn, setSelectedTxn] = useState(null);

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter((t) => {
      if (filterStatus !== 'All' && t.status !== filterStatus) {
        return false;
      }

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          t.id.toLowerCase().includes(q) ||
          t.productName.toLowerCase().includes(q) ||
          t.requesterName.toLowerCase().includes(q) ||
          t.providerName.toLowerCase().includes(q) ||
          t.location.toLowerCase().includes(q)
        );
      }

      return true;
    });
  }, [transactions, filterStatus, searchQuery]);

  const handleStatusChange = async (txnId, newStatus) => {
    await updateTransactionStatus(txnId, newStatus);
  };

  return (
    <div className="d-flex flex-column gap-4">
      {/* Header */}
      <div className="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
        <div>
          <h3 className="fw-bold text-dark mb-1">Exchange Transactions History</h3>
          <p className="text-muted small mb-0">
            Official campus audit log of product handovers, active loans, and completed returns
          </p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="row g-3">
        <div className="col-6 col-md-3">
          <div className="cx-card p-3">
            <span className="text-muted small">Total Transactions</span>
            <h4 className="fw-bold text-dark mb-0">{transactions.length}</h4>
          </div>
        </div>

        <div className="col-6 col-md-3">
          <div className="cx-card p-3">
            <span className="text-muted small">Currently Active</span>
            <h4 className="fw-bold text-warning mb-0">{transactions.filter(t => t.status === 'Active').length}</h4>
          </div>
        </div>

        <div className="col-6 col-md-3">
          <div className="cx-card p-3">
            <span className="text-muted small">Safely Returned</span>
            <h4 className="fw-bold text-success mb-0">{transactions.filter(t => t.status === 'Completed' || t.status === 'Returned').length}</h4>
          </div>
        </div>

        <div className="col-6 col-md-3">
          <div className="cx-card p-3">
            <span className="text-muted small">Your Exchanges</span>
            <h4 className="fw-bold text-primary mb-0">
              {transactions.filter(t => currentUser && (t.requesterId === currentUser.id || t.providerId === currentUser.id)).length}
            </h4>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="cx-filter-bar">
        <div className="row g-3 align-items-center justify-content-between">
          <div className="col-12 col-md-6 d-flex flex-wrap gap-2">
            {['All', 'Active', 'Returned', 'Completed', 'Cancelled'].map((status) => (
              <button
                key={status}
                type="button"
                className={`btn btn-sm py-1 px-3 rounded-pill ${
                  filterStatus === status ? 'btn-primary' : 'btn-light border'
                }`}
                onClick={() => setFilterStatus(status)}
              >
                {status}
              </button>
            ))}
          </div>

          <div className="col-12 col-md-4">
            <div className="input-group input-group-sm">
              <span className="input-group-text bg-light text-muted border-end-0">
                <i className="bi bi-search"></i>
              </span>
              <input
                type="text"
                className="form-control border-start-0 ps-0"
                placeholder="Search transaction, student, item..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Transactions Table */}
      <div className="cx-table-container">
        {filteredTransactions.length === 0 ? (
          <div className="p-5 text-center text-muted">
            <i className="bi bi-receipt fs-1 text-secondary d-block mb-2"></i>
            <h6 className="fw-bold text-dark">No transactions found</h6>
            <p className="small mb-0">No exchange records match your current filters.</p>
          </div>
        ) : (
          <div className="table-responsive">
            <table className="cx-table table">
              <thead>
                <tr>
                  <th>Transaction ID</th>
                  <th>Product</th>
                  <th>Requester</th>
                  <th>Provider / Lender</th>
                  <th>Date</th>
                  <th>Campus Location</th>
                  <th>Status</th>
                  <th className="text-end">Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((txn) => (
                  <tr key={txn.id}>
                    <td>
                      <span className="fw-bold text-dark font-monospace">#{txn.id}</span>
                    </td>
                    <td>
                      <div className="fw-semibold text-dark">{txn.productName}</div>
                      <div className="text-muted small">{txn.category}</div>
                    </td>
                    <td>
                      <div className="small fw-semibold text-dark">{txn.requesterName}</div>
                      <div className="text-muted small" style={{ fontSize: '0.75rem' }}>Borrower</div>
                    </td>
                    <td>
                      <div className="small fw-semibold text-dark">{txn.providerName}</div>
                      <div className="text-muted small" style={{ fontSize: '0.75rem' }}>Owner</div>
                    </td>
                    <td>
                      <div className="small text-muted">{txn.date}</div>
                    </td>
                    <td>
                      <div className="small text-truncate" style={{ maxWidth: 160 }}>
                        <i className="bi bi-geo-alt-fill text-danger me-1"></i>
                        {txn.location}
                      </div>
                    </td>
                    <td>
                      <StatusBadge status={txn.status} />
                    </td>
                    <td className="text-end">
                      <div className="d-flex justify-content-end gap-1">
                        <button
                          type="button"
                          className="btn btn-sm btn-outline-secondary py-1 px-2"
                          title="View Receipt"
                          onClick={() => setSelectedTxn(txn)}
                        >
                          <i className="bi bi-file-text"></i>
                        </button>

                        {txn.status === 'Active' && (
                          <button
                            type="button"
                            className="btn btn-sm btn-outline-success py-1 px-2"
                            title="Mark as Returned & Completed"
                            onClick={() => handleStatusChange(txn.id, 'Completed')}
                          >
                            <i className="bi bi-check2"></i> Complete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Receipt Modal */}
      <Modal
        isOpen={!!selectedTxn}
        onClose={() => setSelectedTxn(null)}
        title={`Campus Exchange Receipt #${selectedTxn?.id}`}
        footer={
          <button
            type="button"
            className="btn btn-sm btn-primary"
            onClick={() => setSelectedTxn(null)}
          >
            Close
          </button>
        }
      >
        {selectedTxn && (
          <div className="p-3 bg-light rounded-3 border">
            <div className="text-center pb-3 border-bottom mb-3">
              <span className="badge bg-primary text-white p-2 mb-2 d-inline-block">
                CAMPUS PRODUCT EXCHANGE RECEIPT
              </span>
              <h5 className="fw-bold text-dark mb-0">#{selectedTxn.id}</h5>
              <span className="text-muted small">CampusX Peer Handover Verification</span>
            </div>

            <div className="row g-2 small mb-3">
              <div className="col-6">
                <span className="text-muted d-block">Product:</span>
                <span className="fw-bold text-dark">{selectedTxn.productName}</span>
              </div>
              <div className="col-6">
                <span className="text-muted d-block">Status:</span>
                <StatusBadge status={selectedTxn.status} />
              </div>
              <div className="col-6">
                <span className="text-muted d-block">Borrower (Requester):</span>
                <span className="fw-semibold text-dark">{selectedTxn.requesterName}</span>
              </div>
              <div className="col-6">
                <span className="text-muted d-block">Lender (Provider):</span>
                <span className="fw-semibold text-dark">{selectedTxn.providerName}</span>
              </div>
              <div className="col-6">
                <span className="text-muted d-block">Exchange Date:</span>
                <span className="text-dark">{selectedTxn.date}</span>
              </div>
              <div className="col-6">
                <span className="text-muted d-block">Location:</span>
                <span className="text-danger fw-semibold">{selectedTxn.location}</span>
              </div>
            </div>

            {selectedTxn.notes && (
              <div className="p-2 bg-white rounded border small text-muted">
                <strong>Log Note:</strong> {selectedTxn.notes}
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
};

export default Transactions;
