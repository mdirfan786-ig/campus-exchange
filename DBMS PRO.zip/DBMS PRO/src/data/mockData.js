// Campus Product Exchange (CampusX) - Mock Database
// Structured for future MySQL/Node.js backend synchronization

export const CATEGORIES = [
  'Stationery',
  'Calculators',
  'Geometry Tools',
  'Books',
  'Lab Equipment',
  'Electronics',
  'Sports Items',
  'Other'
];

export const CAMPUS_LOCATIONS = [
  'Main block ground floor',
  'Main block 1st floor',
  'Main block 2nd floor',
  'Main block 3rd floor',
  'Techpark ground floor',
  'Techpark 1st floor',
  'Techpark 2nd floor',
  'Tech park 3rd floor',
  'Academic block ground floor',
  'Academic block 1st floor',
  'Academic block 2nd floor',
  'Academic block 3rd floor'
];

export const URGENCY_LEVELS = [
  { level: 'Normal', color: 'info', icon: 'bi-info-circle', desc: 'Needed later today or tomorrow' },
  { level: 'Important', color: 'primary', icon: 'bi-exclamation-circle', desc: 'Needed within 2-3 hours' },
  { level: 'Urgent', color: 'warning', icon: 'bi-exclamation-triangle', desc: 'Needed within an hour' },
  { level: 'Emergency', color: 'danger', icon: 'bi-lightning-charge-fill', desc: 'Needed immediately for exam/lab' }
];

export const INITIAL_STUDENTS = [
  {
    id: "STU1001",
    name: "Mohamed Irfan N",
    department: "Computer Science & Engineering",
    year: "3",
    section: "A",
    email: "mohamed.irfan@example.com",
    phone: "+91 98451 23450",
    avatar: "",
    stats: {
      lent: 8,
      borrowed: 5,
      completed: 12,
      rating: 4.9
    }
  },
  {
    id: "STU1002",
    name: "Rahul Sharma",
    department: "Mechanical Engineering",
    year: "2",
    section: "B",
    email: "rahul@example.com",
    phone: "+91 98451 23451",
    avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=150&auto=format&fit=crop&q=80",
    stats: {
      lent: 11,
      borrowed: 3,
      completed: 14,
      rating: 4.8
    }
  },
  {
    id: "STU1003",
    name: "Priya Patel",
    department: "Electronics & Communication",
    year: "4",
    section: "A",
    email: "priya@example.com",
    phone: "+91 98451 23452",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    stats: {
      lent: 9,
      borrowed: 4,
      completed: 13,
      rating: 5.0
    }
  },
  {
    id: "STU1004",
    name: "Sneha Roy",
    department: "Information Technology",
    year: "3",
    section: "B",
    email: "sneha@example.com",
    phone: "+91 98451 23453",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80",
    stats: {
      lent: 7,
      borrowed: 6,
      completed: 11,
      rating: 4.95
    }
  }
];

export const INITIAL_PRODUCTS = [
  {
    id: "PROD101",
    name: "Casio FX-991EX Scientific Calculator",
    category: "Calculators",
    description: "Original non-programmable scientific calculator with matrix and equation solver. Allowed in university examinations.",
    condition: "Excellent",
    available: true,
    ownerId: "STU1001",
    ownerName: "Mohamed Irfan N",
    ownerDept: "CSE",
    location: "Main block ground floor",
    availableTime: "8:30 AM - 5:00 PM",
    quantity: 1,
    icon: "bi-calculator-fill",
    color: "#2563eb",
    image: "https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD102",
    name: "Engineering Drawing Mini Drafter & T-Square",
    category: "Geometry Tools",
    description: "Precision metal clamp drafter with scale rules. Perfect for machine drawing & civil graphics labs.",
    condition: "Good",
    available: true,
    ownerId: "STU1002",
    ownerName: "Rahul Sharma",
    ownerDept: "Mechanical",
    location: "Techpark ground floor",
    availableTime: "9:00 AM - 4:30 PM",
    quantity: 1,
    icon: "bi-rulers",
    color: "#0891b2",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD103",
    name: "Digital Multimeter with Test Probes",
    category: "Lab Equipment",
    description: "True-RMS digital multimeter with probe leads for voltage, resistance, diode, and continuity test.",
    condition: "Like New",
    available: true,
    ownerId: "STU1003",
    ownerName: "Priya Patel",
    ownerDept: "ECE",
    location: "Techpark 2nd floor",
    availableTime: "10:00 AM - 6:00 PM",
    quantity: 1,
    icon: "bi-cpu-fill",
    color: "#7c3aed",
    image: "https://images.unsplash.com/photo-1581092335397-9583fe92d232?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD104",
    name: "White Chemistry Laboratory Coat (Size L)",
    category: "Lab Equipment",
    description: "Pure cotton protective white lab coat with deep pockets. Clean and ironed, ready for chemistry/bio practicals.",
    condition: "Good",
    available: true,
    ownerId: "STU1001",
    ownerName: "Mohamed Irfan N",
    ownerDept: "CSE",
    location: "Academic block ground floor",
    availableTime: "11:00 AM - 3:00 PM",
    quantity: 1,
    icon: "bi-shield-check",
    color: "#059669",
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD105",
    name: "65W USB Type-C Fast Charger + 2m Braided Cable",
    category: "Electronics",
    description: "Multi-protocol PD charger suitable for laptops, iPad, and Android smartphones. Urgent exam prep backup.",
    condition: "Like New",
    available: true,
    ownerId: "STU1004",
    ownerName: "Irfan Khan",
    ownerDept: "IT",
    location: "Academic block 1st floor",
    availableTime: "All Day",
    quantity: 1,
    icon: "bi-plug-fill",
    color: "#ea580c",
    image: "https://images.unsplash.com/photo-1609592807664-96426db4f61f?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD106",
    name: "Data Structures & Algorithms by Cormen (CLRS 3rd Ed)",
    category: "Books",
    description: "Standard reference text for algorithms course and competitive programming. Clear pages with no ink markings.",
    condition: "Good",
    available: true,
    ownerId: "STU1001",
    ownerName: "Mohamed Irfan N",
    ownerDept: "CSE",
    location: "Techpark 1st floor",
    availableTime: "9:00 AM - 5:00 PM",
    quantity: 1,
    icon: "bi-journal-bookmark-fill",
    color: "#4f46e5",
    image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD107",
    name: "Complete Geometry Compass & Protractor Box",
    category: "Geometry Tools",
    description: "Stainless steel compass, divider, 180-deg protractor, set squares, and 15cm ruler in metal tin.",
    condition: "Brand New",
    available: false,
    ownerId: "STU1002",
    ownerName: "Rahul Sharma",
    ownerDept: "Mechanical",
    location: "Main block 2nd floor",
    availableTime: "10:00 AM - 1:00 PM",
    quantity: 1,
    icon: "bi-pencil-ruler",
    color: "#db2777",
    image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=400&auto=format&fit=crop&q=80"
  },
  {
    id: "PROD108",
    name: "Yonex Badminton Racket Pair with Shuttles",
    category: "Sports Items",
    description: "High tension carbon frame rackets with tube of nylon shuttlecocks. For evening campus games.",
    condition: "Good",
    available: true,
    ownerId: "STU1004",
    ownerName: "Irfan Khan",
    ownerDept: "IT",
    location: "Academic block 3rd floor",
    availableTime: "4:00 PM - 7:30 PM",
    quantity: 2,
    icon: "bi-trophy-fill",
    color: "#16a34a",
    image: "https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=400&auto=format&fit=crop&q=80"
  }
];

export const INITIAL_REQUESTS = [
  {
    id: "REQ1024",
    productName: "Scientific Calculator",
    category: "Calculators",
    quantity: 1,
    reason: "Maths Semester Examination (Calculus-II). My calculator stopped turning on.",
    urgency: "Emergency",
    location: "Main block ground floor",
    requiredDate: "Today",
    requiredTime: "10:00 AM",
    description: "Urgent need! Waiting in Main block ground floor. Can return immediately at 1:15 PM once exam finishes.",
    requesterId: "STU1001",
    requesterName: "Mohamed Irfan N",
    requesterDept: "CSE",
    requesterYear: "3",
    requesterPhone: "+91 98451 23450",
    status: "Waiting", // Waiting | Accepted | In Progress | Completed | Cancelled
    acceptedBy: null,
    pickupDetails: null,
    createdAt: "2026-09-24T18:40:00Z"
  },
  {
    id: "REQ1025",
    productName: "Engineering Drafter & Clamp",
    category: "Geometry Tools",
    quantity: 1,
    reason: "Machine Drawing Lab Internal Assessment",
    urgency: "Urgent",
    location: "Techpark ground floor",
    requiredDate: "Today",
    requiredTime: "11:30 AM",
    description: "Need a working clamp drafter for 2 hours. Will handle with extreme care.",
    requesterId: "STU1003",
    requesterName: "Priya Patel",
    requesterDept: "ECE",
    requesterYear: "4",
    requesterPhone: "+91 98451 23452",
    status: "Waiting",
    acceptedBy: null,
    pickupDetails: null,
    createdAt: "2026-09-24T18:15:00Z"
  },
  {
    id: "REQ1026",
    productName: "Digital Multimeter",
    category: "Lab Equipment",
    quantity: 1,
    reason: "IoT Circuit Troubleshooting for Mini Project",
    urgency: "Important",
    location: "Techpark 2nd floor",
    requiredDate: "Today",
    requiredTime: "02:00 PM",
    description: "Need to verify voltage drops across resistor array.",
    requesterId: "STU1004",
    requesterName: "Irfan Khan",
    requesterDept: "IT",
    requesterYear: "3",
    requesterPhone: "+91 98451 23453",
    status: "Accepted",
    acceptedBy: {
      id: "STU1002",
      name: "Rahul Sharma",
      department: "Mechanical",
      phone: "+91 98451 23451",
      location: "Main block 1st floor"
    },
    pickupDetails: "I am in Main block 1st floor. Collect anytime before 2:15 PM.",
    createdAt: "2026-09-24T16:00:00Z"
  },
  {
    id: "REQ1027",
    productName: "White Lab Coat",
    category: "Lab Equipment",
    quantity: 1,
    reason: "Organic Chemistry Practical Examination",
    urgency: "Normal",
    location: "Academic block ground floor",
    requiredDate: "Yesterday",
    requiredTime: "09:30 AM",
    description: "Forgot lab coat in hostel room.",
    requesterId: "STU1001",
    requesterName: "Mohamed Irfan N",
    requesterDept: "CSE",
    requesterYear: "3",
    requesterPhone: "+91 98451 23450",
    status: "Completed",
    acceptedBy: {
      id: "STU1004",
      name: "Irfan Khan",
      department: "IT",
      phone: "+91 98451 23453",
      location: "Academic block 1st floor"
    },
    pickupDetails: "Exchanged in Academic block ground floor lobby. Item returned in clean condition.",
    createdAt: "2026-09-23T08:30:00Z"
  },
  {
    id: "REQ1028",
    productName: "65W USB-C Laptop Charger",
    category: "Electronics",
    quantity: 1,
    reason: "Laptop battery died right before Capstone Presentation",
    urgency: "Emergency",
    location: "Techpark 1st floor",
    requiredDate: "Today",
    requiredTime: "03:15 PM",
    description: "Need for Dell XPS / MacBook charging during slide deck presentation.",
    requesterId: "STU1002",
    requesterName: "Rahul Sharma",
    requesterDept: "Mechanical",
    requesterYear: "2",
    requesterPhone: "+91 98451 23451",
    status: "Waiting",
    acceptedBy: null,
    pickupDetails: null,
    createdAt: "2026-09-24T18:30:00Z"
  }
];

export const INITIAL_TRANSACTIONS = [
  {
    id: "TXN001",
    requestId: "REQ1027",
    productName: "White Lab Coat",
    category: "Lab Equipment",
    requesterName: "Mohamed Irfan N",
    requesterId: "STU1001",
    providerName: "Irfan Khan",
    providerId: "STU1004",
    date: "23/09/2026",
    location: "Academic block ground floor",
    status: "Completed", // Active | Returned | Completed | Cancelled
    notes: "Exchanged in morning and returned by 1:00 PM. Verified clean."
  },
  {
    id: "TXN002",
    requestId: "REQ1026",
    productName: "Digital Multimeter",
    category: "Lab Equipment",
    requesterName: "Irfan Khan",
    requesterId: "STU1004",
    providerName: "Rahul Sharma",
    providerId: "STU1002",
    date: "24/09/2026",
    location: "Techpark 2nd floor",
    status: "Active",
    notes: "Handed over at 1:45 PM. Expected return 4:30 PM."
  },
  {
    id: "TXN003",
    requestId: "REQ1020",
    productName: "Casio FX-991EX Calculator",
    category: "Calculators",
    requesterName: "Priya Patel",
    requesterId: "STU1003",
    providerName: "Mohamed Irfan N",
    providerId: "STU1001",
    date: "22/09/2026",
    location: "Main block ground floor",
    status: "Completed",
    notes: "Exam emergency exchange. Returned immediately."
  },
  {
    id: "TXN004",
    requestId: "REQ1019",
    productName: "Data Structures (CLRS Book)",
    category: "Books",
    requesterName: "Rahul Sharma",
    requesterId: "STU1002",
    providerName: "Mohamed Irfan N",
    providerId: "STU1001",
    date: "21/09/2026",
    location: "Academic block 1st floor",
    status: "Returned",
    notes: "Returned back to bookshelf after evening study session."
  }
];

export const INITIAL_NOTIFICATIONS = [
  {
    id: "NOTIF001",
    userId: "STU1001",
    title: "Urgent Request Match",
    message: "Your calculator request #REQ1024 has 2 nearby matching students with available items!",
    type: "alert",
    unread: true,
    time: "5 mins ago",
    link: "/request/REQ1024"
  },
  {
    id: "NOTIF002",
    userId: "STU1004",
    title: "Request Accepted!",
    message: "Rahul Sharma accepted your request for Digital Multimeter. Pickup location: Main block 1st floor.",
    type: "success",
    unread: true,
    time: "25 mins ago",
    link: "/request/REQ1026"
  },
  {
    id: "NOTIF003",
    userId: "STU1001",
    title: "Exchange Completed",
    message: "Transaction TXN001 (White Lab Coat) has been marked as Completed and Returned.",
    type: "info",
    unread: false,
    time: "Yesterday, 3:15 PM",
    link: "/transactions"
  },
  {
    id: "NOTIF004",
    userId: "STU1002",
    title: "Return Reminder",
    message: "Reminder: Digital Multimeter (TXN002) is due to be returned by 4:30 PM today.",
    type: "warning",
    unread: false,
    time: "2 hours ago",
    link: "/transactions"
  },
  {
    id: "NOTIF005",
    userId: "STU1001",
    title: "New Urgent Campus Request",
    message: "Rahul Sharma urgently needs a 65W USB-C Charger in Techpark 1st floor.",
    type: "alert",
    unread: true,
    time: "30 mins ago",
    link: "/request/REQ1028"
  }
];
