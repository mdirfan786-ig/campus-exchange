import React, { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { INITIAL_STUDENTS } from '../data/mockData';
import Modal from './Modal';

const Navbar = ({ onToggleSidebar }) => {
  const { currentUser, logout, unreadNotificationsCount, switchAccount } = useApp();
  const [navSearch, setNavSearch] = useState('');
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (navSearch.trim()) {
      navigate(`/products?search=${encodeURIComponent(navSearch.trim())}`);
      setNavSearch('');
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="cx-navbar py-2 px-3 px-lg-4">
      <div className="d-flex align-items-center justify-content-between gap-3">
        {/* Left: Brand & Sidebar toggle */}
        <div className="d-flex align-items-center gap-3">
          <button 
            type="button" 
            className="btn btn-sm btn-light border d-lg-none"
            onClick={onToggleSidebar}
            aria-label="Toggle navigation menu"
          >
            <i className="bi bi-list fs-5"></i>
          </button>

          <Link to="/dashboard" className="cx-brand-logo">
            <span className="rounded-3 bg-primary text-white p-2 py-1 d-inline-flex align-items-center justify-content-center shadow-sm">
              <i className="bi bi-box-arrow-up-right"></i>
            </span>
            <span className="d-none d-sm-inline">Campus<span className="text-dark">X</span></span>
            <span className="cx-brand-badge">EXCHANGE</span>
          </Link>
        </div>

        {/* Middle: Search bar */}
        <form onSubmit={handleSearchSubmit} className="d-none d-md-flex align-items-center flex-grow-1 mx-3" style={{ maxWidth: 420 }}>
          <div className="input-group input-group-sm">
            <span className="input-group-text bg-light border-end-0 text-muted">
              <i className="bi bi-search"></i>
            </span>
            <input
              type="text"
              className="form-control bg-light border-start-0 ps-0"
              placeholder="Search calculator, drafter, books, lab coat..."
              value={navSearch}
              onChange={(e) => setNavSearch(e.target.value)}
            />
          </div>
        </form>

        {/* Right Actions */}
        <div className="d-flex align-items-center gap-2 gap-sm-3">
          {/* Multi-Device Network Button */}
          <button
            type="button"
            className="btn btn-sm btn-outline-dark d-none d-md-inline-flex align-items-center gap-1 shadow-xs"
            onClick={() => setShowDeviceModal(true)}
            title="Connect from phone, tablet, or another device on LAN"
          >
            <i className="bi bi-phone"></i>
            <span>All Devices</span>
          </button>

          {/* Quick Create Request Button */}
          <Link to="/create-request" className="btn btn-sm btn-primary d-none d-sm-inline-flex align-items-center gap-1 shadow-sm">
            <i className="bi bi-plus-lg"></i>
            <span>Request Item</span>
          </Link>

          {/* Notifications Icon */}
          <Link 
            to="/notifications" 
            className="btn btn-sm btn-light position-relative border rounded-circle p-2 text-dark"
            title="Notifications"
            style={{ width: 38, height: 38 }}
          >
            <i className="bi bi-bell fs-6"></i>
            {unreadNotificationsCount > 0 && (
              <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style={{ fontSize: '0.65rem' }}>
                {unreadNotificationsCount}
                <span className="visually-hidden">unread messages</span>
              </span>
            )}
          </Link>

          {/* User Account / Profile Dropdown */}
          {currentUser ? (
            <div className="position-relative">
              <button
                type="button"
                className="btn btn-sm btn-light border d-flex align-items-center gap-2 p-1 pe-2 rounded-pill"
                onClick={() => setShowUserMenu(!showUserMenu)}
              >
                {currentUser.avatar ? (
                  <img 
                    src={currentUser.avatar} 
                    alt={currentUser.name} 
                    className="rounded-circle"
                    style={{ width: 28, height: 28, objectFit: 'cover' }}
                  />
                ) : (
                  <div 
                    className="rounded-circle bg-white border text-secondary d-flex align-items-center justify-content-center"
                    style={{ width: 28, height: 28 }}
                  >
                    <i className="bi bi-person-fill text-muted" style={{ fontSize: '0.85rem' }}></i>
                  </div>
                )}
                <span className="d-none d-md-inline small fw-semibold text-dark">
                  {currentUser.name.split(' ')[0]}
                </span>
                <i className="bi bi-chevron-down text-muted small"></i>
              </button>

              {showUserMenu && (
                <div 
                  className="position-absolute end-0 mt-2 py-2 bg-white rounded-3 shadow-lg border"
                  style={{ width: 240, zIndex: 1050 }}
                  onClick={() => setShowUserMenu(false)}
                >
                  <div className="px-3 py-2 border-bottom">
                    <p className="mb-0 fw-bold text-dark small">{currentUser.name}</p>
                    <p className="mb-0 text-muted" style={{ fontSize: '0.75rem' }}>{currentUser.id} • {currentUser.department}</p>
                  </div>

                  <Link to="/profile" className="dropdown-item px-3 py-2 small d-flex align-items-center gap-2 text-dark">
                    <i className="bi bi-person text-primary"></i> My Profile
                  </Link>

                  <Link to="/my-requests" className="dropdown-item px-3 py-2 small d-flex align-items-center gap-2 text-dark">
                    <i className="bi bi-list-check text-primary"></i> My Requests
                  </Link>

                  <Link to="/available-products" className="dropdown-item px-3 py-2 small d-flex align-items-center gap-2 text-dark">
                    <i className="bi bi-box-seam text-primary"></i> Products I Share
                  </Link>

                  <Link to="/transactions" className="dropdown-item px-3 py-2 small d-flex align-items-center gap-2 text-dark">
                    <i className="bi bi-arrow-left-right text-primary"></i> Transactions
                  </Link>

                  {/* Switch Demo Student helper */}
                  <div className="border-top my-1"></div>
                  <div className="px-3 py-1 text-muted fw-semibold" style={{ fontSize: '0.7rem' }}>
                    SWITCH DEMO ACCOUNT:
                  </div>
                  {INITIAL_STUDENTS.map(s => (
                    <button
                      key={s.id}
                      type="button"
                      className={`dropdown-item px-3 py-1 small d-flex align-items-center justify-content-between ${s.id === currentUser.id ? 'bg-light fw-bold text-primary' : 'text-secondary'}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        switchAccount(s.id);
                        setShowUserMenu(false);
                      }}
                    >
                      <span>{s.name} ({s.id})</span>
                      {s.id === currentUser.id && <i className="bi bi-check2 text-primary"></i>}
                    </button>
                  ))}

                  <div className="border-top my-1"></div>
                  <button
                    type="button"
                    className="dropdown-item px-3 py-2 small text-danger d-flex align-items-center gap-2"
                    onClick={handleLogout}
                  >
                    <i className="bi bi-box-arrow-right"></i> Logout
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link to="/login" className="btn btn-sm btn-outline-primary">
              Login
            </Link>
          )}
        </div>
      </div>

      {/* Multi-Device LAN Access Modal */}
      <Modal
        isOpen={showDeviceModal}
        onClose={() => setShowDeviceModal(false)}
        title="📱 Access on All Devices (Mobile & Tablet)"
        maxWidth="540px"
      >
        <div className="d-flex flex-column gap-3">
          <div className="p-3 bg-light rounded-3 border">
            <div className="d-flex align-items-center justify-content-between mb-2">
              <span className="fw-semibold small text-dark">
                <i className="bi bi-wifi text-dark me-1"></i> Wi-Fi / Local Network URL
              </span>
              <span className="badge bg-black text-white px-2 py-1 small">Live Backend</span>
            </div>
            <div className="input-group input-group-sm">
              <input 
                type="text" 
                className="form-control font-monospace text-dark bg-white" 
                value={`http://${window.location.hostname === 'localhost' ? '192.168.43.51' : window.location.hostname}:5174`} 
                readOnly 
              />
              <button 
                className="btn btn-dark" 
                type="button"
                onClick={() => {
                  const url = `http://${window.location.hostname === 'localhost' ? '192.168.43.51' : window.location.hostname}:5174`;
                  navigator.clipboard.writeText(url);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
              >
                {copied ? <><i className="bi bi-check-lg me-1"></i>Copied!</> : <><i className="bi bi-clipboard me-1"></i>Copy URL</>}
              </button>
            </div>
          </div>

          <div>
            <h6 className="fw-bold text-dark small mb-2">How to open on your phone or tablet:</h6>
            <ol className="small text-muted ps-3 mb-0" style={{ lineHeight: 1.6 }}>
              <li>Connect your phone or tablet to the same Wi-Fi network.</li>
              <li>Open Chrome, Safari, or any browser on your device.</li>
              <li>Navigate to: <strong className="text-dark font-monospace">http://192.168.43.51:5174</strong></li>
              <li>Any request you create or accept from your phone immediately syncs with this laptop!</li>
            </ol>
          </div>

          <div className="p-3 border rounded-3 bg-white">
            <div className="d-flex align-items-center justify-content-between small">
              <span className="text-muted">Backend REST API:</span>
              <span className="font-monospace fw-semibold text-dark">http://192.168.43.51:5000/api</span>
            </div>
            <div className="d-flex align-items-center justify-content-between small mt-2">
              <span className="text-muted">Database Engine:</span>
              <span className="badge bg-light text-dark border">campusx_db.json (ACID Persistent)</span>
            </div>
            <div className="d-flex align-items-center justify-content-between small mt-2">
              <span className="text-muted">Multi-Device Status:</span>
              <span className="fw-semibold text-dark"><i className="bi bi-check-circle-fill text-dark me-1"></i> Active on 0.0.0.0</span>
            </div>
          </div>
        </div>
      </Modal>
    </nav>
  );
};

export default Navbar;
