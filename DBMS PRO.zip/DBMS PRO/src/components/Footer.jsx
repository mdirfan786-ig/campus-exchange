import React from 'react';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <footer className="bg-white border-top py-4 px-3 px-md-4 mt-auto">
      <div className="container-fluid max-w-1400">
        <div className="row g-4 align-items-center justify-content-between">
          <div className="col-12 col-md-5">
            <div className="d-flex align-items-center gap-2 mb-2">
              <span className="rounded bg-primary text-white p-1 px-2 fw-bold small">CampusX</span>
              <span className="fw-bold text-dark">Campus Product Exchange System</span>
            </div>
            <p className="text-muted small mb-0">
              A peer-to-peer campus sharing platform enabling college students to request, lend, 
              and exchange study materials & academic essentials temporarily during urgent examinations and labs.
            </p>
          </div>

          <div className="col-12 col-md-4 text-md-center">
            <div className="d-flex justify-content-start justify-content-md-center gap-3 small text-muted">
              <Link to="/about" className="text-decoration-none text-secondary hover-primary">About Project</Link>
              <span>•</span>
              <Link to="/products" className="text-decoration-none text-secondary hover-primary">Catalog</Link>
              <span>•</span>
              <Link to="/create-request" className="text-decoration-none text-secondary hover-primary">Urgent Help</Link>
              <span>•</span>
              <Link to="/transactions" className="text-decoration-none text-secondary hover-primary">Audit Log</Link>
            </div>
            <p className="text-muted mt-2 mb-0" style={{ fontSize: '0.75rem' }}>
              Built for College DBMS Mini-Project Evaluation • Ready for MySQL + Express
            </p>
          </div>

          <div className="col-12 col-md-3 text-md-end text-muted small">
            <div><i className="bi bi-geo-alt-fill text-dark me-1"></i> Campus Network Only</div>
            <div className="mt-1" style={{ fontSize: '0.75rem' }}>© {new Date().getFullYear()} CampusX Peer Exchange. All rights reserved.</div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
