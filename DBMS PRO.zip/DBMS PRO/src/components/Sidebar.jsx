import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';

const Sidebar = ({ isOpen, onClose }) => {
  const { logout, unreadNotificationsCount, currentUser } = useApp();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
    if (onClose) onClose();
  };

  const navItems = [
    { to: '/dashboard', label: 'Dashboard', icon: 'bi-grid-1x2-fill' },
    { to: '/products', label: 'Browse Products', icon: 'bi-search' },
    { to: '/create-request', label: 'Create Request', icon: 'bi-plus-circle-fill', highlight: true },
    { to: '/my-requests', label: 'My Requests', icon: 'bi-clock-history' },
    { to: '/available-products', label: 'Available Products', icon: 'bi-box-seam-fill' },
    { to: '/transactions', label: 'Transactions', icon: 'bi-arrow-left-right' },
    { 
      to: '/notifications', 
      label: 'Notifications', 
      icon: 'bi-bell-fill',
      badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : null 
    },
    { to: '/profile', label: 'Profile', icon: 'bi-person-circle' },
    { to: '/about', label: 'About CampusX', icon: 'bi-info-circle-fill' },
  ];

  return (
    <>
      {isOpen && (
        <div 
          className="sidebar-backdrop d-lg-none" 
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <aside className={`cx-sidebar ${isOpen ? 'open' : ''}`}>
        {/* Student Mini Card */}
        {currentUser && (
          <div className="p-3 mx-3 my-2 bg-light rounded-3 border">
            <div className="d-flex align-items-center gap-2">
              {currentUser.avatar ? (
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="rounded-circle border flex-shrink-0"
                  style={{ width: 38, height: 38, objectFit: 'cover' }}
                />
              ) : (
                <div 
                  className="rounded-circle bg-white border text-secondary d-flex align-items-center justify-content-center flex-shrink-0 shadow-sm"
                  style={{ width: 38, height: 38 }}
                >
                  <i className="bi bi-person-fill fs-5 text-muted"></i>
                </div>
              )}
              <div className="overflow-hidden">
                <p className="mb-0 fw-bold small text-dark text-truncate">{currentUser.name}</p>
                <p className="mb-0 text-muted" style={{ fontSize: '0.72rem' }}>
                  {currentUser.id} • {currentUser.department?.slice(0, 3)?.toUpperCase() || 'ENG'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Links */}
        <nav className="flex-grow-1 py-2">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={({ isActive }) =>
                `sidebar-nav-item ${isActive ? 'active' : ''} ${item.highlight ? 'text-primary' : ''}`
              }
            >
              <i className={`bi ${item.icon}`}></i>
              <span className="flex-grow-1">{item.label}</span>
              {item.badge && (
                <span className="badge bg-danger rounded-pill px-2 py-1 small">
                  {item.badge}
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        {/* Bottom Section: Quick Logout and Campus status */}
        <div className="p-3 border-top mt-auto">
          <div className="d-flex align-items-center justify-content-between text-muted mb-2 px-1" style={{ fontSize: '0.75rem' }}>
            <span><i className="bi bi-shield-check text-dark me-1"></i> Campus Active</span>
            <span className="fw-semibold text-dark">v1.0</span>
          </div>

          <button
            type="button"
            className="btn btn-outline-dark btn-sm w-100 d-flex align-items-center justify-content-center gap-2"
            onClick={handleLogout}
          >
            <i className="bi bi-box-arrow-right"></i>
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
