import React, { useEffect } from 'react';

const Modal = ({ isOpen, onClose, title, children, footer, maxWidth = '560px' }) => {
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="cx-modal-overlay" onClick={onClose}>
      <div 
        className="cx-modal-dialog" 
        style={{ maxWidth }} 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="d-flex align-items-center justify-content-between p-3 px-4 border-bottom">
          <h5 className="mb-0 fw-bold text-dark">{title}</h5>
          <button 
            type="button" 
            className="btn btn-sm btn-light rounded-circle p-1 px-2 text-muted"
            onClick={onClose}
            aria-label="Close"
          >
            <i className="bi bi-x-lg"></i>
          </button>
        </div>
        
        <div className="p-4 overflow-auto" style={{ maxHeight: 'calc(80vh - 120px)' }}>
          {children}
        </div>

        {footer && (
          <div className="p-3 px-4 bg-light border-top d-flex justify-content-end gap-2">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};

export default Modal;
