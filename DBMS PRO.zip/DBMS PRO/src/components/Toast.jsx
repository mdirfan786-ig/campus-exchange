import React from 'react';
import { useApp } from '../context/AppContext';

const Toast = () => {
  const { toasts, removeToast } = useApp();

  if (!toasts || toasts.length === 0) return null;

  const getIcon = (type) => {
    switch (type) {
      case 'success':
        return 'bi-check-circle-fill text-success';
      case 'error':
        return 'bi-x-circle-fill text-danger';
      case 'warning':
        return 'bi-exclamation-triangle-fill text-warning';
      case 'info':
      default:
        return 'bi-info-circle-fill text-primary';
    }
  };

  return (
    <div className="cx-toast-container" aria-live="polite">
      {toasts.map((toast) => (
        <div key={toast.id} className={`cx-toast ${toast.type}`}>
          <i className={`bi ${getIcon(toast.type)} fs-5`}></i>
          <div className="flex-grow-1">
            <p className="mb-0 text-dark fw-medium small">{toast.message}</p>
          </div>
          <button
            type="button"
            className="btn btn-sm btn-link text-muted p-0 text-decoration-none"
            onClick={() => removeToast(toast.id)}
          >
            <i className="bi bi-x fs-5"></i>
          </button>
        </div>
      ))}
    </div>
  );
};

export default Toast;
