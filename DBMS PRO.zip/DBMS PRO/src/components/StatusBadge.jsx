import React from 'react';

const StatusBadge = ({ status, type = 'status' }) => {
  if (type === 'urgency') {
    switch (status) {
      case 'Emergency':
        return (
          <span className="cx-badge badge-emergency">
            <i className="bi bi-lightning-charge-fill"></i> Emergency
          </span>
        );
      case 'Urgent':
        return (
          <span className="cx-badge badge-urgent">
            <i className="bi bi-exclamation-triangle-fill"></i> Urgent
          </span>
        );
      case 'Important':
        return (
          <span className="cx-badge badge-important">
            <i className="bi bi-exclamation-circle-fill"></i> Important
          </span>
        );
      case 'Normal':
      default:
        return (
          <span className="cx-badge badge-normal">
            <i className="bi bi-info-circle-fill"></i> Normal
          </span>
        );
    }
  }

  // Request or Transaction Statuses
  switch (status) {
    case 'Waiting':
      return (
        <span className="cx-badge badge-waiting">
          <i className="bi bi-hourglass-split"></i> Waiting
        </span>
      );
    case 'Accepted':
      return (
        <span className="cx-badge badge-accepted">
          <i className="bi bi-check-circle-fill"></i> Accepted
        </span>
      );
    case 'In Progress':
      return (
        <span className="cx-badge badge-active">
          <i className="bi bi-arrow-repeat"></i> In Progress
        </span>
      );
    case 'Completed':
      return (
        <span className="cx-badge badge-completed">
          <i className="bi bi-patch-check-fill"></i> Completed
        </span>
      );
    case 'Returned':
      return (
        <span className="cx-badge badge-completed">
          <i className="bi bi-arrow-return-left"></i> Returned
        </span>
      );
    case 'Active':
      return (
        <span className="cx-badge badge-active">
          <i className="bi bi-arrow-left-right"></i> Active
        </span>
      );
    case 'Cancelled':
      return (
        <span className="cx-badge badge-cancelled">
          <i className="bi bi-x-circle-fill"></i> Cancelled
        </span>
      );
    case 'Available':
      return (
        <span className="cx-badge badge-completed">
          <i className="bi bi-check-lg"></i> Available
        </span>
      );
    case 'Unavailable':
    case 'Lent Out':
      return (
        <span className="cx-badge badge-cancelled">
          <i className="bi bi-clock-history"></i> Currently Lent
        </span>
      );
    default:
      return (
        <span className="cx-badge badge-normal">
          {status}
        </span>
      );
  }
};

export default StatusBadge;
