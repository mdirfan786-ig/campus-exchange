import React from 'react';
import { Link } from 'react-router-dom';
import StatusBadge from './StatusBadge';

const ProductCard = ({ product, isOwner = false, onToggleAvailability }) => {
  return (
    <div className="cx-card h-100 d-flex flex-direction-column">
      <div className="position-relative" style={{ height: '175px', backgroundColor: '#f1f5f9', overflow: 'hidden' }}>
        {product.image ? (
          <img 
            src={product.image} 
            alt={product.name}
            className="w-100 h-100" 
            style={{ objectFit: 'cover' }}
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.nextSibling.style.display = 'flex';
            }}
          />
        ) : null}
        <div 
          className="w-100 h-100 d-flex align-items-center justify-content-center"
          style={{ 
            display: product.image ? 'none' : 'flex',
            backgroundColor: '#f4f4f5'
          }}
        >
          <i 
            className={`bi ${product.icon || 'bi-box-seam'} fs-1`}
            style={{ color: '#09090b' }}
          ></i>
        </div>

        {/* Status Badge overlay */}
        <div className="position-absolute top-0 end-0 m-2">
          <StatusBadge status={product.available ? 'Available' : 'Lent Out'} />
        </div>

        {/* Category tag */}
        <div className="position-absolute bottom-0 start-0 m-2">
          <span className="badge bg-dark bg-opacity-75 text-white small px-2 py-1 rounded">
            {product.category}
          </span>
        </div>
      </div>

      <div className="p-3 d-flex flex-column flex-grow-1">
        <h6 className="fw-bold text-dark mb-1 text-truncate" title={product.name}>
          {product.name}
        </h6>
        
        <p className="text-muted small mb-2 text-truncate-2" style={{ minHeight: '38px', fontSize: '0.85rem' }}>
          {product.description}
        </p>

        <div className="mt-auto pt-2 border-top">
          <div className="d-flex justify-content-between align-items-center small text-muted mb-2">
            <span>
              <i className="bi bi-person me-1 text-primary"></i>
              {product.ownerName} ({product.ownerDept || 'Campus'})
            </span>
            <span className="badge bg-light text-secondary border">
              {product.condition}
            </span>
          </div>

          <div className="small text-muted mb-3 text-truncate" title={product.location}>
            <i className="bi bi-geo-alt me-1 text-danger"></i>
            {product.location}
          </div>

          <div className="d-flex gap-2">
            <Link 
              to={`/product/${product.id}`} 
              className="btn btn-sm btn-outline-primary flex-grow-1 text-center"
            >
              <i className="bi bi-eye me-1"></i> View Details
            </Link>

            {isOwner && onToggleAvailability && (
              <button
                type="button"
                className={`btn btn-sm ${product.available ? 'btn-outline-warning' : 'btn-outline-success'}`}
                onClick={() => onToggleAvailability(product.id)}
                title={product.available ? 'Mark as currently lent out' : 'Mark as available'}
              >
                <i className={`bi ${product.available ? 'bi-pause-fill' : 'bi-play-fill'}`}></i>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
