import React from 'react';
import { Link } from 'react-router-dom';
import StatusBadge from './StatusBadge';

const RequestCard = ({ request, onAcceptClick, currentUserId }) => {
  const isOwner = currentUserId && request.requesterId === currentUserId;
  const canAccept = request.status === 'Waiting' && !isOwner;

  return (
    <div className="cx-card h-100 d-flex flex-column">
      <div className="p-3 border-bottom d-flex justify-content-between align-items-start gap-2">
        <div>
          <span className="text-muted small fw-semibold">#{request.id}</span>
          <h6 className="fw-bold text-dark mb-0 text-truncate" title={request.productName}>
            {request.productName}
          </h6>
        </div>
        <StatusBadge status={request.urgency} type="urgency" />
      </div>

      <div className="p-3 d-flex flex-column flex-grow-1">
        <div className="d-flex align-items-center gap-2 mb-2">
          <div className="rounded-circle bg-primary bg-opacity-10 text-primary d-flex align-items-center justify-content-center fw-bold" style={{ width: 32, height: 32, fontSize: '0.8rem' }}>
            {request.requesterName.slice(0, 2).toUpperCase()}
          </div>
          <div className="small">
            <span className="fw-semibold text-dark d-block">{request.requesterName}</span>
            <span className="text-muted">{request.requesterDept} Dept • Year {request.requesterYear || '3'}</span>
          </div>
        </div>

        <p className="text-muted small mb-3 fst-italic bg-light p-2 rounded border" style={{ minHeight: '44px', fontSize: '0.83rem' }}>
          "{request.reason || 'Needed urgently for class/exam'}"
        </p>

        <div className="small text-secondary mb-1">
          <i className="bi bi-geo-alt-fill text-danger me-1"></i>
          <span className="fw-medium">{request.location}</span>
        </div>

        <div className="d-flex justify-content-between align-items-center small text-muted mb-3">
          <span>
            <i className="bi bi-clock me-1"></i>
            {request.requiredTime || 'Immediate'} ({request.requiredDate || 'Today'})
          </span>
          <span className="badge bg-light text-dark border">
            Qty: {request.quantity}
          </span>
        </div>

        <div className="mt-auto pt-2 border-top d-flex justify-content-between align-items-center">
          <StatusBadge status={request.status} />

          <div className="d-flex gap-2">
            <Link 
              to={`/request/${request.id}`} 
              className="btn btn-sm btn-outline-secondary"
              title="View full details"
            >
              Details
            </Link>

            {canAccept && onAcceptClick && (
              <button 
                type="button" 
                className="btn btn-sm btn-primary"
                onClick={() => onAcceptClick(request)}
              >
                <i className="bi bi-hand-thumbs-up me-1"></i> Accept
              </button>
            )}

            {isOwner && request.status === 'Waiting' && (
              <span className="badge bg-info bg-opacity-10 text-primary small py-1 px-2">
                Your Request
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestCard;
