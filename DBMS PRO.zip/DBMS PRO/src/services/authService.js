import { KEYS, getStorageData, setStorageData, fetchApi, initStorage } from './api';

initStorage();

export const authService = {
  // Login with student ID or college email
  async login(identifier, password) {
    try {
      const res = await fetchApi('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ identifier, password })
      });
      if (res && res.success && res.data) {
        setStorageData(KEYS.CURRENT_USER, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[AuthService] Backend login error, trying local cache:', err.message);
    }

    const students = getStorageData(KEYS.STUDENTS, []);
    const cleanId = identifier.trim().toLowerCase();

    const student = students.find(
      s => s.id.toLowerCase() === cleanId || s.email.toLowerCase() === cleanId
    );

    if (!student) {
      throw new Error("Student ID or Email not found in campus directory.");
    }

    setStorageData(KEYS.CURRENT_USER, student);
    return student;
  },

  // Register new student
  async register(studentData) {
    try {
      const res = await fetchApi('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(studentData)
      });
      if (res && res.success && res.data) {
        setStorageData(KEYS.CURRENT_USER, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[AuthService] Backend register error:', err.message);
    }

    const students = getStorageData(KEYS.STUDENTS, []);
    const exists = students.some(
      s => s.id.toLowerCase() === studentData.id.toLowerCase() ||
           s.email.toLowerCase() === studentData.email.toLowerCase()
    );

    if (exists) {
      throw new Error("Student ID or Email already registered in CampusX.");
    }

    const newStudent = {
      ...studentData,
      stats: { lent: 0, borrowed: 0, completed: 0, rating: 5.0 }
    };

    students.push(newStudent);
    setStorageData(KEYS.STUDENTS, students);
    return newStudent;
  },

  // Get current logged-in student
  getCurrentUser() {
    return getStorageData(KEYS.CURRENT_USER, null);
  },

  // Update profile
  async updateProfile(updatedData) {
    const currentUser = getStorageData(KEYS.CURRENT_USER, null);
    if (!currentUser) throw new Error("No active student session.");

    try {
      const res = await fetchApi(`/api/auth/profile/${currentUser.id}`, {
        method: 'PUT',
        body: JSON.stringify(updatedData)
      });
      if (res && res.success && res.data) {
        setStorageData(KEYS.CURRENT_USER, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[AuthService] Backend profile update failed:', err.message);
    }

    const merged = { ...currentUser, ...updatedData };
    setStorageData(KEYS.CURRENT_USER, merged);
    return merged;
  },

  // Switch account easily for demoing request-accept flows
  async switchUser(studentId) {
    const students = await this.getAllStudents();
    const student = students.find(s => s.id === studentId);
    if (student) {
      setStorageData(KEYS.CURRENT_USER, student);
      return student;
    }
    throw new Error("Student not found");
  },

  // Logout
  async logout() {
    localStorage.removeItem(KEYS.CURRENT_USER);
    return true;
  },

  // Get all registered students
  async getAllStudents() {
    try {
      const res = await fetchApi('/api/auth/students');
      if (res && res.success && Array.isArray(res.data)) {
        setStorageData(KEYS.STUDENTS, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[AuthService] Backend students fetch failed:', err.message);
    }
    return getStorageData(KEYS.STUDENTS, []);
  }
};
