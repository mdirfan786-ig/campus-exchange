import { KEYS, getStorageData, setStorageData, fetchApi, initStorage } from './api';

initStorage();

export const requestService = {
  // Get requests with filters from real backend (fallback to localStorage if network offline)
  async getRequests(filters = {}) {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.category && filters.category !== 'All') params.append('category', filters.category);
    if (filters.urgency && filters.urgency !== 'All') params.append('urgency', filters.urgency);
    if (filters.status && filters.status !== 'All') params.append('status', filters.status);
    if (filters.requesterId) params.append('requesterId', filters.requesterId);

    const queryString = params.toString() ? `?${params.toString()}` : '';

    try {
      const res = await fetchApi(`/api/requests${queryString}`);
      if (res && res.success && Array.isArray(res.data)) {
        // Cache to storage for offline resilience
        setStorageData(KEYS.REQUESTS, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[RequestService] Backend offline or unreachable, using local storage cache:', err.message);
    }

    // Offline / fallback filter
    let list = getStorageData(KEYS.REQUESTS, []);

    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(r =>
        (r.productName && r.productName.toLowerCase().includes(q)) ||
        (r.reason && r.reason.toLowerCase().includes(q)) ||
        (r.location && r.location.toLowerCase().includes(q)) ||
        (r.category && r.category.toLowerCase().includes(q)) ||
        (r.requesterName && r.requesterName.toLowerCase().includes(q))
      );
    }

    if (filters.category && filters.category !== 'All') {
      list = list.filter(r => r.category === filters.category);
    }

    if (filters.urgency && filters.urgency !== 'All') {
      list = list.filter(r => r.urgency === filters.urgency);
    }

    if (filters.status && filters.status !== 'All') {
      list = list.filter(r => r.status === filters.status);
    }

    if (filters.requesterId) {
      list = list.filter(r => r.requesterId === filters.requesterId);
    }

    return list;
  },

  // Get single request by ID
  async getRequestById(id) {
    try {
      const res = await fetchApi(`/api/requests/${id}`);
      if (res && res.success && res.data) {
        return res.data;
      }
    } catch (err) {
      console.warn(`[RequestService] Failed to fetch request #${id} from backend:`, err.message);
    }

    const list = getStorageData(KEYS.REQUESTS, []);
    const req = list.find(r => r.id === id);
    if (!req) throw new Error("Request not found");
    return req;
  },

  // Create urgent product request on backend
  async createRequest(reqData) {
    try {
      const res = await fetchApi('/api/requests', {
        method: 'POST',
        body: JSON.stringify(reqData)
      });
      if (res && res.success && res.data) {
        // Sync local cache
        const list = getStorageData(KEYS.REQUESTS, []);
        list.unshift(res.data);
        setStorageData(KEYS.REQUESTS, list);
        return res.data;
      }
    } catch (err) {
      console.warn('[RequestService] Backend POST failed, saving locally:', err.message);
    }

    // Local fallback
    const list = getStorageData(KEYS.REQUESTS, []);
    const newId = `REQ${1020 + list.length + 1}`;

    const newRequest = {
      ...reqData,
      id: newId,
      status: "Waiting",
      acceptedBy: null,
      pickupDetails: null,
      createdAt: new Date().toISOString()
    };

    list.unshift(newRequest);
    setStorageData(KEYS.REQUESTS, list);
    return newRequest;
  },

  // Accept a student's request
  async acceptRequest(requestId, lenderStudent, pickupDetails) {
    try {
      const res = await fetchApi(`/api/requests/${requestId}/accept`, {
        method: 'PUT',
        body: JSON.stringify({ lenderStudent, pickupDetails })
      });
      if (res && res.success && res.data) {
        const list = getStorageData(KEYS.REQUESTS, []);
        const idx = list.findIndex(r => r.id === requestId);
        if (idx !== -1) {
          list[idx] = res.data;
          setStorageData(KEYS.REQUESTS, list);
        }
        return res.data;
      }
    } catch (err) {
      console.warn('[RequestService] Backend accept failed, updating locally:', err.message);
    }

    // Local fallback
    const list = getStorageData(KEYS.REQUESTS, []);
    const index = list.findIndex(r => r.id === requestId);
    if (index === -1) throw new Error("Request not found");

    const req = list[index];
    req.status = "Accepted";
    req.acceptedBy = {
      id: lenderStudent.id,
      name: lenderStudent.name,
      department: lenderStudent.department,
      phone: lenderStudent.phone,
      location: lenderStudent.location || "On Campus"
    };
    req.pickupDetails = pickupDetails || "Meet on campus. Call on arrival.";
    setStorageData(KEYS.REQUESTS, list);
    return req;
  },

  // Update request status (Completed, Cancelled, Returned)
  async updateRequestStatus(requestId, status, currentUserId) {
    try {
      const res = await fetchApi(`/api/requests/${requestId}/status`, {
        method: 'PUT',
        body: JSON.stringify({ status, currentUserId })
      });
      if (res && res.success && res.data) {
        const list = getStorageData(KEYS.REQUESTS, []);
        const idx = list.findIndex(r => r.id === requestId);
        if (idx !== -1) {
          list[idx] = res.data;
          setStorageData(KEYS.REQUESTS, list);
        }
        return res.data;
      }
    } catch (err) {
      console.warn('[RequestService] Backend status update failed:', err.message);
    }

    // Local fallback
    const list = getStorageData(KEYS.REQUESTS, []);
    const index = list.findIndex(r => r.id === requestId);
    if (index === -1) throw new Error("Request not found");

    list[index].status = status;
    setStorageData(KEYS.REQUESTS, list);
    return list[index];
  }
};
