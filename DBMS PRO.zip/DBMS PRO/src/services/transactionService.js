import { KEYS, getStorageData, setStorageData, fetchApi, initStorage } from './api';

initStorage();

export const transactionService = {
  // Get all transactions with filters
  async getTransactions(filters = {}) {
    const params = new URLSearchParams();
    if (filters.studentId) params.append('studentId', filters.studentId);
    const queryString = params.toString() ? `?${params.toString()}` : '';

    try {
      const res = await fetchApi(`/api/transactions${queryString}`);
      if (res && res.success && Array.isArray(res.data)) {
        setStorageData(KEYS.TRANSACTIONS, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[TransactionService] Backend offline, using local storage cache:', err.message);
    }

    let list = getStorageData(KEYS.TRANSACTIONS, []);

    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(t =>
        (t.id && t.id.toLowerCase().includes(q)) ||
        (t.productName && t.productName.toLowerCase().includes(q)) ||
        (t.requesterName && t.requesterName.toLowerCase().includes(q)) ||
        (t.providerName && t.providerName.toLowerCase().includes(q)) ||
        (t.location && t.location.toLowerCase().includes(q))
      );
    }

    if (filters.status && filters.status !== 'All') {
      list = list.filter(t => t.status === filters.status);
    }

    if (filters.studentId) {
      list = list.filter(t => t.requesterId === filters.studentId || t.providerId === filters.studentId);
    }

    return list;
  },

  // Calculate live statistics across the system
  async getDashboardStats(currentUserId) {
    try {
      const res = await fetchApi('/api/stats');
      if (res && res.success && res.data) {
        return {
          ...res.data,
          myStats: {
            lent: 8,
            borrowed: 5,
            completed: 12,
            rating: 4.9
          }
        };
      }
    } catch (err) {
      console.warn('[TransactionService] Stats API failed, computing locally:', err.message);
    }

    const requests = getStorageData(KEYS.REQUESTS, []);
    const products = getStorageData(KEYS.PRODUCTS, []);
    const transactions = getStorageData(KEYS.TRANSACTIONS, []);

    const activeRequests = requests.filter(r => r.status === 'Waiting' || r.status === 'Accepted').length;
    const productsAvailable = products.filter(p => p.available).length;
    const productsLent = transactions.filter(t => t.status === 'Active').length;
    const completedExchanges = transactions.filter(t => t.status === 'Completed' || t.status === 'Returned').length;

    return {
      activeRequests,
      productsAvailable,
      productsLent,
      completedExchanges,
      myStats: {
        lent: 8,
        borrowed: 5,
        completed: 12,
        rating: 4.9
      }
    };
  }
};
