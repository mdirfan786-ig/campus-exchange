// CampusX Universal API Layer with Real Backend & Offline LocalStorage Fallback
// Enables multi-device access across smartphones, tablets, and computers on LAN/Wi-Fi

import {
  INITIAL_STUDENTS,
  INITIAL_PRODUCTS,
  INITIAL_REQUESTS,
  INITIAL_TRANSACTIONS,
  INITIAL_NOTIFICATIONS
} from '../data/mockData';

const KEYS = {
  STUDENTS: 'campusx_students',
  PRODUCTS: 'campusx_products',
  REQUESTS: 'campusx_requests',
  TRANSACTIONS: 'campusx_transactions',
  NOTIFICATIONS: 'campusx_notifications',
  CURRENT_USER: 'campusx_currentUser'
};

// Initialize localStorage with initial seed data if not present
export const initStorage = () => {
  if (!localStorage.getItem(KEYS.STUDENTS)) {
    localStorage.setItem(KEYS.STUDENTS, JSON.stringify(INITIAL_STUDENTS));
  }
  if (!localStorage.getItem(KEYS.PRODUCTS)) {
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
  }
  if (!localStorage.getItem(KEYS.REQUESTS)) {
    localStorage.setItem(KEYS.REQUESTS, JSON.stringify(INITIAL_REQUESTS));
  }
  if (!localStorage.getItem(KEYS.TRANSACTIONS)) {
    localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(INITIAL_TRANSACTIONS));
  }
  if (!localStorage.getItem(KEYS.NOTIFICATIONS)) {
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(INITIAL_NOTIFICATIONS));
  }
  if (!localStorage.getItem(KEYS.CURRENT_USER)) {
    localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(INITIAL_STUDENTS[0]));
  }
};

// Generic read helper
export const getStorageData = (key, defaultVal = []) => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultVal;
  } catch (e) {
    console.error(`Error reading ${key} from storage:`, e);
    return defaultVal;
  }
};

// Generic write helper
export const setStorageData = (key, data) => {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error(`Error writing ${key} to storage:`, e);
  }
};

// Mock async delay for fallback
export const delay = (ms = 80) => new Promise(resolve => setTimeout(resolve, ms));

// ==================== UNIVERSAL MULTI-DEVICE HTTP CALLER ====================
// Automatically handles requests from localhost, phone, tablet on Wi-Fi (e.g. 192.168.x.x)
export const fetchApi = async (endpoint, options = {}) => {
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const url = cleanEndpoint.startsWith('/api') ? cleanEndpoint : `/api${cleanEndpoint}`;

  try {
    const response = await fetch(url, {
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      },
      ...options
    });

    if (!response.ok) {
      const errBody = await response.json().catch(() => ({}));
      throw new Error(errBody.error || `HTTP ${response.status}: Request failed`);
    }

    return await response.json();
  } catch (err) {
    // If proxy failed, retry directly hitting port 5000 on current hostname
    if (typeof window !== 'undefined' && !options._retried) {
      try {
        const host = window.location.hostname || 'localhost';
        const fallbackUrl = `http://${host}:5000${url}`;
        const fallbackRes = await fetch(fallbackUrl, {
          headers: {
            'Content-Type': 'application/json',
            ...(options.headers || {})
          },
          ...options,
          _retried: true
        });
        if (fallbackRes.ok) {
          return await fallbackRes.json();
        }
      } catch (fallbackErr) {
        // Fall through to throw err
      }
    }
    throw err;
  }
};

export { KEYS };
