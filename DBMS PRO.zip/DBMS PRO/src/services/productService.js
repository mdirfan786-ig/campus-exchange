import { KEYS, getStorageData, setStorageData, fetchApi, initStorage } from './api';

initStorage();

export const productService = {
  // Get all products with optional filters
  async getProducts(filters = {}) {
    const params = new URLSearchParams();
    if (filters.search) params.append('search', filters.search);
    if (filters.category && filters.category !== 'All') params.append('category', filters.category);
    if (filters.availability && filters.availability !== 'All') {
      params.append('available', filters.availability === 'Available');
    }
    if (filters.ownerId) params.append('ownerId', filters.ownerId);

    const queryString = params.toString() ? `?${params.toString()}` : '';

    try {
      const res = await fetchApi(`/api/products${queryString}`);
      if (res && res.success && Array.isArray(res.data)) {
        setStorageData(KEYS.PRODUCTS, res.data);
        return res.data;
      }
    } catch (err) {
      console.warn('[ProductService] Backend offline, using local storage cache:', err.message);
    }

    // Local fallback
    let list = getStorageData(KEYS.PRODUCTS, []);

    if (filters.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(p =>
        (p.name && p.name.toLowerCase().includes(q)) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q)) ||
        (p.location && p.location.toLowerCase().includes(q))
      );
    }

    if (filters.category && filters.category !== 'All') {
      list = list.filter(p => p.category === filters.category);
    }

    if (filters.availability && filters.availability !== 'All') {
      const isAvail = filters.availability === 'Available';
      list = list.filter(p => p.available === isAvail);
    }

    if (filters.ownerId) {
      list = list.filter(p => p.ownerId === filters.ownerId);
    }

    return list;
  },

  // Get single product
  async getProductById(id) {
    try {
      const res = await fetchApi(`/api/products/${id}`);
      if (res && res.success && res.data) {
        return res.data;
      }
    } catch (err) {
      console.warn(`[ProductService] Failed to fetch product #${id} from backend:`, err.message);
    }

    const list = getStorageData(KEYS.PRODUCTS, []);
    const product = list.find(p => p.id === id);
    if (!product) throw new Error("Product not found");
    return product;
  },

  // Add new product offered for campus lending
  async addProduct(productData) {
    try {
      const res = await fetchApi('/api/products', {
        method: 'POST',
        body: JSON.stringify(productData)
      });
      if (res && res.success && res.data) {
        const list = getStorageData(KEYS.PRODUCTS, []);
        list.unshift(res.data);
        setStorageData(KEYS.PRODUCTS, list);
        return res.data;
      }
    } catch (err) {
      console.warn('[ProductService] Backend add failed, saving locally:', err.message);
    }

    const list = getStorageData(KEYS.PRODUCTS, []);
    const newId = `PROD${100 + list.length + 1}`;

    const newProduct = {
      ...productData,
      id: newId,
      available: true,
      quantity: Number(productData.quantity) || 1,
      createdAt: new Date().toISOString()
    };

    list.unshift(newProduct);
    setStorageData(KEYS.PRODUCTS, list);
    return newProduct;
  },

  // Toggle availability
  async toggleAvailability(productId) {
    try {
      const res = await fetchApi(`/api/products/${productId}/availability`, {
        method: 'PUT'
      });
      if (res && res.success && res.data) {
        const list = getStorageData(KEYS.PRODUCTS, []);
        const idx = list.findIndex(p => p.id === productId);
        if (idx !== -1) {
          list[idx] = res.data;
          setStorageData(KEYS.PRODUCTS, list);
        }
        return res.data;
      }
    } catch (err) {
      console.warn('[ProductService] Backend toggle failed, updating locally:', err.message);
    }

    const list = getStorageData(KEYS.PRODUCTS, []);
    const index = list.findIndex(p => p.id === productId);
    if (index === -1) throw new Error("Product not found");

    list[index].available = !list[index].available;
    setStorageData(KEYS.PRODUCTS, list);
    return list[index];
  },

  async deleteProduct(productId) {
    let list = getStorageData(KEYS.PRODUCTS, []);
    list = list.filter(p => p.id !== productId);
    setStorageData(KEYS.PRODUCTS, list);
    return true;
  }
};
