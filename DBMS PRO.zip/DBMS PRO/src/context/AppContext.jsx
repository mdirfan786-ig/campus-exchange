import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authService } from '../services/authService';
import { productService } from '../services/productService';
import { requestService } from '../services/requestService';
import { transactionService } from '../services/transactionService';
import { KEYS, getStorageData, setStorageData } from '../services/api';

const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(() => {
    const user = authService.getCurrentUser();
    if (!user || user.id === 'STU1001' || user.name === 'Arun Kumar') {
      const updated = {
        id: 'STU1001',
        name: 'Mohamed Irfan N',
        department: 'Computer Science & Engineering',
        year: '3',
        section: 'A',
        email: 'mohamed.irfan@example.com',
        phone: '+91 98451 23450',
        avatar: '',
        stats: {
          lent: 8,
          borrowed: 5,
          completed: 12,
          rating: 4.9
        }
      };
      setStorageData(KEYS.CURRENT_USER, updated);
      return updated;
    }
    return user;
  });
  const [products, setProducts] = useState([]);
  const [requests, setRequests] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState([]);

  // Toast dispatch helper
  const showToast = useCallback((message, type = 'success', duration = 3500) => {
    const id = Date.now() + Math.random().toString(36).substring(2, 6);
    setToasts(prev => [...prev, { id, message, type }]);

    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, duration);
  }, []);

  const removeToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Fetch all initial data from local services
  const refreshData = useCallback(async () => {
    try {
      const [prods, reqs, txns, notifs] = await Promise.all([
        productService.getProducts(),
        requestService.getRequests(),
        transactionService.getTransactions(),
        getStorageData(KEYS.NOTIFICATIONS, [])
      ]);

      setProducts(prods);
      setRequests(reqs);
      setTransactions(txns);
      setNotifications(notifs);
    } catch (err) {
      console.error("Error refreshing data:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Auth actions
  const login = async (identifier, password) => {
    const user = await authService.login(identifier, password);
    setCurrentUser(user);
    showToast(`Welcome back, ${user.name}!`, 'success');
    return user;
  };

  const register = async (studentData) => {
    const user = await authService.register(studentData);
    showToast("Registration successful! You can now log in.", 'success');
    return user;
  };

  const logout = async () => {
    await authService.logout();
    setCurrentUser(null);
    showToast("Logged out successfully.", 'info');
  };

  const updateProfile = async (updatedData) => {
    const updated = await authService.updateProfile(updatedData);
    setCurrentUser(updated);
    showToast("Profile details updated successfully!", 'success');
    return updated;
  };

  const switchAccount = async (studentId) => {
    const user = await authService.switchUser(studentId);
    setCurrentUser(user);
    showToast(`Switched active profile to ${user.name} (${user.id})`, 'info');
    return user;
  };

  // Product actions
  const addProduct = async (productData) => {
    const newProd = await productService.addProduct({
      ...productData,
      ownerId: currentUser?.id || "STU1001",
      ownerName: currentUser?.name || "Student",
      ownerDept: currentUser?.department?.slice(0, 3)?.toUpperCase() || "ENG"
    });
    setProducts(prev => [newProd, ...prev]);
    showToast(`"${newProd.name}" added to available products!`, 'success');
    return newProd;
  };

  const toggleProductAvailability = async (productId) => {
    const updated = await productService.toggleAvailability(productId);
    setProducts(prev => prev.map(p => p.id === productId ? updated : p));
    showToast(`Status updated: ${updated.available ? 'Available' : 'Lent Out'}`, 'info');
    return updated;
  };

  const deleteProduct = async (productId) => {
    await productService.deleteProduct(productId);
    setProducts(prev => prev.filter(p => p.id !== productId));
    showToast("Product removed from exchange catalog.", 'info');
  };

  // Request actions
  const createRequest = async (requestData) => {
    const newReq = await requestService.createRequest({
      ...requestData,
      requesterId: currentUser?.id || "STU1001",
      requesterName: currentUser?.name || "Campus Student",
      requesterDept: currentUser?.department || "CSE",
      requesterYear: currentUser?.year || "3",
      requesterPhone: currentUser?.phone || "+91 98451 23450"
    });
    setRequests(prev => [newReq, ...prev]);
    await refreshData();
    showToast("Urgent request broadcasted to campus students!", 'success');
    return newReq;
  };

  const acceptRequest = async (requestId, pickupDetails) => {
    if (!currentUser) throw new Error("Please log in to accept requests.");
    const result = await requestService.acceptRequest(requestId, currentUser, pickupDetails);
    await refreshData();
    showToast(`Request accepted! Pickup details sent to ${result.request.requesterName}.`, 'success');
    return result;
  };

  const cancelRequest = async (requestId) => {
    const updated = await requestService.cancelRequest(requestId);
    setRequests(prev => prev.map(r => r.id === requestId ? updated : r));
    showToast("Request cancelled.", 'info');
    return updated;
  };

  const completeRequest = async (requestId) => {
    const updated = await requestService.completeRequest(requestId);
    await refreshData();
    showToast("Request and exchange completed successfully!", 'success');
    return updated;
  };

  // Transaction actions
  const updateTransactionStatus = async (txnId, status, notes) => {
    const updated = await transactionService.updateTransactionStatus(txnId, status, notes);
    setTransactions(prev => prev.map(t => t.id === txnId ? updated : t));
    showToast(`Transaction ${txnId} marked as ${status}.`, 'success');
    return updated;
  };

  // Notification actions
  const markNotificationRead = (notifId) => {
    setNotifications(prev => {
      const updated = prev.map(n => n.id === notifId ? { ...n, unread: false } : n);
      setStorageData(KEYS.NOTIFICATIONS, updated);
      return updated;
    });
  };

  const markAllNotificationsRead = () => {
    setNotifications(prev => {
      const updated = prev.map(n => ({ ...n, unread: false }));
      setStorageData(KEYS.NOTIFICATIONS, updated);
      return updated;
    });
    showToast("All notifications marked as read.", 'info');
  };

  // Calculated metrics
  const unreadNotificationsCount = notifications.filter(
    n => n.unread && (n.userId === currentUser?.id || n.userId === 'ALL')
  ).length;

  const stats = {
    activeRequests: requests.filter(r => r.status === 'Waiting' || r.status === 'Accepted').length,
    productsAvailable: products.filter(p => p.available).length,
    productsLent: transactions.filter(t => t.status === 'Active').length,
    completedExchanges: transactions.filter(t => t.status === 'Completed' || t.status === 'Returned').length
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        login,
        register,
        logout,
        updateProfile,
        switchAccount,
        products,
        addProduct,
        toggleProductAvailability,
        deleteProduct,
        requests,
        createRequest,
        acceptRequest,
        cancelRequest,
        completeRequest,
        transactions,
        updateTransactionStatus,
        notifications,
        unreadNotificationsCount,
        markNotificationRead,
        markAllNotificationsRead,
        stats,
        toasts,
        showToast,
        removeToast,
        loading,
        refreshData
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
};
